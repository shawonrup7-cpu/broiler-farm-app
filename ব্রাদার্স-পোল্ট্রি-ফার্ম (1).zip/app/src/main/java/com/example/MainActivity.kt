package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HomeWork
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.HomeWork
import androidx.compose.material.icons.outlined.MedicalServices
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.FinanceScreen
import com.example.ui.screens.FlocksScreen
import com.example.ui.screens.HealthAndPortalScreen
import com.example.ui.screens.formatCurrencyBdt
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.PoultryViewModel
import java.util.Locale

enum class AppDestination(
    val route: String,
    val labelBn: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    DASHBOARD("dashboard", "ড্যাশবোর্ড", Icons.Filled.Dashboard, Icons.Outlined.Dashboard),
    FLOCKS("flocks", "ব্যাচ ও শেড", Icons.Filled.HomeWork, Icons.Outlined.HomeWork),
    FINANCE("finance", "আয় ও ব্যয়", Icons.Filled.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet),
    HEALTH_PORTAL("health_portal", "টিকা ও পোর্টাল", Icons.Filled.MedicalServices, Icons.Outlined.MedicalServices)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val context = LocalContext.current
                val viewModel: PoultryViewModel = viewModel(
                    factory = PoultryViewModel.provideFactory(context)
                )
                BroilerFarmAccountApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BroilerFarmAccountApp(
    viewModel: PoultryViewModel
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val fcrResult by viewModel.fcrResult.collectAsStateWithLifecycle()
    var currentTab by rememberSaveable { mutableStateOf(AppDestination.DASHBOARD) }
    var showEditAppNameDialog by rememberSaveable { mutableStateOf(false) }

    BackHandler(enabled = currentTab != AppDestination.DASHBOARD) {
        currentTab = AppDestination.DASHBOARD
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isExpandedScreen = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            topBar = {
                TopAppBar(
                    title = {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Pets,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = uiState.customAppName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                    Text(
                                        text = "মোট আয়: ${formatCurrencyBdt(uiState.totalIncomeBdt)} • মোট ব্যয়: ${formatCurrencyBdt(uiState.totalExpenseBdt)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            FilledTonalButton(
                                onClick = { showEditAppNameDialog = true },
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier
                                    .padding(end = 8.dp)
                                    .testTag("change_app_name_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "অ্যাপের নাম পরিবর্তন",
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "নাম বদলান",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
            },
            bottomBar = {
                if (!isExpandedScreen) {
                    NavigationBar(
                        modifier = Modifier.testTag("bottom_navigation_bar")
                    ) {
                        AppDestination.entries.forEach { tab ->
                            val selected = currentTab == tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { currentTab = tab },
                                icon = {
                                    TabIconWithBadge(
                                        tab = tab,
                                        selected = selected,
                                        badgeCount = when (tab) {
                                            AppDestination.DASHBOARD -> uiState.pendingDailyMedicineCount
                                            AppDestination.HEALTH_PORTAL -> uiState.pendingVaccinationCount
                                            else -> 0
                                        }
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.labelBn,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                modifier = Modifier.testTag("nav_tab_${tab.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isExpandedScreen) {
                    NavigationRail(
                        modifier = Modifier
                            .fillMaxHeight()
                            .testTag("side_navigation_rail")
                    ) {
                        AppDestination.entries.forEach { tab ->
                            val selected = currentTab == tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { currentTab = tab },
                                icon = {
                                    TabIconWithBadge(
                                        tab = tab,
                                        selected = selected,
                                        badgeCount = when (tab) {
                                            AppDestination.DASHBOARD -> uiState.pendingDailyMedicineCount
                                            AppDestination.HEALTH_PORTAL -> uiState.pendingVaccinationCount
                                            else -> 0
                                        }
                                    )
                                },
                                label = { Text(tab.labelBn) },
                                modifier = Modifier.testTag("rail_tab_${tab.route}")
                            )
                        }
                    }
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    when (currentTab) {
                        AppDestination.DASHBOARD -> {
                            DashboardScreen(
                                uiState = uiState,
                                onAddDailyLog = viewModel::addDailyLog,
                                onDeleteDailyLog = viewModel::deleteDailyLog,
                                onQuickAddTransaction = viewModel::addTransaction,
                                onAddBroilerPallaSale = viewModel::addBroilerPallaSale,
                                onDeleteBroilerSale = viewModel::deleteBroilerSale,
                                onAddDailyMedicine = viewModel::addDailyMedicine,
                                onToggleDailyMedicine = viewModel::toggleDailyMedicine,
                                onDeleteDailyMedicine = viewModel::deleteDailyMedicine,
                                onAddFlockClick = viewModel::addFlock,
                                onOpenEditAppName = { showEditAppNameDialog = true },
                                onNavigateToFlocks = { currentTab = AppDestination.FLOCKS },
                                onNavigateToFinance = { currentTab = AppDestination.FINANCE },
                                onNavigateToHealth = { currentTab = AppDestination.HEALTH_PORTAL }
                            )
                        }

                        AppDestination.FLOCKS -> {
                            FlocksScreen(
                                uiState = uiState,
                                onBreedFilterChange = viewModel::setBreedFilter,
                                onSearchQueryChange = viewModel::setSearchQuery,
                                onAddFlock = viewModel::addFlock,
                                onDeleteFlock = viewModel::deleteFlock,
                                onAddDailyLog = viewModel::addDailyLog
                            )
                        }

                        AppDestination.FINANCE -> {
                            FinanceScreen(
                                uiState = uiState,
                                fcrResult = fcrResult,
                                onFinanceFilterChange = viewModel::setFinanceFilter,
                                onSearchQueryChange = viewModel::setSearchQuery,
                                onAddTransaction = viewModel::addTransaction,
                                onDeleteTransaction = viewModel::deleteTransaction,
                                onAddBroilerPallaSale = viewModel::addBroilerPallaSale,
                                onDeleteBroilerSale = viewModel::deleteBroilerSale,
                                onUpdateFcr = viewModel::updateFcrCalculator
                            )
                        }

                        AppDestination.HEALTH_PORTAL -> {
                            HealthAndPortalScreen(
                                vaccinations = uiState.vaccinations,
                                flocks = uiState.flocks,
                                onAddVaccination = viewModel::addVaccination,
                                onToggleVaccination = viewModel::toggleVaccination,
                                onDeleteVaccination = viewModel::deleteVaccination
                            )
                        }
                    }
                }
            }
        }
    }

    if (showEditAppNameDialog) {
        var nameInput by rememberSaveable { mutableStateOf(uiState.customAppName) }
        val presetNames = listOf(
            "ব্রয়লার খামার হিসাব",
            "স্মার্ট পোল্ট্রি খামার হিসাব",
            "আধুনিক ব্রয়লার ফার্ম খাতা"
        )
        AlertDialog(
            onDismissRequest = { showEditAppNameDialog = false },
            title = {
                Text(
                    text = "অ্যাপ ও খামারের নাম পরিবর্তন করুন",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "আপনার খামারের বা অ্যাপের পছন্দের নাম লিখুন অথবা নিচের যেকোনো একটি নির্বাচন করুন:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("অ্যাপ / খামারের নাম") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("app_name_input_field")
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        presetNames.forEach { preset ->
                            FilledTonalButton(
                                onClick = { nameInput = preset },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(preset, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateAppName(nameInput)
                        showEditAppNameDialog = false
                    },
                    modifier = Modifier.testTag("save_app_name_btn")
                ) {
                    Text("নাম সংরক্ষণ করুন", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditAppNameDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@Composable
private fun TabIconWithBadge(
    tab: AppDestination,
    selected: Boolean,
    badgeCount: Int
) {
    val icon = if (selected) tab.selectedIcon else tab.unselectedIcon
    if (badgeCount > 0) {
        BadgedBox(
            badge = {
                Badge {
                    Text(badgeCount.toString())
                }
            }
        ) {
            Icon(imageVector = icon, contentDescription = tab.labelBn)
        }
    } else {
        Icon(imageVector = icon, contentDescription = tab.labelBn)
    }
}
