package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "flocks")
data class FlockEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val shedNumber: String,
    val breed: String, // "কব-৫০০ (Cobb-500)", "রস-৩০৮ (Ross-308)", "হাবার্ড (Hubbard)", "আর্বার একরস (Arbor Acres)"
    val initialCount: Int,
    val currentCount: Int,
    val ageInDays: Int,
    val targetSaleDays: Int = 32,
    val avgWeightGrams: Int,
    val totalFeedConsumedKg: Double,
    val chickPricePerBird: Double = 48.0,
    val startDateLabel: String, // বাচ্চার আসার দিন (Chick Arrival Date)
    val hatcheryName: String = "কাজী হ্যাচারি (A-Grade)",
    val notes: String,
    val isActive: Boolean = true
) {
    val deadBirdCount: Int
        get() = (initialCount - currentCount).coerceAtLeast(0)

    val mortalityRatePercent: Double
        get() = if (initialCount > 0) (deadBirdCount.toDouble() / initialCount.toDouble()) * 100.0 else 0.0
}

@Entity(tableName = "daily_logs")
data class DailyLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val flockId: Long,
    val flockName: String,
    val dateLabel: String,
    val feedPhase: String, // "প্রি-স্টার্টার", "স্টার্টার", "গ্রোয়ার", "ফিনিশার"
    val mortalityCount: Int,
    val feedKg: Double,
    val waterLiters: Double,
    val avgWeightGrams: Int,
    val medicineGiven: String,
    val remarks: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "finance_transactions")
data class FinanceTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String,
    // আয় (Sales): "মুরগি বিক্রি", "খুচরা মুরগি বিক্রি", "ফিড বিক্রি", "লিটার/ব্যবহৃত গুঁড়া বিক্রি"
    // ব্যয় (Expenses): "বাচ্চা ক্রয়", "ফিড ক্রয়", "ওষুধ ও টিকা", "কাঠের গুঁড়া কেনা", "কর্মচারী বেতন", "যাতায়াত ভাড়া", "বিদ্যুৎ ও অন্যান্য"
    val isIncome: Boolean,
    val amountBdt: Double,
    val quantityNote: String,
    val dateLabel: String,
    val partyName: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "vaccinations")
data class VaccinationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val flockName: String,
    val vaccineName: String,
    val targetAgeDays: Int,
    val scheduledDateLabel: String,
    val route: String, // "চোখে ১ ফোঁটা", "খাবার পানিতে", "ইনজেকশন"
    val doseInfo: String,
    val isCompleted: Boolean = false
)

@Entity(tableName = "daily_medicines")
data class DailyMedicineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val flockName: String,
    val ageDayLabel: String, // যেমন: "১ম - ৫ম দিন", "৮ম - ১২তম দিন", "প্রতিদিন (চলমান)"
    val medicineName: String, // যেমন: "লাইসোভিট + গ্লুকোজ", "ক্যালপ্লেক্স ও AD3E", "হেপাটোভেট (লিভার টনিক)"
    val timeOfDay: String, // "সকাল", "দুপুর", "রাত"
    val dosagePerLiter: String, // যেমন: "১ গ্রাম / ১ লিটার পানিতে"
    val purpose: String, // যেমন: "ব্রুডিং শক্তি ও স্ট্রেস কমানো", "ঠান্ডা ও শ্বাসকষ্ট রোধ", "দ্রুত ওজন বৃদ্ধি"
    val isGivenToday: Boolean = false
)

/**
 * পাল্লা ভিত্তিক ব্রয়লার মুরগি বিক্রির হিসাব (১৫/২০ টা করে মুরগি ওজন, ক্রেতার নাম, তারিখ, ওজন, পিস,
 * কত পাল্লা দিলাম, মোট কত কেজি হলো, গড় কত হলো)
 */
@Entity(tableName = "broiler_sales")
data class BroilerSaleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val buyerName: String,           // ক্রেতার নাম
    val saleDateLabel: String,       // বিক্রির তারিখ
    val shedName: String,            // কোন শেড / ব্যাচ থেকে বিক্রি
    val pallaCount: Int,             // মোট কত পাল্লা দিলাম
    val totalBirdsPieces: Int,       // মোট কত পিস মুরগি
    val totalWeightKg: Double,       // মোট কত কেজি হলো
    val avgWeightPerBirdKg: Double,  // গড় ওজন (প্রতি পিস মুরগি কত কেজি)
    val avgWeightPerPallaKg: Double, // গড় ওজন (প্রতি পাল্লায় কত কেজি)
    val pricePerKgBdt: Double,       // প্রতি কেজির দর (৳)
    val totalAmountBdt: Double,      // সর্বমোট বিক্রয় মূল্য (৳)
    val pallaBreakdownText: String,  // প্রতিটি পাল্লার আলাদা হিসাব ("পাল্লা-১: ২০ পিস • ৩৫.৪০ কেজি|পাল্লা-২: ১৮ পিস • ৩১.৮০ কেজি")
    val timestamp: Long = System.currentTimeMillis()
)
