package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PoultryDao {

    // Flocks
    @Query("SELECT * FROM flocks ORDER BY id DESC")
    fun getAllFlocks(): Flow<List<FlockEntity>>

    @Query("SELECT COUNT(*) FROM flocks")
    suspend fun getFlockCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFlock(flock: FlockEntity): Long

    @Update
    suspend fun updateFlock(flock: FlockEntity)

    @Delete
    suspend fun deleteFlock(flock: FlockEntity)

    // Daily Logs
    @Query("SELECT * FROM daily_logs ORDER BY timestamp DESC")
    fun getAllDailyLogs(): Flow<List<DailyLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyLog(log: DailyLogEntity): Long

    @Delete
    suspend fun deleteDailyLog(log: DailyLogEntity)

    // Finance Transactions
    @Query("SELECT * FROM finance_transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<FinanceTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: FinanceTransactionEntity): Long

    @Delete
    suspend fun deleteTransaction(transaction: FinanceTransactionEntity)

    // Vaccinations
    @Query("SELECT * FROM vaccinations ORDER BY isCompleted ASC, targetAgeDays ASC")
    fun getAllVaccinations(): Flow<List<VaccinationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaccination(vaccination: VaccinationEntity): Long

    @Update
    suspend fun updateVaccination(vaccination: VaccinationEntity)

    @Delete
    suspend fun deleteVaccination(vaccination: VaccinationEntity)

    // Daily Medicines (প্রতিদিনের ঔষধ শিডিউল)
    @Query("SELECT * FROM daily_medicines ORDER BY isGivenToday ASC, id ASC")
    fun getAllDailyMedicines(): Flow<List<DailyMedicineEntity>>

    @Query("SELECT COUNT(*) FROM daily_medicines")
    suspend fun getDailyMedicineCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyMedicine(medicine: DailyMedicineEntity): Long

    @Update
    suspend fun updateDailyMedicine(medicine: DailyMedicineEntity)

    @Delete
    suspend fun deleteDailyMedicine(medicine: DailyMedicineEntity)

    // Broiler Palla Sales (পাল্লা ধরে ইচ্ছেমতো পিস ও ওজন দিয়ে মুরগি বিক্রি)
    @Query("SELECT * FROM broiler_sales ORDER BY timestamp DESC")
    fun getAllBroilerSales(): Flow<List<BroilerSaleEntity>>

    @Query("SELECT COUNT(*) FROM broiler_sales")
    suspend fun getBroilerSaleCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBroilerSale(sale: BroilerSaleEntity): Long

    @Update
    suspend fun updateBroilerSale(sale: BroilerSaleEntity)

    @Delete
    suspend fun deleteBroilerSale(sale: BroilerSaleEntity)
}
