package com.example.data

import kotlinx.coroutines.flow.Flow
import java.util.Locale

class PoultryRepository(private val dao: PoultryDao) {

    val allFlocks: Flow<List<FlockEntity>> = dao.getAllFlocks()
    val allDailyLogs: Flow<List<DailyLogEntity>> = dao.getAllDailyLogs()
    val allTransactions: Flow<List<FinanceTransactionEntity>> = dao.getAllTransactions()
    val allVaccinations: Flow<List<VaccinationEntity>> = dao.getAllVaccinations()
    val allDailyMedicines: Flow<List<DailyMedicineEntity>> = dao.getAllDailyMedicines()
    val allBroilerSales: Flow<List<BroilerSaleEntity>> = dao.getAllBroilerSales()

    suspend fun insertFlock(flock: FlockEntity): Long = dao.insertFlock(flock)
    suspend fun updateFlock(flock: FlockEntity) = dao.updateFlock(flock)
    suspend fun deleteFlock(flock: FlockEntity) = dao.deleteFlock(flock)

    suspend fun recordDailyLog(log: DailyLogEntity, flock: FlockEntity?) {
        dao.insertDailyLog(log)
        if (flock != null) {
            val updatedCount = (flock.currentCount - log.mortalityCount).coerceAtLeast(0)
            val updatedFeed = flock.totalFeedConsumedKg + log.feedKg
            val updatedWeight = if (log.avgWeightGrams > 0) log.avgWeightGrams else flock.avgWeightGrams
            dao.updateFlock(
                flock.copy(
                    currentCount = updatedCount,
                    totalFeedConsumedKg = updatedFeed,
                    avgWeightGrams = updatedWeight,
                    ageInDays = flock.ageInDays + 1
                )
            )
        }
    }

    suspend fun deleteDailyLog(log: DailyLogEntity) = dao.deleteDailyLog(log)

    suspend fun insertTransaction(transaction: FinanceTransactionEntity) =
        dao.insertTransaction(transaction)

    suspend fun deleteTransaction(transaction: FinanceTransactionEntity) =
        dao.deleteTransaction(transaction)

    suspend fun insertVaccination(vaccination: VaccinationEntity) =
        dao.insertVaccination(vaccination)

    suspend fun toggleVaccination(vaccination: VaccinationEntity) =
        dao.updateVaccination(vaccination.copy(isCompleted = !vaccination.isCompleted))

    suspend fun deleteVaccination(vaccination: VaccinationEntity) =
        dao.deleteVaccination(vaccination)

    suspend fun insertDailyMedicine(medicine: DailyMedicineEntity) =
        dao.insertDailyMedicine(medicine)

    suspend fun toggleDailyMedicine(medicine: DailyMedicineEntity) =
        dao.updateDailyMedicine(medicine.copy(isGivenToday = !medicine.isGivenToday))

    suspend fun deleteDailyMedicine(medicine: DailyMedicineEntity) =
        dao.deleteDailyMedicine(medicine)

    /**
     * পাল্লা ভিত্তিক মুরগি বিক্রি সংরক্ষণ বা কাস্টমাইজ/এডিট করে এবং বিক্রি খাতায় যুক্ত করে
     */
    suspend fun saveOrUpdateBroilerPallaSale(sale: BroilerSaleEntity, isEdit: Boolean) {
        dao.insertBroilerSale(sale)
        val weightStr = String.format(Locale.US, "%.2f", sale.totalWeightKg)
        val avgBirdStr = String.format(Locale.US, "%.2f", sale.avgWeightPerBirdKg)
        val rateStr = String.format(Locale.US, "%.0f", sale.pricePerKgBdt)
        if (!isEdit) {
            dao.insertTransaction(
                FinanceTransactionEntity(
                    title = "${sale.shedName} মুরগি বিক্রি (${sale.pallaCount} পাল্লা • ${sale.totalBirdsPieces} পিস)",
                    category = "মুরগি বিক্রি",
                    isIncome = true,
                    amountBdt = sale.totalAmountBdt,
                    quantityNote = "${sale.pallaCount} পাল্লা • ${sale.totalBirdsPieces} পিস • $weightStr কেজি (গড় $avgBirdStr কেজি) @ ৳$rateStr/কেজি",
                    dateLabel = sale.saleDateLabel,
                    partyName = sale.buyerName,
                    timestamp = sale.timestamp
                )
            )
        }
    }

    suspend fun deleteBroilerSale(sale: BroilerSaleEntity) =
        dao.deleteBroilerSale(sale)

    suspend fun seedIfEmpty() {
        if (dao.getFlockCount() > 0 && dao.getDailyMedicineCount() > 0 && dao.getBroilerSaleCount() > 0) return

        if (dao.getFlockCount() == 0) {
            val flock1Id = dao.insertFlock(
                FlockEntity(
                    name = "কব-৫০০ ফিনিশার ব্যাচ #১৪",
                    shedNumber = "শেড-০১ (উত্তর)",
                    breed = "কব-৫০০ (Cobb-500)",
                    initialCount = 2000,
                    currentCount = 1948,
                    ageInDays = 26,
                    targetSaleDays = 32,
                    avgWeightGrams = 1580,
                    totalFeedConsumedKg = 4550.0,
                    chickPricePerBird = 48.0,
                    startDateLabel = "০২ সেপ্টেম্বর ২০২৬",
                    hatcheryName = "কাজী হ্যাচারি (A-Grade)",
                    notes = "ফিনিশার পেলেট ফিড চলছে। গড় ওজন ১.৫৮ কেজি, ৩০-৩২ দিনে বিক্রির লক্ষ্যমাত্রা।"
                )
            )

            val flock2Id = dao.insertFlock(
                FlockEntity(
                    name = "রস-৩০৮ গ্রোয়ার ব্যাচ #১৫",
                    shedNumber = "শেড-০২ (মধ্যম)",
                    breed = "রস-৩০৮ (Ross-308)",
                    initialCount = 1500,
                    currentCount = 1472,
                    ageInDays = 16,
                    targetSaleDays = 30,
                    avgWeightGrams = 670,
                    totalFeedConsumedKg = 1320.0,
                    chickPricePerBird = 50.0,
                    startDateLabel = "১২ সেপ্টেম্বর ২০২৬",
                    hatcheryName = "সিপি (CP) হ্যাচারি",
                    notes = "গ্রোয়ার ক্রাম্বল ফিড ও লিভার টনিক চলছে। বৃদ্ধি আদর্শ মানের চেয়ে ভালো।"
                )
            )

            val flock3Id = dao.insertFlock(
                FlockEntity(
                    name = "হাবার্ড ব্রুডিং ব্যাচ #১৬",
                    shedNumber = "শেড-০৩ (দক্ষিণ)",
                    breed = "হাবার্ড (Hubbard)",
                    initialCount = 1200,
                    currentCount = 1190,
                    ageInDays = 6,
                    targetSaleDays = 32,
                    avgWeightGrams = 165,
                    totalFeedConsumedKg = 210.0,
                    chickPricePerBird = 46.0,
                    startDateLabel = "২২ সেপ্টেম্বর ২০২৬",
                    hatcheryName = "নাহার এগ্রো হ্যাচারি",
                    notes = "ব্রুডিং তাপমাত্রা ৩২°C। প্রি-স্টার্টার ফিড এবং গ্লুকোজ-লাইসোভিট চলছে।"
                )
            )

            // Seed Broiler Daily Logs
            dao.insertDailyLog(
                DailyLogEntity(
                    flockId = flock1Id,
                    flockName = "কব-৫০০ ফিনিশার ব্যাচ #১৪ (শেড-০১)",
                    dateLabel = "আজ • ২৭ সেপ্টেম্বর",
                    feedPhase = "ফিনিশার পেলেট",
                    mortalityCount = 2,
                    feedKg = 275.0,
                    waterLiters = 560.0,
                    avgWeightGrams = 1580,
                    medicineGiven = "নেফ্রোকেয়ার ও ইলেকট্রোলাইট (দুপুরের পানিতে)",
                    remarks = "খাবার গ্রহণ ও ওজন বৃদ্ধি চমৎকার, শেডের পর্দা নামানো আছে",
                    timestamp = System.currentTimeMillis() - 3_600_000L
                )
            )

            dao.insertDailyLog(
                DailyLogEntity(
                    flockId = flock2Id,
                    flockName = "রস-৩০৮ গ্রোয়ার ব্যাচ #১৫ (শেড-০২)",
                    dateLabel = "আজ • ২৭ সেপ্টেম্বর",
                    feedPhase = "গ্রোয়ার ক্রাম্বল",
                    mortalityCount = 1,
                    feedKg = 140.0,
                    waterLiters = 290.0,
                    avgWeightGrams = 670,
                    medicineGiven = "ক্যালপ্লেক্স ও ভিটামিন AD3E (সকালের পানিতে)",
                    remarks = "কাঠের গুঁড়া (লিটার) নাড়াচাড়া ও চুন ছিটানো হয়েছে",
                    timestamp = System.currentTimeMillis() - 7_200_000L
                )
            )

            dao.insertDailyLog(
                DailyLogEntity(
                    flockId = flock3Id,
                    flockName = "হাবার্ড ব্রুডিং ব্যাচ #১৬ (শেড-০৩)",
                    dateLabel = "আজ • ২৭ সেপ্টেম্বর",
                    feedPhase = "প্রি-স্টার্টার",
                    mortalityCount = 0,
                    feedKg = 46.0,
                    waterLiters = 95.0,
                    avgWeightGrams = 165,
                    medicineGiven = "লাইসোভিট ও ভিটামিন সি (সকাল ও রাতের পানিতে)",
                    remarks = "৫ম দিনের রানীক্ষেত (BCRDV) টিকা সফলভাবে সম্পন্ন",
                    timestamp = System.currentTimeMillis() - 18_000_000L
                )
            )

            // Seed Finance Transactions
            dao.insertTransaction(
                FinanceTransactionEntity(
                    title = "শেড-০১ মুরগি বিক্রি (৬ পাল্লা • ১০৮ পিস)",
                    category = "মুরগি বিক্রি",
                    isIncome = true,
                    amountBdt = 34452.0,
                    quantityNote = "৬ পাল্লা • ১০৮ পিস • ১৯১.৪০ কেজি (গড় ১.৭৭ কেজি) @ ৳১৮০/কেজি",
                    dateLabel = "২৭ সেপ্টেম্বর ২০২৬",
                    partyName = "বিসমিল্লাহ পোল্ট্রি আড়ত (হাজী করিম)",
                    timestamp = System.currentTimeMillis() - 2_400_000L
                )
            )
            dao.insertTransaction(
                FinanceTransactionEntity(
                    title = "শেড-০১ মুরগি বিক্রি (৫ পাল্লা • ৯০ পিস)",
                    category = "মুরগি বিক্রি",
                    isIncome = true,
                    amountBdt = 28152.0,
                    quantityNote = "৫ পাল্লা • ৯০ পিস • ১৫৬.৪০ কেজি (গড় ১.৭৪ কেজি) @ ৳১৮০/কেজি",
                    dateLabel = "২৬ সেপ্টেম্বর ২০২৬",
                    partyName = "আল-মদিনা ব্রয়লার সাপ্লাই (জসিম পাইকার)",
                    timestamp = System.currentTimeMillis() - 45_000_000L
                )
            )

            dao.insertTransaction(
                FinanceTransactionEntity(
                    title = "খুচরা মুরগি বিক্রি (২৮ পিস • ৪৫.০০ কেজি)",
                    category = "খুচরা মুরগি বিক্রি",
                    isIncome = true,
                    amountBdt = 8550.0,
                    quantityNote = "28 পিস~45.00 কেজি~1.61 কেজি/পিস~স্থানীয় বাজার নগদ",
                    dateLabel = "২৭ সেপ্টেম্বর ২০২৬",
                    partyName = "স্থানীয় বাজার ও প্রতিবেশী ক্রেতা",
                    timestamp = System.currentTimeMillis() - 4_500_000L
                )
            )

            dao.insertTransaction(
                FinanceTransactionEntity(
                    title = "ফিড বিক্রি (৪ বস্তা • ২০০.০০ কেজি)",
                    category = "ফিড বিক্রি",
                    isIncome = true,
                    amountBdt = 13800.0,
                    quantityNote = "4 বস্তা~200.00 কেজি~50.00 কেজি/বস্তা~স্টার্টার ফিড নগদ",
                    dateLabel = "২৫ সেপ্টেম্বর ২০২৬",
                    partyName = "রহমান পোল্ট্রি খামার (পাশের খামার)",
                    timestamp = System.currentTimeMillis() - 22_000_000L
                )
            )

            dao.insertTransaction(
                FinanceTransactionEntity(
                    title = "কাঠের গুঁড়া বা লিটার বিক্রি (১২০ বস্তা • ৩৬০০ কেজি)",
                    category = "কাঠের গুঁড়া বা লিটার বিক্রি",
                    isIncome = true,
                    amountBdt = 9600.0,
                    quantityNote = "120 বস্তা~3600.00 কেজি~30.00 কেজি/বস্তা~শেড-১ এর জৈব সার",
                    dateLabel = "২৪ সেপ্টেম্বর ২০২৬",
                    partyName = "সবুজ নার্সারি ও মাছের প্রজেক্ট",
                    timestamp = System.currentTimeMillis() - 36_000_000L
                )
            )

            dao.insertTransaction(
                FinanceTransactionEntity(
                    title = "বাচ্চা কেনা (৩৫০০ পিস • ৳১,৭১,০০০)",
                    category = "বাচ্চা কেনা",
                    isIncome = false,
                    amountBdt = 171000.0,
                    quantityNote = "3500 পিস~৳1,71,000~৳49/পিস~কব-৫০০ ও রস-৩০৮",
                    dateLabel = "১২ সেপ্টেম্বর ২০২৬",
                    partyName = "কাজী ও সিপি হ্যাচারি ডিলার",
                    timestamp = System.currentTimeMillis() - 80_000_000L
                )
            )
            dao.insertTransaction(
                FinanceTransactionEntity(
                    title = "বাচ্চা কেনা (১২০০ পিস • ৳৫৫,২০০)",
                    category = "বাচ্চা কেনা",
                    isIncome = false,
                    amountBdt = 55200.0,
                    quantityNote = "1200 পিস~৳55,200~৳46/পিস~হাবার্ড A-গ্রেড",
                    dateLabel = "২২ সেপ্টেম্বর ২০২৬",
                    partyName = "নাহার এগ্রো হ্যাচারি",
                    timestamp = System.currentTimeMillis() - 60_000_000L
                )
            )

            dao.insertTransaction(
                FinanceTransactionEntity(
                    title = "ফিড কেনা (৬০ বস্তা • ৩০০০.০০ কেজি)",
                    category = "ফিড কেনা",
                    isIncome = false,
                    amountBdt = 201000.0,
                    quantityNote = "60 বস্তা~3000.00 কেজি~50.00 কেজি/বস্তা~গ্রোয়ার ও ফিনিশার",
                    dateLabel = "২৬ সেপ্টেম্বর ২০২৬",
                    partyName = "মেসার্স ভাই ভাই ফিড ট্রেডার্স",
                    timestamp = System.currentTimeMillis() - 10_800_000L
                )
            )

            dao.insertTransaction(
                FinanceTransactionEntity(
                    title = "কাঠের গুঁড়া কেনা (১০০ বস্তা • ২৫০০.০০ কেজি)",
                    category = "কাঠের গুঁড়া কেনা",
                    isIncome = false,
                    amountBdt = 14500.0,
                    quantityNote = "100 বস্তা~2500.00 কেজি~25.00 কেজি/বস্তা~শুকনো কাঠের গুঁড়া",
                    dateLabel = "২১ সেপ্টেম্বর ২০২৬",
                    partyName = "সোনার বাংলা স-মিল ও টিম্বার্স",
                    timestamp = System.currentTimeMillis() - 48_000_000L
                )
            )

            dao.insertTransaction(
                FinanceTransactionEntity(
                    title = "কর্মচারী বেতন (৩ জন • ৳২৮,০০০)",
                    category = "কর্মচারী বেতন",
                    isIncome = false,
                    amountBdt = 28000.0,
                    quantityNote = "3 জন~৳28,000~৳9333/জন~সেপ্টেম্বর মাসিক বেতন",
                    dateLabel = "২৫ সেপ্টেম্বর ২০২৬",
                    partyName = "রফিকুল ইসলাম, সুমন ও করিম",
                    timestamp = System.currentTimeMillis() - 30_000_000L
                )
            )

            dao.insertTransaction(
                FinanceTransactionEntity(
                    title = "পরিবহন ব্যয় বা ভাড়া (৩ ট্রিপ • ৳৬,৫০০)",
                    category = "পরিবহন ব্যয় বা ভাড়া",
                    isIncome = false,
                    amountBdt = 6500.0,
                    quantityNote = "3 ট্রিপ~৳6,500~৳2167/ট্রিপ~ফিড ও বাচ্চা পরিবহন",
                    dateLabel = "২৬ সেপ্টেম্বর ২০২৬",
                    partyName = "মায়ের দোয়া পরিবহন সার্ভিস",
                    timestamp = System.currentTimeMillis() - 15_000_000L
                )
            )

            dao.insertTransaction(
                FinanceTransactionEntity(
                    title = "মেডিসিন কেনা (১০ ইউনিট • ৳১২,৪০০)",
                    category = "মেডিসিন কেনা",
                    isIncome = false,
                    amountBdt = 12400.0,
                    quantityNote = "10 ইউনিট~৳12,400~৳1240/ইউনিট~ভ্যাকসিন ও লিভার টনিক",
                    dateLabel = "২৩ সেপ্টেম্বর ২০২৬",
                    partyName = "পপুলার ভেট ফার্মা",
                    timestamp = System.currentTimeMillis() - 40_000_000L
                )
            )

            dao.insertTransaction(
                FinanceTransactionEntity(
                    title = "অন্যান্য খরচ (২ ইউনিট • ৳৭,৮০০)",
                    category = "অন্যান্য খরচ",
                    isIncome = false,
                    amountBdt = 7800.0,
                    quantityNote = "2 ইউনিট~৳7,800~৳3900/ইউনিট~বিদ্যুৎ বিল ও ব্রুডার গ্যাস",
                    dateLabel = "২০ সেপ্টেম্বর ২০২৬",
                    partyName = "পল্লী বিদ্যুৎ ও যমুনা গ্যাস",
                    timestamp = System.currentTimeMillis() - 52_000_000L
                )
            )

            // Seed Broiler Vaccinations
            dao.insertVaccination(
                VaccinationEntity(
                    flockName = "হাবার্ড ব্রুডিং ব্যাচ #১৬ (শেড-০৩)",
                    vaccineName = "গামবোরো ১ম ডোজ (IBD Intermediate)",
                    targetAgeDays = 10,
                    scheduledDateLabel = "০১ অক্টোবর ২০২৬",
                    route = "চোখে ১ ফোঁটা বা ঠান্ডা পানিতে",
                    doseInfo = "১,২০০ ডোজ ভায়াল (বরফ পানিতে সংরক্ষণ)",
                    isCompleted = false
                )
            )

            dao.insertVaccination(
                VaccinationEntity(
                    flockName = "রস-৩০৮ গ্রোয়ার ব্যাচ #১৫ (শেড-০২)",
                    vaccineName = "গামবোরো বুস্টার ডোজ (IBD Plus)",
                    targetAgeDays = 17,
                    scheduledDateLabel = "২৮ সেপ্টেম্বর ২০২৬ (আগামীকাল)",
                    route = "খাবার পানিতে (২ ঘন্টা পানি বন্ধ রেখে)",
                    doseInfo = "১,৫০০ ডোজ • স্কিম মিল্ক পাউডারসহ",
                    isCompleted = false
                )
            )

            dao.insertVaccination(
                VaccinationEntity(
                    flockName = "রস-৩০৮ গ্রোয়ার ব্যাচ #১৫ (শেড-০২)",
                    vaccineName = "রানীক্ষেত লাসোটা বুস্টার (ND LaSota)",
                    targetAgeDays = 21,
                    scheduledDateLabel = "০২ অক্টোবর ২০২৬",
                    route = "খাবার পানিতে",
                    doseInfo = "১,৫০০ ডোজ",
                    isCompleted = false
                )
            )

            dao.insertVaccination(
                VaccinationEntity(
                    flockName = "হাবার্ড ব্রুডিং ব্যাচ #১৬ (শেড-০৩)",
                    vaccineName = "রানীক্ষেত + ব্রংকাইটিস (BCRDV + IB)",
                    targetAgeDays = 5,
                    scheduledDateLabel = "২৬ সেপ্টেম্বর ২০২৬",
                    route = "চোখে ১ ফোঁটা করে",
                    doseInfo = "১,২০০ ডোজ (সম্পন্ন)",
                    isCompleted = true
                )
            )
        }

        // Seed Daily Medicine Schedule (প্রতিদিনের ঔষধ শিডিউল)
        if (dao.getDailyMedicineCount() == 0) {
            dao.insertDailyMedicine(
                DailyMedicineEntity(
                    flockName = "শেড-০৩ (হাবার্ড ব্রুডিং - ৬ দিন)",
                    ageDayLabel = "১ম – ৭ম দিন (ব্রুডিং কোর্স)",
                    medicineName = "লাইসোভিট + গ্লুকোজ + ভিটামিন সি",
                    timeOfDay = "সকাল",
                    dosagePerLiter = "১ গ্রাম / ১ লিটার পানিতে",
                    purpose = "বাচ্চার ব্রুডিং ধকল কাটানো ও রোগ প্রতিরোধ ক্ষমতা বৃদ্ধি",
                    isGivenToday = true
                )
            )
            dao.insertDailyMedicine(
                DailyMedicineEntity(
                    flockName = "শেড-০২ (রস-৩০৮ গ্রোয়ার - ১৬ দিন)",
                    ageDayLabel = "১৪তম – ১৮তম দিন (গ্রোথ কোর্স)",
                    medicineName = "ক্যালপ্লেক্স (ক্যালসিয়াম) + ভিটামিন AD3E",
                    timeOfDay = "সকাল",
                    dosagePerLiter = "২ মি.লি. / ১ লিটার পানিতে",
                    purpose = "দ্রুত দৈহিক ওজন বৃদ্ধি ও পায়ের হাড় মজবুত করা",
                    isGivenToday = true
                )
            )
            dao.insertDailyMedicine(
                DailyMedicineEntity(
                    flockName = "শেড-০১ (কব-৫০০ ফিনিশার - ২৬ দিন)",
                    ageDayLabel = "২২তম – ৩০তম দিন (ফিনিশার কোর্স)",
                    medicineName = "নেফ্রোকেয়ার (কিডনি টনিক) + ইলেকট্রোলাইট",
                    timeOfDay = "দুপুর",
                    dosagePerLiter = "১.৫ মি.লি. / ১ লিটার পানিতে",
                    purpose = "হিট স্ট্রেস কমানো ও ফিনিশার মুরগির কিডনি/গাউট সুরক্ষা",
                    isGivenToday = false
                )
            )
            dao.insertDailyMedicine(
                DailyMedicineEntity(
                    flockName = "শেড-০২ (রস-৩০৮ গ্রোয়ার - ১৬ দিন)",
                    ageDayLabel = "১৫তম – ২০তম দিন (হজম ও লিভার কোর্স)",
                    medicineName = "হেপাটোভেট (লিভার টনিক) + জাইমভেট",
                    timeOfDay = "রাত",
                    dosagePerLiter = "১ মি.লি. / ১ লিটার পানিতে",
                    purpose = "খাবার হজম বৃদ্ধি ও FCR কমানো",
                    isGivenToday = false
                )
            )
            dao.insertDailyMedicine(
                DailyMedicineEntity(
                    flockName = "শেড-০১ ও শেড-০২ (সকল শেড)",
                    ageDayLabel = "প্রতিদিন রাতের পানি (শ্বাসতন্ত্র সুরক্ষা)",
                    medicineName = "তুর্কি-প্লাস / ব্রঙ্কোভেট (হারবাল কফ সিরাপ)",
                    timeOfDay = "রাত",
                    dosagePerLiter = "১ মি.লি. / ২ লিটার পানিতে",
                    purpose = "রাতের ঠান্ডা ও ফোঁড়-ফোঁড় শব্দ প্রতিরোধ",
                    isGivenToday = false
                )
            )
        }

        // Seed Broiler Palla Sales (১ম ঘর: পিস | ২য় ঘর: ওজন | ৩য় ঘর: গড় অটো | ৪র্থ ঘর: মন্তব্য)
        if (dao.getBroilerSaleCount() == 0) {
            dao.insertBroilerSale(
                BroilerSaleEntity(
                    buyerName = "বিসমিল্লাহ পোল্ট্রি আড়ত (হাজী করিম)",
                    saleDateLabel = "২৭ সেপ্টেম্বর ২০২৬",
                    shedName = "শেড-০১ (কব-৫০০ ব্যাচ #১৪)",
                    pallaCount = 6,
                    totalBirdsPieces = 108,
                    totalWeightKg = 191.40,
                    avgWeightPerBirdKg = 1.772,
                    avgWeightPerPallaKg = 31.90,
                    pricePerKgBdt = 180.0,
                    totalAmountBdt = 34452.0,
                    pallaBreakdownText = listOf(
                        "পাল্লা-1~20~35.60~1.78~১ নং খাঁচা বড় সাইজ",
                        "পাল্লা-2~18~32.10~1.78~২ নং খাঁচা",
                        "পাল্লা-3~18~31.80~1.77~৩ নং খাঁচা",
                        "পাল্লা-4~17~30.20~1.78~৪ নং খাঁচা",
                        "পাল্লা-5~20~35.40~1.77~৫ নং খাঁচা",
                        "পাল্লা-6~15~26.30~1.75~শেষ পাল্লা"
                    ).joinToString("|"),
                    timestamp = System.currentTimeMillis() - 2_400_000L
                )
            )

            dao.insertBroilerSale(
                BroilerSaleEntity(
                    buyerName = "আল-মদিনা ব্রয়লার সাপ্লাই (জসিম পাইকার)",
                    saleDateLabel = "২৬ সেপ্টেম্বর ২০২৬",
                    shedName = "শেড-০১ (কব-৫০০ ব্যাচ #১৪)",
                    pallaCount = 5,
                    totalBirdsPieces = 90,
                    totalWeightKg = 156.40,
                    avgWeightPerBirdKg = 1.738,
                    avgWeightPerPallaKg = 31.28,
                    pricePerKgBdt = 180.0,
                    totalAmountBdt = 28152.0,
                    pallaBreakdownText = listOf(
                        "পাল্লা-1~20~34.80~1.74~সকালের গাড়ি",
                        "পাল্লা-2~18~31.40~1.74~ভালো গ্রেড",
                        "পাল্লা-3~17~29.50~1.74~মাঝারি সাইজ",
                        "পাল্লা-4~20~34.90~1.75~খাঁচা-৪",
                        "পাল্লা-5~15~25.80~1.72~নগদ পরিশোধ"
                    ).joinToString("|"),
                    timestamp = System.currentTimeMillis() - 45_000_000L
                )
            )
        }
    }
}
