package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        FlockEntity::class,
        DailyLogEntity::class,
        FinanceTransactionEntity::class,
        VaccinationEntity::class,
        DailyMedicineEntity::class,
        BroilerSaleEntity::class
    ],
    version = 6,
    exportSchema = false
)
abstract class PoultryDatabase : RoomDatabase() {
    abstract fun poultryDao(): PoultryDao

    companion object {
        @Volatile
        private var INSTANCE: PoultryDatabase? = null

        fun getDatabase(context: Context): PoultryDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PoultryDatabase::class.java,
                    "brothers_poultry_db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
