package com.example.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.BroilerSaleEntity
import com.example.data.DailyLogEntity
import com.example.data.DailyMedicineEntity
import com.example.data.FinanceTransactionEntity
import com.example.data.FlockEntity
import com.example.data.PoultryDatabase
import com.example.data.PoultryRepository
import com.example.data.VaccinationEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class FcrCalculationResult(
    val totalLiveWeightKg: Double = 0.0,
    val fcr: Double = 0.0,
    val totalProductionCostBdt: Double = 0.0,
    val costPerKgMeatBdt: Double = 0.0,
    val estimatedRevenueBdt: Double = 0.0,
    val estimatedProfitBdt: Double = 0.0,
    val profitPerBirdBdt: Double = 0.0
)

data class PoultryUiState(
    val customAppName: String = "ব্রয়লার খামার হিসাব",
    val flocks: List<FlockEntity> = emptyList(),
    val dailyLogs: List<DailyLogEntity> = emptyList(),
    val transactions: List<FinanceTransactionEntity> = emptyList(),
    val allTransactionsUnfiltered: List<FinanceTransactionEntity> = emptyList(),
    val vaccinations: List<VaccinationEntity> = emptyList(),
    val dailyMedicines: List<DailyMedicineEntity> = emptyList(),
    val broilerSales: List<BroilerSaleEntity> = emptyList(),
    val selectedBreedFilter: String = "সব জাত",
    val selectedFinanceFilter: String = "সব লেনদেন",
    val searchQuery: String = "",
    // Broiler KPIs & Mortality (মৃত্যু হার)
    val totalActiveBirds: Int = 0,
    val totalInitialBirds: Int = 0,
    val totalDeadBirds: Int = 0,
    val todayDeadBirds: Int = 0,
    val overallMortalityRatePercent: Double = 0.0,
    val totalFeedConsumedKg: Double = 0.0,
    val totalFeedBagsConsumed: Double = 0.0,
    val totalEstimatedLiveWeightKg: Double = 0.0,
    val averageWeightGrams: Int = 0,
    val overallFcr: Double = 0.0,
    // Total Income & Expenses
    val totalIncomeBdt: Double = 0.0,
    val totalExpenseBdt: Double = 0.0,
    val netProfitBdt: Double = 0.0,
    // সকল ব্যয় আলাদা (৭টি খাত: বাচ্চা কেনা, ফিড কেনা, মেডিসিন কেনা, কাঠের গুঁড়া কেনা, পরিবহন ব্যয় বা ভাড়া, কর্মচারী বেতন, অন্যান্য খরচ)
    val costPerLiveBirdBdt: Double = 0.0,
    val costPerLiveKgBdt: Double = 0.0,
    val chickPurchaseExpenseBdt: Double = 0.0,
    val feedPurchaseExpenseBdt: Double = 0.0,
    val medicineVaccineExpenseBdt: Double = 0.0,
    val sawdustPurchaseExpenseBdt: Double = 0.0,
    val transportFareExpenseBdt: Double = 0.0,
    val employeeSalaryExpenseBdt: Double = 0.0,
    val utilityOtherExpenseBdt: Double = 0.0,
    // সকল আয় আলাদা (মুরগি বিক্রি, ফিড বিক্রি, কাঠের গুঁড়া বা লিটার বিক্রি)
    val chickenSalesTotalBdt: Double = 0.0,
    val mainBroilerSalesBdt: Double = 0.0,
    val retailChickenSalesBdt: Double = 0.0,
    val feedSalesBdt: Double = 0.0,
    val litterSawdustSalesBdt: Double = 0.0,
    val totalOtherSalesBdt: Double = 0.0,
    val totalSalePallaCount: Int = 0,
    val totalSoldBirdsPieces: Int = 0,
    val totalSoldWeightKg: Double = 0.0,
    val overallSoldAvgWeightPerBirdKg: Double = 0.0,
    val overallSoldAvgWeightPerPallaKg: Double = 0.0,
    // Alerts
    val pendingVaccinationCount: Int = 0,
    val pendingDailyMedicineCount: Int = 0
)

private data class CoreDataBundle(
    val flocks: List<FlockEntity>,
    val logs: List<DailyLogEntity>,
    val transactions: List<FinanceTransactionEntity>,
    val vaccinations: List<VaccinationEntity>,
    val dailyMedicines: List<DailyMedicineEntity>,
    val broilerSales: List<BroilerSaleEntity>
)

class PoultryViewModel(
    private val repository: PoultryRepository,
    appContext: Context
) : ViewModel() {

    private val prefs = appContext.getSharedPreferences("poultry_app_prefs", Context.MODE_PRIVATE)
    private val _customAppName = MutableStateFlow(
        prefs.getString("custom_app_name", "ব্রয়লার খামার হিসাব") ?: "ব্রয়লার খামার হিসাব"
    )
    private val _selectedBreedFilter = MutableStateFlow("সব জাত")
    private val _selectedFinanceFilter = MutableStateFlow("সব লেনদেন")
    private val _searchQuery = MutableStateFlow("")

    private val _fcrResult = MutableStateFlow(
        calculateBroilerFcr(
            birdCount = 1948,
            avgWeightGrams = 1580.0,
            totalFeedKg = 4550.0,
            feedBagPrice50Kg = 3350.0,
            chickCostPerBird = 48.0,
            medicineAndOtherCost = 28500.0,
            expectedSalePricePerKg = 180.0
        )
    )
    val fcrResult: StateFlow<FcrCalculationResult> = _fcrResult

    init {
        viewModelScope.launch {
            repository.seedIfEmpty()
        }
    }

    fun updateAppName(newName: String) {
        val trimmed = newName.trim().ifBlank { "ব্রয়লার খামার হিসাব" }
        prefs.edit().putString("custom_app_name", trimmed).apply()
        _customAppName.value = trimmed
    }

    private val firstFiveFlow = combine(
        repository.allFlocks,
        repository.allDailyLogs,
        repository.allTransactions,
        repository.allVaccinations,
        repository.allDailyMedicines
    ) { flocks, logs, transactions, vaccinations, dailyMedicines ->
        CoreDataBundle(flocks, logs, transactions, vaccinations, dailyMedicines, emptyList())
    }

    private val coreDataFlow = combine(
        firstFiveFlow,
        repository.allBroilerSales
    ) { bundle, broilerSales ->
        bundle.copy(broilerSales = broilerSales)
    }

    val uiState: StateFlow<PoultryUiState> = combine(
        coreDataFlow,
        _selectedBreedFilter,
        _selectedFinanceFilter,
        _searchQuery,
        _customAppName
    ) { core, breedFilter, financeFilter, query, appName ->
        val flocks = core.flocks
        val logs = core.logs
        val transactions = core.transactions
        val vaccinations = core.vaccinations
        val dailyMedicines = core.dailyMedicines
        val broilerSales = core.broilerSales

        val activeFlocks = flocks.filter { it.isActive }
        val totalActive = activeFlocks.sumOf { it.currentCount }
        val totalInitial = activeFlocks.sumOf { it.initialCount }
        val totalDead = (totalInitial - totalActive).coerceAtLeast(0)
        val todayDead = logs.take(3).filter { it.dateLabel.contains("আজ") }.sumOf { it.mortalityCount }
        val mortalityRate = if (totalInitial > 0) {
            (totalDead.toDouble() / totalInitial.toDouble()) * 100.0
        } else {
            0.0
        }

        val totalFeedKg = activeFlocks.sumOf { it.totalFeedConsumedKg }
        val totalFeedBags = totalFeedKg / 50.0
        val totalLiveWeightKg = activeFlocks.sumOf { (it.currentCount * it.avgWeightGrams) / 1000.0 }
        val weightedAvgWeightGrams = if (totalActive > 0) {
            (activeFlocks.sumOf { it.currentCount * it.avgWeightGrams } / totalActive)
        } else {
            0
        }
        val overallFcr = if (totalLiveWeightKg > 0.0) {
            totalFeedKg / totalLiveWeightKg
        } else {
            0.0
        }

        // Income & Expense Calculations
        val income = transactions.filter { it.isIncome }.sumOf { it.amountBdt }
        val expense = transactions.filter { !it.isIncome }.sumOf { it.amountBdt }

        // ৭টি আলাদা ব্যয়ের খাত (বাচ্চা কেনা, ফিড কেনা, মেডিসিন কেনা, কাঠের গুঁড়া কেনা, পরিবহন ব্যয় বা ভাড়া, কর্মচারী বেতন, অন্যান্য খরচ)
        val chickExpense = transactions.filter {
            !it.isIncome && (it.category == "বাচ্চা কেনা" || it.category == "বাচ্চা ক্রয়")
        }.sumOf { it.amountBdt }

        val feedExpense = transactions.filter {
            !it.isIncome && (it.category == "ফিড কেনা" || it.category == "ফিড ক্রয়")
        }.sumOf { it.amountBdt }

        val medicineExpense = transactions.filter {
            !it.isIncome && (it.category == "মেডিসিন কেনা" || it.category == "ওষুধ ও টিকা")
        }.sumOf { it.amountBdt }

        val sawdustExpense = transactions.filter {
            !it.isIncome && it.category == "কাঠের গুঁড়া কেনা"
        }.sumOf { it.amountBdt }

        val transportExpense = transactions.filter {
            !it.isIncome && (it.category == "পরিবহন ব্যয় বা ভাড়া" || it.category == "যাতায়াত ভাড়া")
        }.sumOf { it.amountBdt }

        val salaryExpense = transactions.filter {
            !it.isIncome && it.category == "কর্মচারী বেতন"
        }.sumOf { it.amountBdt }

        val utilityExpense = transactions.filter {
            !it.isIncome && (it.category == "অন্যান্য খরচ" || it.category == "বিদ্যুৎ ও অন্যান্য")
        }.sumOf { it.amountBdt }

        val costPerBird = if (totalActive > 0) expense / totalActive.toDouble() else 0.0
        val costPerKg = if (totalLiveWeightKg > 0.0) expense / totalLiveWeightKg else 0.0

        // ৩টি আলাদা আয়ের খাত (মুরগি বিক্রি, ফিড বিক্রি, কাঠের গুঁড়া বা লিটার বিক্রি)
        val mainBroilerSales = transactions.filter {
            it.isIncome && it.category == "মুরগি বিক্রি"
        }.sumOf { it.amountBdt }

        val retailChickenSales = transactions.filter {
            it.isIncome && it.category == "খুচরা মুরগি বিক্রি"
        }.sumOf { it.amountBdt }

        val chickenSalesTotal = mainBroilerSales + retailChickenSales

        val feedSales = transactions.filter {
            it.isIncome && it.category == "ফিড বিক্রি"
        }.sumOf { it.amountBdt }

        val litterSales = transactions.filter {
            it.isIncome && (
                it.category == "কাঠের গুঁড়া বা লিটার বিক্রি" ||
                    it.category == "লিটার/ব্যবহৃত গুঁড়া বিক্রি" ||
                    it.category == "লিটার/সার বিক্রি"
                )
        }.sumOf { it.amountBdt }

        val totalOtherSales = retailChickenSales + feedSales + litterSales

        // Palla Sale Aggregate Metrics
        val totalPallaCount = broilerSales.sumOf { it.pallaCount }
        val totalSoldPieces = broilerSales.sumOf { it.totalBirdsPieces }
        val totalSoldKg = broilerSales.sumOf { it.totalWeightKg }
        val overallAvgPerBirdKg = if (totalSoldPieces > 0) totalSoldKg / totalSoldPieces.toDouble() else 0.0
        val overallAvgPerPallaKg = if (totalPallaCount > 0) totalSoldKg / totalPallaCount.toDouble() else 0.0

        val filteredFlocks = flocks.filter { flock ->
            val matchesBreed = breedFilter == "সব জাত" || flock.breed.contains(breedFilter, ignoreCase = true)
            val matchesQuery = query.isBlank() ||
                flock.name.contains(query, ignoreCase = true) ||
                flock.shedNumber.contains(query, ignoreCase = true) ||
                flock.breed.contains(query, ignoreCase = true) ||
                flock.startDateLabel.contains(query, ignoreCase = true) ||
                flock.hatcheryName.contains(query, ignoreCase = true)
            matchesBreed && matchesQuery
        }

        val filteredTransactions = transactions.filter { tx ->
            val matchesType = when (financeFilter) {
                "সকল আয়" -> tx.isIncome
                "সকল ব্যয়" -> !tx.isIncome
                "মুরগি বিক্রি" -> tx.isIncome && (tx.category == "মুরগি বিক্রি" || tx.category == "খুচরা মুরগি বিক্রি")
                "ফিড বিক্রি" -> tx.isIncome && tx.category == "ফিড বিক্রি"
                "কাঠের গুঁড়া বা লিটার বিক্রি" -> tx.isIncome && (
                    tx.category == "কাঠের গুঁড়া বা লিটার বিক্রি" ||
                        tx.category == "লিটার/ব্যবহৃত গুঁড়া বিক্রি" ||
                        tx.category == "লিটার/সার বিক্রি"
                    )
                "বাচ্চা কেনা" -> !tx.isIncome && (tx.category == "বাচ্চা কেনা" || tx.category == "বাচ্চা ক্রয়")
                "ফিড কেনা" -> !tx.isIncome && (tx.category == "ফিড কেনা" || tx.category == "ফিড ক্রয়")
                "মেডিসিন কেনা" -> !tx.isIncome && (tx.category == "মেডিসিন কেনা" || tx.category == "ওষুধ ও টিকা")
                "কাঠের গুঁড়া কেনা" -> !tx.isIncome && itMatchesCategory(tx.category, "কাঠের গুঁড়া কেনা")
                "পরিবহন ব্যয় বা ভাড়া" -> !tx.isIncome && (tx.category == "পরিবহন ব্যয় বা ভাড়া" || tx.category == "যাতায়াত ভাড়া")
                "কর্মচারী বেতন" -> !tx.isIncome && tx.category == "কর্মচারী বেতন"
                "অন্যান্য খরচ" -> !tx.isIncome && (tx.category == "অন্যান্য খরচ" || tx.category == "বিদ্যুৎ ও অন্যান্য")
                else -> true
            }
            val matchesSearch = query.isBlank() ||
                tx.title.contains(query, ignoreCase = true) ||
                tx.category.contains(query, ignoreCase = true) ||
                tx.partyName.contains(query, ignoreCase = true)
            matchesType && matchesSearch
        }

        PoultryUiState(
            customAppName = appName,
            flocks = filteredFlocks,
            dailyLogs = logs,
            transactions = filteredTransactions,
            allTransactionsUnfiltered = transactions,
            vaccinations = vaccinations,
            dailyMedicines = dailyMedicines,
            broilerSales = broilerSales,
            selectedBreedFilter = breedFilter,
            selectedFinanceFilter = financeFilter,
            searchQuery = query,
            totalActiveBirds = totalActive,
            totalInitialBirds = totalInitial,
            totalDeadBirds = totalDead,
            todayDeadBirds = todayDead,
            overallMortalityRatePercent = mortalityRate,
            totalFeedConsumedKg = totalFeedKg,
            totalFeedBagsConsumed = totalFeedBags,
            totalEstimatedLiveWeightKg = totalLiveWeightKg,
            averageWeightGrams = weightedAvgWeightGrams,
            overallFcr = overallFcr,
            totalIncomeBdt = income,
            totalExpenseBdt = expense,
            netProfitBdt = income - expense,
            costPerLiveBirdBdt = costPerBird,
            costPerLiveKgBdt = costPerKg,
            chickPurchaseExpenseBdt = chickExpense,
            feedPurchaseExpenseBdt = feedExpense,
            medicineVaccineExpenseBdt = medicineExpense,
            sawdustPurchaseExpenseBdt = sawdustExpense,
            transportFareExpenseBdt = transportExpense,
            employeeSalaryExpenseBdt = salaryExpense,
            utilityOtherExpenseBdt = utilityExpense,
            chickenSalesTotalBdt = chickenSalesTotal,
            mainBroilerSalesBdt = mainBroilerSales,
            retailChickenSalesBdt = retailChickenSales,
            feedSalesBdt = feedSales,
            litterSawdustSalesBdt = litterSales,
            totalOtherSalesBdt = totalOtherSales,
            totalSalePallaCount = totalPallaCount,
            totalSoldBirdsPieces = totalSoldPieces,
            totalSoldWeightKg = totalSoldKg,
            overallSoldAvgWeightPerBirdKg = overallAvgPerBirdKg,
            overallSoldAvgWeightPerPallaKg = overallAvgPerPallaKg,
            pendingVaccinationCount = vaccinations.count { !it.isCompleted },
            pendingDailyMedicineCount = dailyMedicines.count { !it.isGivenToday }
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = PoultryUiState()
    )

    private fun itMatchesCategory(actual: String, target: String): Boolean = actual == target

    fun setBreedFilter(filter: String) {
        _selectedBreedFilter.value = filter
    }

    fun setFinanceFilter(filter: String) {
        _selectedFinanceFilter.value = filter
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun addFlock(
        name: String,
        shedNumber: String,
        breed: String,
        initialCount: Int,
        ageInDays: Int,
        targetSaleDays: Int,
        avgWeightGrams: Int,
        chickPricePerBird: Double,
        arrivalDateLabel: String,
        hatcheryName: String,
        notes: String
    ) {
        viewModelScope.launch {
            val dateStr = arrivalDateLabel.ifBlank {
                SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
            }
            repository.insertFlock(
                FlockEntity(
                    name = name.trim(),
                    shedNumber = shedNumber.trim(),
                    breed = breed,
                    initialCount = initialCount,
                    currentCount = initialCount,
                    ageInDays = ageInDays,
                    targetSaleDays = targetSaleDays.coerceAtLeast(25),
                    avgWeightGrams = avgWeightGrams,
                    totalFeedConsumedKg = 0.0,
                    chickPricePerBird = chickPricePerBird,
                    startDateLabel = dateStr.trim(),
                    hatcheryName = hatcheryName.ifBlank { "এ-গ্রেড ব্রয়লার হ্যাচারি" }.trim(),
                    notes = notes.ifBlank { "নতুন ব্রয়লার ব্যাচ সংযোজন" }
                )
            )
        }
    }

    fun deleteFlock(flock: FlockEntity) {
        viewModelScope.launch {
            repository.deleteFlock(flock)
        }
    }

    fun addDailyLog(
        flock: FlockEntity,
        feedPhase: String,
        mortalityCount: Int,
        feedKg: Double,
        waterLiters: Double,
        avgWeightGrams: Int,
        medicineGiven: String,
        remarks: String
    ) {
        viewModelScope.launch {
            val dateStr = SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date())
            val log = DailyLogEntity(
                flockId = flock.id,
                flockName = "${flock.name} (${flock.shedNumber})",
                dateLabel = "আজ • $dateStr",
                feedPhase = feedPhase,
                mortalityCount = mortalityCount,
                feedKg = feedKg,
                waterLiters = waterLiters,
                avgWeightGrams = avgWeightGrams,
                medicineGiven = medicineGiven.ifBlank { "নিয়মিত পানি ও ভিটামিন" },
                remarks = remarks.ifBlank { "স্বাভাবিক ব্রয়লার বৃদ্ধি" }
            )
            repository.recordDailyLog(log, flock)
        }
    }

    fun deleteDailyLog(log: DailyLogEntity) {
        viewModelScope.launch {
            repository.deleteDailyLog(log)
        }
    }

    fun addTransaction(
        title: String,
        category: String,
        isIncome: Boolean,
        amountBdt: Double,
        quantityNote: String,
        partyName: String
    ) {
        viewModelScope.launch {
            val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
            repository.insertTransaction(
                FinanceTransactionEntity(
                    title = title.trim(),
                    category = category,
                    isIncome = isIncome,
                    amountBdt = amountBdt,
                    quantityNote = quantityNote.ifBlank { "নগদ লেনদেন" },
                    dateLabel = dateStr,
                    partyName = partyName.ifBlank { "সাধারণ ক্রেতা/বিক্রেতা" }
                )
            )
        }
    }

    fun deleteTransaction(transaction: FinanceTransactionEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
        }
    }

    fun addBroilerPallaSale(
        buyerName: String,
        saleDateLabel: String,
        shedName: String,
        pallaCount: Int,
        totalBirdsPieces: Int,
        totalWeightKg: Double,
        avgWeightPerBirdKg: Double,
        avgWeightPerPallaKg: Double,
        pricePerKgBdt: Double,
        totalAmountBdt: Double,
        pallaBreakdownText: String,
        existingSaleId: Long = 0L
    ) {
        viewModelScope.launch {
            val finalDate = saleDateLabel.ifBlank {
                SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
            }
            val sale = BroilerSaleEntity(
                id = existingSaleId,
                buyerName = buyerName.ifBlank { "পাইকারি মুরগি ক্রেতা" }.trim(),
                saleDateLabel = finalDate.trim(),
                shedName = shedName.ifBlank { "শেড-০১" }.trim(),
                pallaCount = pallaCount,
                totalBirdsPieces = totalBirdsPieces,
                totalWeightKg = totalWeightKg,
                avgWeightPerBirdKg = avgWeightPerBirdKg,
                avgWeightPerPallaKg = avgWeightPerPallaKg,
                pricePerKgBdt = pricePerKgBdt,
                totalAmountBdt = totalAmountBdt,
                pallaBreakdownText = pallaBreakdownText
            )
            repository.saveOrUpdateBroilerPallaSale(sale, isEdit = existingSaleId > 0L)
        }
    }

    fun deleteBroilerSale(sale: BroilerSaleEntity) {
        viewModelScope.launch {
            repository.deleteBroilerSale(sale)
        }
    }

    fun addVaccination(
        flockName: String,
        vaccineName: String,
        targetAgeDays: Int,
        scheduledDateLabel: String,
        route: String,
        doseInfo: String
    ) {
        viewModelScope.launch {
            repository.insertVaccination(
                VaccinationEntity(
                    flockName = flockName,
                    vaccineName = vaccineName.trim(),
                    targetAgeDays = targetAgeDays,
                    scheduledDateLabel = scheduledDateLabel.ifBlank { "নির্ধারিত দিন" },
                    route = route,
                    doseInfo = doseInfo.ifBlank { "পূর্ণ ডোজ" },
                    isCompleted = false
                )
            )
        }
    }

    fun toggleVaccination(vaccination: VaccinationEntity) {
        viewModelScope.launch {
            repository.toggleVaccination(vaccination)
        }
    }

    fun deleteVaccination(vaccination: VaccinationEntity) {
        viewModelScope.launch {
            repository.deleteVaccination(vaccination)
        }
    }

    fun addDailyMedicine(
        flockName: String,
        ageDayLabel: String,
        medicineName: String,
        timeOfDay: String,
        dosagePerLiter: String,
        purpose: String
    ) {
        viewModelScope.launch {
            repository.insertDailyMedicine(
                DailyMedicineEntity(
                    flockName = flockName.ifBlank { "সকল ব্রয়লার শেড" },
                    ageDayLabel = ageDayLabel.ifBlank { "প্রতিদিন" },
                    medicineName = medicineName.trim(),
                    timeOfDay = timeOfDay,
                    dosagePerLiter = dosagePerLiter.ifBlank { "১ মি.লি. / ১ লিটার পানিতে" },
                    purpose = purpose.ifBlank { "নিয়মিত স্বাস্থ্য সুরক্ষা ও গ্রোথ" },
                    isGivenToday = false
                )
            )
        }
    }

    fun toggleDailyMedicine(medicine: DailyMedicineEntity) {
        viewModelScope.launch {
            repository.toggleDailyMedicine(medicine)
        }
    }

    fun deleteDailyMedicine(medicine: DailyMedicineEntity) {
        viewModelScope.launch {
            repository.deleteDailyMedicine(medicine)
        }
    }

    fun updateFcrCalculator(
        birdCount: Int,
        avgWeightGrams: Double,
        totalFeedKg: Double,
        feedBagPrice50Kg: Double,
        chickCostPerBird: Double,
        medicineAndOtherCost: Double,
        expectedSalePricePerKg: Double
    ) {
        _fcrResult.value = calculateBroilerFcr(
            birdCount = birdCount,
            avgWeightGrams = avgWeightGrams,
            totalFeedKg = totalFeedKg,
            feedBagPrice50Kg = feedBagPrice50Kg,
            chickCostPerBird = chickCostPerBird,
            medicineAndOtherCost = medicineAndOtherCost,
            expectedSalePricePerKg = expectedSalePricePerKg
        )
    }

    companion object {
        fun calculateBroilerFcr(
            birdCount: Int,
            avgWeightGrams: Double,
            totalFeedKg: Double,
            feedBagPrice50Kg: Double,
            chickCostPerBird: Double,
            medicineAndOtherCost: Double,
            expectedSalePricePerKg: Double
        ): FcrCalculationResult {
            val totalLiveWeightKg = (birdCount * avgWeightGrams) / 1000.0
            val fcr = if (totalLiveWeightKg > 0.0) totalFeedKg / totalLiveWeightKg else 0.0
            val feedCostPerKg = feedBagPrice50Kg / 50.0
            val feedCost = totalFeedKg * feedCostPerKg
            val chickCost = birdCount * chickCostPerBird
            val totalCost = feedCost + chickCost + medicineAndOtherCost
            val costPerKgMeat = if (totalLiveWeightKg > 0.0) totalCost / totalLiveWeightKg else 0.0
            val revenue = totalLiveWeightKg * expectedSalePricePerKg
            val profit = revenue - totalCost
            val profitPerBird = if (birdCount > 0) profit / birdCount else 0.0

            return FcrCalculationResult(
                totalLiveWeightKg = totalLiveWeightKg,
                fcr = fcr,
                totalProductionCostBdt = totalCost,
                costPerKgMeatBdt = costPerKgMeat,
                estimatedRevenueBdt = revenue,
                estimatedProfitBdt = profit,
                profitPerBirdBdt = profitPerBird
            )
        }

        fun provideFactory(context: Context): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    val appCtx = context.applicationContext
                    val database = PoultryDatabase.getDatabase(appCtx)
                    val repository = PoultryRepository(database.poultryDao())
                    return PoultryViewModel(repository, appCtx) as T
                }
            }
    }
}
