package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.BroilerSaleEntity
import com.example.data.FinanceTransactionEntity
import com.example.viewmodel.FcrCalculationResult
import com.example.viewmodel.PoultryUiState
import java.util.Locale

@Composable
fun FinanceScreen(
    uiState: PoultryUiState,
    fcrResult: FcrCalculationResult,
    onFinanceFilterChange: (String) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onAddTransaction: (String, String, Boolean, Double, String, String) -> Unit,
    onDeleteTransaction: (FinanceTransactionEntity) -> Unit,
    onAddBroilerPallaSale: (String, String, String, Int, Int, Double, Double, Double, Double, Double, String, Long) -> Unit,
    onDeleteBroilerSale: (BroilerSaleEntity) -> Unit,
    onUpdateFcr: (Int, Double, Double, Double, Double, Double, Double) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedSubTab by rememberSaveable { mutableIntStateOf(0) }
    var showAddTxDialog by rememberSaveable { mutableStateOf(false) }
    var addTxDefaultIncome by rememberSaveable { mutableStateOf(true) }
    var addTxDefaultCategory by rememberSaveable { mutableStateOf("ফিড বিক্রি") }
    var showPallaSaleDialog by rememberSaveable { mutableStateOf(false) }
    var editingPallaSale by remember { mutableStateOf<BroilerSaleEntity?>(null) }

    val openCategoryDialog: (Boolean, String) -> Unit = { isIncome, category ->
        if (isIncome && category == "মুরগি বিক্রি") {
            editingPallaSale = null
            showPallaSaleDialog = true
        } else {
            addTxDefaultIncome = isIncome
            addTxDefaultCategory = category
            showAddTxDialog = true
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            if (selectedSubTab == 0) {
                FloatingActionButton(
                    onClick = {
                        addTxDefaultIncome = false
                        addTxDefaultCategory = "ফিড কেনা"
                        showAddTxDialog = true
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("add_finance_fab")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "নতুন লেনদেন")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("নতুন আয়/ব্যয়", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            TabRow(
                selectedTabIndex = selectedSubTab,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Tab(
                    selected = selectedSubTab == 0,
                    onClick = { selectedSubTab = 0 },
                    text = { Text("সকল আয় ও সকল ব্যয় খাতা", fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.ReceiptLong, contentDescription = null) },
                    modifier = Modifier.testTag("tab_ledger")
                )
                Tab(
                    selected = selectedSubTab == 1,
                    onClick = { selectedSubTab = 1 },
                    text = { Text("ব্রয়লার FCR ও লাভ ক্যালকুলেটর", fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.Calculate, contentDescription = null) },
                    modifier = Modifier.testTag("tab_fcr_calculator")
                )
            }

            if (selectedSubTab == 0) {
                LedgerListContent(
                    uiState = uiState,
                    onFinanceFilterChange = onFinanceFilterChange,
                    onSearchQueryChange = onSearchQueryChange,
                    onOpenCategoryEntry = openCategoryDialog,
                    onOpenPallaSaleDialog = {
                        editingPallaSale = null
                        showPallaSaleDialog = true
                    },
                    onEditBroilerSale = { sale ->
                        editingPallaSale = sale
                        showPallaSaleDialog = true
                    },
                    onDeleteBroilerSale = onDeleteBroilerSale,
                    onDeleteTransaction = onDeleteTransaction
                )
            } else {
                BroilerFcrCalculatorContent(
                    fcrResult = fcrResult,
                    onUpdateFcr = onUpdateFcr
                )
            }
        }
    }

    if (showAddTxDialog) {
        SmartFourBoxTransactionDialog(
            initialIsIncome = addTxDefaultIncome,
            initialCategory = addTxDefaultCategory,
            onDismiss = { showAddTxDialog = false },
            onOpenMultiPallaSaleInstead = {
                showAddTxDialog = false
                editingPallaSale = null
                showPallaSaleDialog = true
            },
            onConfirm = { title, category, isIncome, amount, qtyNote, party ->
                onAddTransaction(title, category, isIncome, amount, qtyNote, party)
                showAddTxDialog = false
            }
        )
    }

    if (showPallaSaleDialog) {
        PallaBroilerSaleDialog(
            flocks = uiState.flocks,
            initialSaleToEdit = editingPallaSale,
            onDismiss = {
                showPallaSaleDialog = false
                editingPallaSale = null
            },
            onConfirmSale = { buyer, date, shed, pallaCount, totalPcs, totalKg, avgBirdKg, avgPallaKg, rate, totalBdt, breakdown, existingId ->
                onAddBroilerPallaSale(
                    buyer,
                    date,
                    shed,
                    pallaCount,
                    totalPcs,
                    totalKg,
                    avgBirdKg,
                    avgPallaKg,
                    rate,
                    totalBdt,
                    breakdown,
                    existingId
                )
                showPallaSaleDialog = false
                editingPallaSale = null
            }
        )
    }
}

@Composable
private fun LedgerListContent(
    uiState: PoultryUiState,
    onFinanceFilterChange: (String) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onOpenCategoryEntry: (Boolean, String) -> Unit,
    onOpenPallaSaleDialog: () -> Unit,
    onEditBroilerSale: (BroilerSaleEntity) -> Unit,
    onDeleteBroilerSale: (BroilerSaleEntity) -> Unit,
    onDeleteTransaction: (FinanceTransactionEntity) -> Unit
) {
    val filters = listOf(
        "সব লেনদেন",
        "সকল আয়",
        "সকল ব্যয়",
        "মুরগি বিক্রি",
        "ফিড বিক্রি",
        "কাঠের গুঁড়া বা লিটার বিক্রি",
        "বাচ্চা কেনা",
        "ফিড কেনা",
        "মেডিসিন কেনা",
        "কাঠের গুঁড়া কেনা",
        "পরিবহন ব্যয় বা ভাড়া",
        "কর্মচারী বেতন",
        "অন্যান্য খরচ"
    )

    val incomeTransactions = remember(uiState.transactions) {
        uiState.transactions.filter { it.isIncome }
    }
    val expenseTransactions = remember(uiState.transactions) {
        uiState.transactions.filter { !it.isIncome }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("finance_ledger_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Net Profit & Overall Income vs Expense Summary Card
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${uiState.customAppName} • নিট মুনাফা / ব্যালেন্স",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = formatCurrencyBdt(uiState.netProfitBdt),
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Button(
                            onClick = onOpenPallaSaleDialog,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF15803D),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Scale, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("পাল্লা বিক্রি যোগ", fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "সর্বমোট আয় (সব বিক্রি)",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF15803D),
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = formatCurrencyBdt(uiState.totalIncomeBdt),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF15803D)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "সর্বমোট ব্যয় (সব খরচ)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = formatCurrencyBdt(uiState.totalExpenseBdt),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }

        // 2. সকল আয় আলাদা ভাবে (মুরগি বিক্রি, ফিড বিক্রি, কাঠের গুঁড়া বা লিটার বিক্রি আলাদা)
        item {
            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("finance_all_income_separate_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = Color(0xFFF0FDF4)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "সকল আয় আলাদা (মুরগি, ফিড ও কাঠের গুঁড়া/লিটার বিক্রি)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF14532D)
                            )
                            Text(
                                text = "ট্যাপ করে সরাসরি আয়ের এন্ট্রি যোগ করুন",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF166534)
                            )
                        }
                        Text(
                            text = formatCurrencyBdt(uiState.totalIncomeBdt),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF15803D)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FinanceCategoryButtonCard(
                            title = "মুরগি বিক্রি",
                            amountBdt = uiState.chickenSalesTotalBdt,
                            buttonLabel = "+ মুরগি বিক্রি",
                            accentColor = Color(0xFF15803D),
                            onClick = { onOpenCategoryEntry(true, "মুরগি বিক্রি") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("finance_btn_chicken_sale")
                        )
                        FinanceCategoryButtonCard(
                            title = "ফিড বিক্রি",
                            amountBdt = uiState.feedSalesBdt,
                            buttonLabel = "+ ফিড বিক্রি",
                            accentColor = Color(0xFFD97706),
                            onClick = { onOpenCategoryEntry(true, "ফিড বিক্রি") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("finance_btn_feed_sale")
                        )
                        FinanceCategoryButtonCard(
                            title = "কাঠের গুঁড়া বা লিটার বিক্রি",
                            amountBdt = uiState.litterSawdustSalesBdt,
                            buttonLabel = "+ গুঁড়া/লিটার বিক্রি",
                            accentColor = Color(0xFF4F46E5),
                            onClick = { onOpenCategoryEntry(true, "কাঠের গুঁড়া বা লিটার বিক্রি") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("finance_btn_litter_sale")
                        )
                    }
                }
            }
        }

        // 3. সকল ব্যয় আলাদা ভাবে (৭টি বাটন: বাচ্চা কেনা, ফিড কেনা, মেডিসিন কেনা, কাঠের গুঁড়া কেনা, পরিবহন ব্যয় বা ভাড়া, কর্মচারী বেতন, অন্যান্য খরচ)
        item {
            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("finance_all_expense_separate_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = Color(0xFFFEF2F2)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "সকল ব্যয় আলাদা (৭টি খরচের বাটন ও আলাদা হিসাব)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF991B1B)
                            )
                            Text(
                                text = "যেকোনো বাটনে ট্যাপ করে সেই খাতের খরচ যোগ করুন",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF7F1D1D)
                            )
                        }
                        Text(
                            text = formatCurrencyBdt(uiState.totalExpenseBdt),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFB91C1C)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FinanceCategoryButtonCard(
                            title = "বাচ্চা কেনা",
                            amountBdt = uiState.chickPurchaseExpenseBdt,
                            buttonLabel = "+ বাচ্চা কেনা",
                            accentColor = Color(0xFF0F766E),
                            onClick = { onOpenCategoryEntry(false, "বাচ্চা কেনা") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("finance_btn_chick_buy")
                        )
                        FinanceCategoryButtonCard(
                            title = "ফিড কেনা",
                            amountBdt = uiState.feedPurchaseExpenseBdt,
                            buttonLabel = "+ ফিড কেনা",
                            accentColor = Color(0xFFC2410C),
                            onClick = { onOpenCategoryEntry(false, "ফিড কেনা") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("finance_btn_feed_buy")
                        )
                        FinanceCategoryButtonCard(
                            title = "মেডিসিন কেনা",
                            amountBdt = uiState.medicineVaccineExpenseBdt,
                            buttonLabel = "+ মেডিসিন কেনা",
                            accentColor = Color(0xFFBE123C),
                            onClick = { onOpenCategoryEntry(false, "মেডিসিন কেনা") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("finance_btn_medicine_buy")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FinanceCategoryButtonCard(
                            title = "কাঠের গুঁড়া কেনা",
                            amountBdt = uiState.sawdustPurchaseExpenseBdt,
                            buttonLabel = "+ কাঠের গুঁড়া কেনা",
                            accentColor = Color(0xFFB45309),
                            onClick = { onOpenCategoryEntry(false, "কাঠের গুঁড়া কেনা") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("finance_btn_sawdust_buy")
                        )
                        FinanceCategoryButtonCard(
                            title = "পরিবহন ব্যয় বা ভাড়া",
                            amountBdt = uiState.transportFareExpenseBdt,
                            buttonLabel = "+ পরিবহন/ভাড়া",
                            accentColor = Color(0xFF0369A1),
                            onClick = { onOpenCategoryEntry(false, "পরিবহন ব্যয় বা ভাড়া") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("finance_btn_transport")
                        )
                        FinanceCategoryButtonCard(
                            title = "কর্মচারী বেতন",
                            amountBdt = uiState.employeeSalaryExpenseBdt,
                            buttonLabel = "+ কর্মচারী বেতন",
                            accentColor = Color(0xFF7C3AED),
                            onClick = { onOpenCategoryEntry(false, "কর্মচারী বেতন") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("finance_btn_salary")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FinanceCategoryButtonCard(
                            title = "অন্যান্য খরচ",
                            amountBdt = uiState.utilityOtherExpenseBdt,
                            buttonLabel = "+ অন্যান্য খরচ যোগ করুন",
                            accentColor = Color(0xFF475569),
                            onClick = { onOpenCategoryEntry(false, "অন্যান্য খরচ") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("finance_btn_other_expense")
                        )
                    }
                }
            }
        }

        // 4. Search & Category Filter Chips
        item {
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("মুরগি বিক্রি, ফিড কেনা, মেডিসিন কেনা বা ক্রেতা খুঁজুন...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                filters.forEach { filter ->
                    FilterChip(
                        selected = uiState.selectedFinanceFilter == filter,
                        onClick = { onFinanceFilterChange(filter) },
                        label = { Text(filter) }
                    )
                }
            }
        }

        // 5. Palla Sale Invoices (when viewing All or Income or Chicken Sale)
        if (uiState.broilerSales.isNotEmpty() &&
            (uiState.selectedFinanceFilter == "সব লেনদেন" ||
                uiState.selectedFinanceFilter == "সকল আয়" ||
                uiState.selectedFinanceFilter == "মুরগি বিক্রি")
        ) {
            item {
                Text(
                    text = "পাল্লা ভিত্তিক মুরগি বিক্রির চালানসমূহ (৪ ঘরের পাল্লা ছক):",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF14532D)
                )
            }
            items(uiState.broilerSales, key = { "palla_${it.id}" }) { sale ->
                BroilerPallaSaleInvoiceCard(
                    sale = sale,
                    onEditSale = onEditBroilerSale,
                    onDelete = { onDeleteBroilerSale(sale) }
                )
            }
        }

        // 6. Separate Income Transactions Section
        if (incomeTransactions.isNotEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFDCFCE7),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "সকল আয়ের লেনদেন তালিকা (${incomeTransactions.size} টি)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF14532D)
                        )
                        Text(
                            text = formatCurrencyBdt(incomeTransactions.sumOf { it.amountBdt }),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF15803D)
                        )
                    }
                }
            }

            items(incomeTransactions, key = { "inc_${it.id}" }) { tx ->
                TransactionRowCard(
                    tx = tx,
                    onDelete = { onDeleteTransaction(tx) }
                )
            }
        }

        // 7. Separate Expense Transactions Section
        if (expenseTransactions.isNotEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFFEE2E2),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "সকল ব্যয়ের লেনদেন তালিকা (${expenseTransactions.size} টি)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF991B1B)
                        )
                        Text(
                            text = formatCurrencyBdt(expenseTransactions.sumOf { it.amountBdt }),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFB91C1C)
                        )
                    }
                }
            }

            items(expenseTransactions, key = { "exp_${it.id}" }) { tx ->
                TransactionRowCard(
                    tx = tx,
                    onDelete = { onDeleteTransaction(tx) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(76.dp))
        }
    }
}

@Composable
private fun FinanceCategoryButtonCard(
    title: String,
    amountBdt: Double,
    buttonLabel: String,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = Color.White,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1E293B),
                maxLines = 1
            )
            Text(
                text = formatCurrencyBdt(amountBdt),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.ExtraBold,
                color = accentColor,
                maxLines = 1
            )
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = accentColor.copy(alpha = 0.14f)
            ) {
                Text(
                    text = buttonLabel,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = accentColor,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun TransactionRowCard(
    tx: FinanceTransactionEntity,
    onDelete: () -> Unit
) {
    val accentColor = if (tx.isIncome) Color(0xFF15803D) else MaterialTheme.colorScheme.error

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("tx_card_${tx.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (tx.isIncome) {
                        Icons.AutoMirrored.Filled.TrendingUp
                    } else {
                        Icons.AutoMirrored.Filled.TrendingDown
                    },
                    contentDescription = tx.category,
                    tint = accentColor
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = accentColor.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = tx.category,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = accentColor,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = tx.dateLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = tx.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                TransactionFourBoxMiniStrip(tx = tx)
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = (if (tx.isIncome) "+" else "-") + formatCurrencyBdt(tx.amountBdt),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = accentColor
                )
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "লেনদেন মুছুন",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun BroilerFcrCalculatorContent(
    fcrResult: FcrCalculationResult,
    onUpdateFcr: (Int, Double, Double, Double, Double, Double, Double) -> Unit
) {
    var birdCountInput by rememberSaveable { mutableStateOf("1948") }
    var avgWeightGramsInput by rememberSaveable { mutableStateOf("1580") }
    var totalFeedKgInput by rememberSaveable { mutableStateOf("4550") }
    var feedBagPrice50KgInput by rememberSaveable { mutableStateOf("3350") }
    var chickCostInput by rememberSaveable { mutableStateOf("48") }
    var medicineCostInput by rememberSaveable { mutableStateOf("28500") }
    var salePricePerKgInput by rememberSaveable { mutableStateOf("180") }

    val recalculate = {
        onUpdateFcr(
            birdCountInput.toIntOrNull() ?: 0,
            avgWeightGramsInput.toDoubleOrNull() ?: 0.0,
            totalFeedKgInput.toDoubleOrNull() ?: 0.0,
            feedBagPrice50KgInput.toDoubleOrNull() ?: 0.0,
            chickCostInput.toDoubleOrNull() ?: 0.0,
            medicineCostInput.toDoubleOrNull() ?: 0.0,
            salePricePerKgInput.toDoubleOrNull() ?: 0.0
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("fcr_calculator_view"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "ব্রয়লার FCR (Feed Conversion Ratio)",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Text(
                                text = String.format(Locale.US, "%.2f", fcrResult.fcr),
                                style = MaterialTheme.typography.displaySmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = if (fcrResult.fcr in 0.1..1.68) Color(0xFF15803D) else Color(0xFFD97706),
                            contentColor = Color.White
                        ) {
                            Text(
                                text = if (fcrResult.fcr in 0.1..1.68) "আদর্শ ব্রয়লার FCR" else "খাবার খরচ বেশি",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.15f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "মোট জীবন্ত ওজন",
                                style = MaterialTheme.typography.labelSmall
                            )
                            Text(
                                text = "${String.format(Locale.US, "%.1f", fcrResult.totalLiveWeightKg)} কেজি",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Column {
                            Text(
                                text = "১ কেজি মাংস উৎপাদন খরচ",
                                style = MaterialTheme.typography.labelSmall
                            )
                            Text(
                                text = "৳${String.format(Locale.US, "%.1f", fcrResult.costPerKgMeatBdt)}/কেজি",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "সম্ভাব্য নিট লাভ",
                                style = MaterialTheme.typography.labelSmall
                            )
                            Text(
                                text = formatCurrencyBdt(fcrResult.estimatedProfitBdt),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (fcrResult.estimatedProfitBdt >= 0) Color(0xFF15803D) else MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "প্রতিটি ব্রয়লার মুরগিতে গড় লাভ: ৳${String.format(Locale.US, "%.1f", fcrResult.profitPerBirdBdt)} • মোট উৎপাদন খরচ: ${formatCurrencyBdt(fcrResult.totalProductionCostBdt)}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }
        }

        item {
            Text(
                text = "ব্রয়লার ব্যাচের তথ্য দিন (স্বয়ংক্রিয় FCR ও লাভের হিসাব):",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = birdCountInput,
                    onValueChange = {
                        birdCountInput = it
                        recalculate()
                    },
                    label = { Text("জীবিত ব্রয়লার (পিস)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("fcr_bird_count_input")
                )
                OutlinedTextField(
                    value = avgWeightGramsInput,
                    onValueChange = {
                        avgWeightGramsInput = it
                        recalculate()
                    },
                    label = { Text("গড় ওজন (গ্রাম)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("fcr_avg_weight_input")
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = totalFeedKgInput,
                    onValueChange = {
                        totalFeedKgInput = it
                        recalculate()
                    },
                    label = { Text("মোট খাবার (কেজি)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("fcr_total_feed_input")
                )
                OutlinedTextField(
                    value = feedBagPrice50KgInput,
                    onValueChange = {
                        feedBagPrice50KgInput = it
                        recalculate()
                    },
                    label = { Text("৫০ কেজি বস্তার দাম (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = chickCostInput,
                    onValueChange = {
                        chickCostInput = it
                        recalculate()
                    },
                    label = { Text("বাচ্চার দর (৳/পিস)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = medicineCostInput,
                    onValueChange = {
                        medicineCostInput = it
                        recalculate()
                    },
                    label = { Text("ওষুধ, গুঁড়া, বেতন ও ভাড়া (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            OutlinedTextField(
                value = salePricePerKgInput,
                onValueChange = {
                    salePricePerKgInput = it
                    recalculate()
                },
                label = { Text("প্রত্যাশিত ব্রয়লার বিক্রয় দর (৳/কেজি)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun AddFinanceTransactionDialog(
    onDismiss: () -> Unit,
    onOpenPallaSaleInstead: () -> Unit,
    onConfirm: (String, String, Boolean, Double, String, String) -> Unit
) {
    var isIncome by remember { mutableStateOf(true) }
    val incomeCategories = listOf(
        "খুচরা মুরগি বিক্রি",
        "ফিড বিক্রি",
        "লিটার/ব্যবহৃত গুঁড়া বিক্রি",
        "মুরগি বিক্রি"
    )
    val expenseCategories = listOf(
        "ফিড ক্রয়",
        "বাচ্চা ক্রয়",
        "ওষুধ ও টিকা",
        "কাঠের গুঁড়া কেনা",
        "কর্মচারী বেতন",
        "যাতায়াত ভাড়া",
        "বিদ্যুৎ ও অন্যান্য"
    )
    var selectedCategory by remember { mutableStateOf(incomeCategories.first()) }
    var title by remember { mutableStateOf("") }
    var amountInput by remember { mutableStateOf("") }
    var quantityNote by remember { mutableStateOf("") }
    var partyName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "নতুন বিক্রি বা খরচের হিসাব",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = isIncome,
                        onClick = {
                            isIncome = true
                            selectedCategory = incomeCategories.first()
                        },
                        label = { Text("বিক্রি (আয়)") }
                    )
                    FilterChip(
                        selected = !isIncome,
                        onClick = {
                            isIncome = false
                            selectedCategory = expenseCategories.first()
                        },
                        label = { Text("খরচ (ব্যয়)") }
                    )
                }

                if (isIncome) {
                    Button(
                        onClick = onOpenPallaSaleInstead,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF15803D),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Scale, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("১৫/২০ টা করে পাল্লা ওজন দিয়ে মুরগি বিক্রি করুন")
                    }
                }

                val activeCategories = if (isIncome) incomeCategories else expenseCategories
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    activeCategories.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat) }
                        )
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("বিবরণ") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tx_title_input")
                )
                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("টাকার পরিমাণ (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tx_amount_input")
                )
                OutlinedTextField(
                    value = quantityNote,
                    onValueChange = { quantityNote = it },
                    label = { Text("পরিমাণ (কেজি / পিস / বস্তা / ট্রিপ)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = partyName,
                    onValueChange = { partyName = it },
                    label = { Text("ক্রেতা / কর্মচারী / ডিলারের নাম") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountInput.toDoubleOrNull() ?: 0.0
                    val finalTitle = title.ifBlank { selectedCategory }
                    if (amount > 0.0) {
                        onConfirm(finalTitle, selectedCategory, isIncome, amount, quantityNote, partyName)
                    }
                },
                modifier = Modifier.testTag("confirm_add_tx_btn")
            ) {
                Text("সংরক্ষণ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}
