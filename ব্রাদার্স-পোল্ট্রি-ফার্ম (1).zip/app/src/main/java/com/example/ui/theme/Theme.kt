package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val DarkColorScheme = darkColorScheme(
    primary = DarkGreenPrimary,
    onPrimary = Color(0xFF072114),
    primaryContainer = DarkGreenContainer,
    onPrimaryContainer = FarmGreenLight,
    secondary = DarkGreenSecondary,
    onSecondary = Color(0xFF092317),
    secondaryContainer = DarkSurfaceVariant,
    onSecondaryContainer = FarmGreenLight,
    tertiary = DarkGoldTertiary,
    onTertiary = Color(0xFF2B1900),
    tertiaryContainer = Color(0xFF543605),
    onTertiaryContainer = HarvestGoldLight,
    background = DarkBackground,
    onBackground = Color(0xFFE6F2EB),
    surface = DarkSurface,
    onSurface = Color(0xFFE6F2EB),
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = Color(0xFFB7CCC0)
)

private val LightColorScheme = lightColorScheme(
    primary = FarmGreenPrimary,
    onPrimary = Color.White,
    primaryContainer = FarmGreenLight,
    onPrimaryContainer = TextDarkForest,
    secondary = FarmGreenSecondary,
    onSecondary = Color.White,
    secondaryContainer = FarmMintContainer,
    onSecondaryContainer = TextDarkForest,
    tertiary = HarvestGold,
    onTertiary = Color.White,
    tertiaryContainer = HarvestGoldLight,
    onTertiaryContainer = Color(0xFF451A03),
    background = CreamBackground,
    onBackground = TextDarkForest,
    surface = WarmSurface,
    onSurface = TextDarkForest,
    surfaceVariant = WarmSurfaceVariant,
    onSurfaceVariant = TextMutedOlive
)

val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = AppShapes,
        content = content
    )
}
