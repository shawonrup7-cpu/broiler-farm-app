package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BroilerSaleEntity
import com.example.data.FinanceTransactionEntity
import com.example.data.FlockEntity
import com.example.viewmodel.PoultryUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ৪টি ঘরের পাল্লা রো ডাটা:
 * ১ম ঘর: পিস (piecesText)
 * ২য় ঘর: ওজন কেজি (weightKgText)
 * ৩য় ঘর: গড় (avgPerBirdKg - অটোমেটিক ভাবে হিসাব হবে)
 * ৪র্থ ঘর: মন্তব্য - ঐচ্ছিক (remarkText)
 */
data class EditablePallaItem(
    val uid: Long,
    val piecesText: String,
    val weightKgText: String,
    val remarkText: String = ""
) {
    val pieces: Int
        get() = normalizeDigits(piecesText).trim().toIntOrNull()?.coerceAtLeast(0) ?: 0

    val weightKg: Double
        get() = normalizeDigits(weightKgText).trim().toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0

    // ৩য় ঘর: গড় ওজন (অটোমেটিক ভাবে)
    val avgPerBirdKg: Double
        get() = if (pieces > 0) weightKg / pieces.toDouble() else 0.0
}

data class ParsedPallaRowDisplay(
    val serialLabel: String,
    val piecesLabel: String,
    val weightLabel: String,
    val autoAvgLabel: String,
    val remarkLabel: String
)

data class FourBoxTransactionRowDisplay(
    val categoryShort: String,
    val box1Label: String,
    val box2Label: String,
    val box3AutoAvgLabel: String,
    val box4RemarkLabel: String,
    val totalAmountLabel: String
)

private fun normalizeDigits(input: String): String {
    return input.map { ch ->
        if (ch in '০'..'৯') '0' + (ch - '০') else ch
    }.joinToString("")
}

/**
 * সংরক্ষিত পাল্লা টেক্সট থেকে ৪টি ঘরের (পিস | ওজন | গড় | মন্তব্য) লিস্ট তৈরি করে
 */
fun parsePallaBreakdownToEditableList(breakdownText: String): List<EditablePallaItem> {
    if (breakdownText.isBlank()) return emptyList()
    val numberRegex = Regex("""([0-9]+(?:\.[0-9]+)?)""")
    return breakdownText.split("|")
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .mapIndexed { idx, row ->
            if (row.contains("~")) {
                val parts = row.split("~")
                val pcs = normalizeDigits(parts.getOrNull(1) ?: "15")
                val wt = normalizeDigits(parts.getOrNull(2) ?: "26.5")
                val remark = parts.getOrNull(4) ?: ""
                EditablePallaItem(
                    uid = idx + 1L,
                    piecesText = pcs,
                    weightKgText = wt,
                    remarkText = remark
                )
            } else {
                val normalized = normalizeDigits(row)
                val afterColon = normalized.substringAfter(":", normalized)
                val matches = numberRegex.findAll(afterColon).map { it.value }.toList()
                val pcsStr = matches.getOrNull(0)?.substringBefore(".") ?: "15"
                val wtStr = matches.getOrNull(1) ?: "26.5"
                val remarkPart = row.substringAfter("মন্তব্য:", "").trim()
                EditablePallaItem(
                    uid = idx + 1L,
                    piecesText = pcsStr,
                    weightKgText = wtStr,
                    remarkText = remarkPart
                )
            }
        }
}

fun parsePallaBreakdownForTableDisplay(breakdownText: String): List<ParsedPallaRowDisplay> {
    return parsePallaBreakdownToEditableList(breakdownText).mapIndexed { index, item ->
        ParsedPallaRowDisplay(
            serialLabel = "পাল্লা-${index + 1}",
            piecesLabel = "${item.pieces} পিস",
            weightLabel = "${String.format(Locale.US, "%.2f", item.weightKg)} কেজি",
            autoAvgLabel = "${String.format(Locale.US, "%.2f", item.avgPerBirdKg)} কেজি",
            remarkLabel = item.remarkText.ifBlank { "—" }
        )
    }
}

/**
 * যেকোনো বিক্রি বা খরচের লেনদেনকে ৪টি ঘরের (১ম ঘর | ২য় ঘর | ৩য় ঘর: গড় অটো | ৪র্থ ঘর: মন্তব্য) ফরম্যাটে রূপান্তর করে
 */
fun parseTransactionToFourBoxDisplay(tx: FinanceTransactionEntity): FourBoxTransactionRowDisplay {
    val note = tx.quantityNote.trim()
    val shortCat = when (tx.category) {
        "মুরগি বিক্রি" -> "মুরগি বিক্রি"
        "খুচরা মুরগি বিক্রি" -> "খুচরা মুরগি"
        "ফিড বিক্রি" -> "ফিড বিক্রি"
        "কাঠের গুঁড়া বা লিটার বিক্রি", "লিটার/ব্যবহৃত গুঁড়া বিক্রি", "লিটার/সার বিক্রি" -> "কাঠের গুঁড়া/লিটার"
        "বাচ্চা কেনা", "বাচ্চা ক্রয়" -> "বাচ্চা কেনা"
        "ফিড কেনা", "ফিড ক্রয়" -> "ফিড কেনা"
        "মেডিসিন কেনা", "ওষুধ ও টিকা" -> "মেডিসিন কেনা"
        "কাঠের গুঁড়া কেনা" -> "কাঠের গুঁড়া কেনা"
        "পরিবহন ব্যয় বা ভাড়া", "যাতায়াত ভাড়া" -> "পরিবহন/ভাড়া"
        "কর্মচারী বেতন" -> "কর্মচারী বেতন"
        "অন্যান্য খরচ", "বিদ্যুৎ ও অন্যান্য" -> "অন্যান্য খরচ"
        else -> tx.category
    }

    if (note.contains("~")) {
        val parts = note.split("~").map { it.trim() }
        return FourBoxTransactionRowDisplay(
            categoryShort = shortCat,
            box1Label = parts.getOrNull(0)?.ifBlank { "—" } ?: "—",
            box2Label = parts.getOrNull(1)?.ifBlank { "—" } ?: "—",
            box3AutoAvgLabel = parts.getOrNull(2)?.ifBlank { "—" } ?: "—",
            box4RemarkLabel = parts.getOrNull(3)?.ifBlank { "—" } ?: "—",
            totalAmountLabel = formatCurrencyBdt(tx.amountBdt)
        )
    }

    // Fallback intelligent parser for older/seed notes
    val normalized = normalizeDigits(note)
    val nums = Regex("""([0-9]+(?:\.[0-9]+)?)""").findAll(normalized).mapNotNull { it.value.toDoubleOrNull() }.toList()
    val remarkFallback = tx.partyName.ifBlank { "—" }

    return when (tx.category) {
        "খুচরা মুরগি বিক্রি", "মুরগি বিক্রি" -> {
            val firstNum = nums.getOrNull(0) ?: 10.0
            val secondNum = nums.getOrNull(1) ?: 18.0
            val avg = if (firstNum > 0) secondNum / firstNum else 0.0
            FourBoxTransactionRowDisplay(
                categoryShort = shortCat,
                box1Label = "${firstNum.toInt()} পিস",
                box2Label = "${String.format(Locale.US, "%.1f", secondNum)} কেজি",
                box3AutoAvgLabel = "${String.format(Locale.US, "%.2f", avg)} কেজি/পিস",
                box4RemarkLabel = remarkFallback,
                totalAmountLabel = formatCurrencyBdt(tx.amountBdt)
            )
        }
        "ফিড বিক্রি", "ফিড কেনা", "ফিড ক্রয়" -> {
            val bags = nums.getOrNull(0) ?: 1.0
            val kg = if (nums.size >= 2 && nums[1] >= bags * 10) nums[1] else bags * 50.0
            val avgKg = if (bags > 0) kg / bags else 50.0
            FourBoxTransactionRowDisplay(
                categoryShort = shortCat,
                box1Label = "${bags.toInt()} বস্তা",
                box2Label = "${kg.toInt()} কেজি",
                box3AutoAvgLabel = "${avgKg.toInt()} কেজি/বস্তা",
                box4RemarkLabel = remarkFallback,
                totalAmountLabel = formatCurrencyBdt(tx.amountBdt)
            )
        }
        "কাঠের গুঁড়া বা লিটার বিক্রি", "লিটার/ব্যবহৃত গুঁড়া বিক্রি", "কাঠের গুঁড়া কেনা" -> {
            val bags = nums.getOrNull(0) ?: 10.0
            val avgPrice = if (bags > 0) tx.amountBdt / bags else 0.0
            FourBoxTransactionRowDisplay(
                categoryShort = shortCat,
                box1Label = "${bags.toInt()} বস্তা",
                box2Label = formatCurrencyBdt(tx.amountBdt),
                box3AutoAvgLabel = "৳${String.format(Locale.US, "%.0f", avgPrice)}/বস্তা",
                box4RemarkLabel = remarkFallback,
                totalAmountLabel = formatCurrencyBdt(tx.amountBdt)
            )
        }
        "বাচ্চা কেনা", "বাচ্চা ক্রয়" -> {
            val chicks = nums.getOrNull(0) ?: 1000.0
            val avgRate = if (chicks > 0) tx.amountBdt / chicks else 0.0
            FourBoxTransactionRowDisplay(
                categoryShort = shortCat,
                box1Label = "${chicks.toInt()} পিস",
                box2Label = formatCurrencyBdt(tx.amountBdt),
                box3AutoAvgLabel = "৳${String.format(Locale.US, "%.1f", avgRate)}/পিস",
                box4RemarkLabel = remarkFallback,
                totalAmountLabel = formatCurrencyBdt(tx.amountBdt)
            )
        }
        "কর্মচারী বেতন" -> {
            val staff = nums.getOrNull(0) ?: 1.0
            val avgSal = if (staff > 0) tx.amountBdt / staff else tx.amountBdt
            FourBoxTransactionRowDisplay(
                categoryShort = shortCat,
                box1Label = "${staff.toInt()} জন",
                box2Label = formatCurrencyBdt(tx.amountBdt),
                box3AutoAvgLabel = "৳${String.format(Locale.US, "%.0f", avgSal)}/জন",
                box4RemarkLabel = remarkFallback,
                totalAmountLabel = formatCurrencyBdt(tx.amountBdt)
            )
        }
        "পরিবহন ব্যয় বা ভাড়া", "যাতায়াত ভাড়া" -> {
            val trips = nums.getOrNull(0) ?: 1.0
            val avgTrip = if (trips > 0) tx.amountBdt / trips else tx.amountBdt
            FourBoxTransactionRowDisplay(
                categoryShort = shortCat,
                box1Label = "${trips.toInt()} ট্রিপ",
                box2Label = formatCurrencyBdt(tx.amountBdt),
                box3AutoAvgLabel = "৳${String.format(Locale.US, "%.0f", avgTrip)}/ট্রিপ",
                box4RemarkLabel = remarkFallback,
                totalAmountLabel = formatCurrencyBdt(tx.amountBdt)
            )
        }
        else -> {
            val units = nums.getOrNull(0) ?: 1.0
            val avgCost = if (units > 0) tx.amountBdt / units else tx.amountBdt
            FourBoxTransactionRowDisplay(
                categoryShort = shortCat,
                box1Label = "${units.toInt()} ইউনিট",
                box2Label = formatCurrencyBdt(tx.amountBdt),
                box3AutoAvgLabel = "৳${String.format(Locale.US, "%.0f", avgCost)}/ইউনিট",
                box4RemarkLabel = remarkFallback,
                totalAmountLabel = formatCurrencyBdt(tx.amountBdt)
            )
        }
    }
}

/**
 * ড্যাশবোর্ডে "অন্যান্য বিক্রি ঘর" (খুচরা মুরগি: কেজি/পিস, ফিড: বস্তা, লিটার/গুঁড়া: বস্তা) এর ৪ ঘরের ছক
 */
@Composable
fun OtherSalesFourBoxDashboardTable(
    transactions: List<FinanceTransactionEntity>,
    modifier: Modifier = Modifier
) {
    val otherSales = remember(transactions) {
        transactions.filter {
            it.isIncome && (
                it.category == "খুচরা মুরগি বিক্রি" ||
                    it.category == "ফিড বিক্রি" ||
                    it.category == "কাঠের গুঁড়া বা লিটার বিক্রি" ||
                    it.category == "লিটার/ব্যবহৃত গুঁড়া বিক্রি" ||
                    it.category == "লিটার/সার বিক্রি"
                )
        }
    }

    if (otherSales.isEmpty()) return

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.White,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // 4-Box Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFCCFBF1))
                    .padding(horizontal = 8.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "বিক্রি খাত",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF115E59),
                    modifier = Modifier.weight(0.95f)
                )
                Text(
                    text = "১ম: পিস/বস্তা/কেজি",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF115E59),
                    modifier = Modifier.weight(0.95f)
                )
                Text(
                    text = "২য়: ওজন/টাকা",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF115E59),
                    modifier = Modifier.weight(0.95f)
                )
                Text(
                    text = "৩য়: গড় (অটো)",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFFB45309),
                    modifier = Modifier.weight(1.0f)
                )
                Text(
                    text = "৪র্থ: মন্তব্য",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF334155),
                    modifier = Modifier.weight(0.95f)
                )
            }

            otherSales.take(6).forEachIndexed { idx, tx ->
                val row = parseTransactionToFourBoxDisplay(tx)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (idx % 2 == 0) Color.White else Color(0xFFF8FAFC))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = row.categoryShort,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F766E),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(0.95f)
                    )
                    Text(
                        text = row.box1Label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF1E293B),
                        maxLines = 1,
                        modifier = Modifier.weight(0.95f)
                    )
                    Text(
                        text = row.box2Label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF15803D),
                        maxLines = 1,
                        modifier = Modifier.weight(0.95f)
                    )
                    Text(
                        text = row.box3AutoAvgLabel,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFD97706),
                        maxLines = 1,
                        modifier = Modifier.weight(1.0f)
                    )
                    Text(
                        text = row.box4RemarkLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF64748B),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(0.95f)
                    )
                }
            }
        }
    }
}

/**
 * ড্যাশবোর্ডে খরচের খাতগুলোর জন্য ৪ ঘরের ছক (১ম ঘর: বস্তা/পিস/জন/ট্রিপ | ২য় ঘর: ওজন/টাকা | ৩য় ঘর: গড় অটো | ৪র্থ ঘর: মন্তব্য)
 */
@Composable
fun ExpensesFourBoxDashboardTable(
    transactions: List<FinanceTransactionEntity>,
    modifier: Modifier = Modifier
) {
    val expenses = remember(transactions) {
        transactions.filter { !it.isIncome }
    }

    if (expenses.isEmpty()) return

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFFFF1F2).copy(alpha = 0.6f),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFFEE2E2))
                    .padding(horizontal = 8.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "খরচের খাত",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF991B1B),
                    modifier = Modifier.weight(0.95f)
                )
                Text(
                    text = "১ম: বস্তা/পিস/জন",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF991B1B),
                    modifier = Modifier.weight(0.95f)
                )
                Text(
                    text = "২য়: ওজন/টাকা",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF991B1B),
                    modifier = Modifier.weight(0.95f)
                )
                Text(
                    text = "৩য়: গড় (অটো)",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFFB45309),
                    modifier = Modifier.weight(1.0f)
                )
                Text(
                    text = "৪র্থ: মন্তব্য",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF334155),
                    modifier = Modifier.weight(0.95f)
                )
            }

            expenses.take(6).forEachIndexed { idx, tx ->
                val row = parseTransactionToFourBoxDisplay(tx)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (idx % 2 == 0) Color.White else Color(0xFFFFF1F2).copy(alpha = 0.35f))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = row.categoryShort,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFBE123C),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(0.95f)
                    )
                    Text(
                        text = row.box1Label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF1E293B),
                        maxLines = 1,
                        modifier = Modifier.weight(0.95f)
                    )
                    Text(
                        text = row.box2Label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFDC2626),
                        maxLines = 1,
                        modifier = Modifier.weight(0.95f)
                    )
                    Text(
                        text = row.box3AutoAvgLabel,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFD97706),
                        maxLines = 1,
                        modifier = Modifier.weight(1.0f)
                    )
                    Text(
                        text = row.box4RemarkLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF64748B),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(0.95f)
                    )
                }
            }
        }
    }
}

/**
 * বিক্রি ও খরচের খাতার প্রতিটি লেনদেনের কার্ডে ৪ ঘরের ছক দেখানোর স্ট্রিপ
 */
@Composable
fun TransactionFourBoxMiniStrip(
    tx: FinanceTransactionEntity,
    modifier: Modifier = Modifier
) {
    val row = remember(tx) { parseTransactionToFourBoxDisplay(tx) }
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (tx.isIncome) Color(0xFFF0FDF4) else Color(0xFFFEF2F2),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("১ম ঘর", style = TextStyle(fontSize = 9.sp), color = Color(0xFF64748B))
                Text(row.box1Label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E293B))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("২য় ঘর", style = TextStyle(fontSize = 9.sp), color = Color(0xFF64748B))
                Text(row.box2Label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold, color = if (tx.isIncome) Color(0xFF15803D) else Color(0xFFDC2626))
            }
            Column(modifier = Modifier.weight(1.1f)) {
                Text("৩য়: গড় (অটো)", style = TextStyle(fontSize = 9.sp), color = Color(0xFFB45309))
                Text(row.box3AutoAvgLabel, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold, color = Color(0xFFD97706))
            }
            Column(modifier = Modifier.weight(1.1f)) {
                Text("৪র্থ: মন্তব্য", style = TextStyle(fontSize = 9.sp), color = Color(0xFF64748B))
                Text(
                    text = row.box4RemarkLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF475569),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

/**
 * ড্যাশবোর্ডে মৃত্যু হার (Mortality Rate) ও শেড ভিত্তিক মৃত মুরগির বিস্তারিত কার্ড
 */
@Composable
fun DashboardMortalitySummaryCard(
    uiState: PoultryUiState,
    onRecordMortalityClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isLowMortality = uiState.overallMortalityRatePercent <= 3.5
    val statusColor = if (isLowMortality) Color(0xFF15803D) else Color(0xFFDC2626)
    val badgeBgColor = if (isLowMortality) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)

    ElevatedCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("dashboard_mortality_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFEE2E2)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isLowMortality) Icons.Default.HealthAndSafety else Icons.Default.WarningAmber,
                            contentDescription = "মৃত্যু হার",
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "মৃত্যু হার ও মৃত মুরগির হিসাব (Mortality Rate)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "সকল শেডের মোট বাচ্চা, মৃত সংখ্যা ও শতকরা মৃত্যু হার (%)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                OutlinedButton(
                    onClick = onRecordMortalityClick,
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("record_mortality_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("মৃত্যু এন্ট্রি", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
            }

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFFFFF1F2),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "খামারের গড় মৃত্যু হার (Mortality Rate)",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color(0xFF9F1239),
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${String.format(Locale.US, "%.2f", uiState.overallMortalityRatePercent)}%",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFFBE123C)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = badgeBgColor
                        ) {
                            Text(
                                text = if (isLowMortality) "স্বাভাবিক সীমায় আছে (<৩.৫%)" else "সতর্কতা প্রয়োজন (>৩.৫%)",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = statusColor,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }

                    LinearProgressIndicator(
                        progress = { (uiState.overallMortalityRatePercent.toFloat() / 10f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(7.dp)
                            .clip(RoundedCornerShape(50)),
                        color = if (isLowMortality) Color(0xFF16A34A) else Color(0xFFDC2626),
                        trackColor = Color(0xFFFECDD3)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MortalityStatColumn(
                            label = "মোট বাচ্চা এসেছিল",
                            value = "${formatBanglaInt(uiState.totalInitialBirds)} পিস",
                            valueColor = Color(0xFF1E293B)
                        )
                        MortalityStatColumn(
                            label = "এখন পর্যন্ত মোট মৃত",
                            value = "${formatBanglaInt(uiState.totalDeadBirds)} পিস",
                            valueColor = Color(0xFFDC2626)
                        )
                        MortalityStatColumn(
                            label = "আজকে মৃত",
                            value = "${formatBanglaInt(uiState.todayDeadBirds)} পিস",
                            valueColor = Color(0xFFB45309)
                        )
                        MortalityStatColumn(
                            label = "বর্তমান জীবিত",
                            value = "${formatBanglaInt(uiState.totalActiveBirds)} পিস",
                            valueColor = Color(0xFF15803D)
                        )
                    }
                }
            }

            if (uiState.flocks.isNotEmpty()) {
                Text(
                    text = "শেড অনুযায়ী আলাদা মৃত্যু হার:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                uiState.flocks.forEach { flock ->
                    val shedDead = flock.deadBirdCount
                    val shedMortalityPct = flock.mortalityRatePercent
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 9.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${flock.shedNumber} • ${flock.name}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "মোট বাচ্চা: ${flock.initialCount} টি • জীবিত: ${flock.currentCount} টি",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "মৃত: $shedDead টি",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFDC2626)
                                )
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (shedMortalityPct <= 3.5) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)
                                ) {
                                    Text(
                                        text = "${String.format(Locale.US, "%.2f", shedMortalityPct)}%",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (shedMortalityPct <= 3.5) Color(0xFF15803D) else Color(0xFFDC2626),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MortalityStatColumn(
    label: String,
    value: String,
    valueColor: Color
) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF64748B)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.ExtraBold,
            color = valueColor
        )
    }
}

/**
 * ৪টি ঘরের ছকে সাজানো পাল্লা বিক্রির চালান কার্ড:
 * [১ম ঘর: পিস] | [২য় ঘর: ওজন] | [৩য় ঘর: গড় (অটো)] | [৪র্থ ঘর: মন্তব্য]
 */
@Composable
fun BroilerPallaSaleInvoiceCard(
    sale: BroilerSaleEntity,
    onEditSale: (BroilerSaleEntity) -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tableRows = remember(sale.pallaBreakdownText) {
        parsePallaBreakdownForTableDisplay(sale.pallaBreakdownText)
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("palla_sale_invoice_${sale.id}"),
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFFF0FDF4)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header: Buyer Name, Date, Shed, Total Amount, Edit & Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = Color(0xFF15803D),
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "ক্রেতা: ${sale.buyerName}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF14532D)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = null,
                                tint = Color(0xFF166534),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "তারিখ: ${sale.saleDateLabel}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF166534)
                            )
                        }
                        Text(
                            text = "• ${sale.shedName}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF15803D)
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = formatCurrencyBdt(sale.totalAmountBdt),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF15803D)
                        )
                        Text(
                            text = "দর: ৳${String.format(Locale.US, "%.0f", sale.pricePerKgBdt)}/কেজি",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF166534)
                        )
                    }
                    IconButton(
                        onClick = { onEditSale(sale) },
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("edit_palla_sale_${sale.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "পিস ও ওজন এডিট করুন",
                            tint = Color(0xFF0284C7),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "বিক্রি চালান মুছুন",
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // ৪টি ঘরের ছক (১ম ঘর: পিস | ২য় ঘর: ওজন | ৩য় ঘর: গড় (অটো) | ৪র্থ ঘর: মন্তব্য)
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color.White,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFDCFCE7))
                            .padding(horizontal = 8.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "পাল্লা",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF14532D),
                            modifier = Modifier.weight(0.75f)
                        )
                        Text(
                            text = "১ম ঘর: পিস",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF14532D),
                            modifier = Modifier.weight(0.85f)
                        )
                        Text(
                            text = "২য় ঘর: ওজন",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF14532D),
                            modifier = Modifier.weight(0.95f)
                        )
                        Text(
                            text = "৩য়: গড় (অটো)",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFB45309),
                            modifier = Modifier.weight(0.95f)
                        )
                        Text(
                            text = "৪র্থ: মন্তব্য",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF475569),
                            modifier = Modifier.weight(1.0f)
                        )
                    }

                    // Table Rows
                    tableRows.forEachIndexed { idx, row ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (idx % 2 == 0) Color.White else Color(0xFFF8FAFC))
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = row.serialLabel,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF15803D),
                                modifier = Modifier.weight(0.75f)
                            )
                            Text(
                                text = row.piecesLabel,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF1E293B),
                                modifier = Modifier.weight(0.85f)
                            )
                            Text(
                                text = row.weightLabel,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF15803D),
                                modifier = Modifier.weight(0.95f)
                            )
                            Text(
                                text = row.autoAvgLabel,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFD97706),
                                modifier = Modifier.weight(0.95f)
                            )
                            Text(
                                text = row.remarkLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF64748B),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1.0f)
                            )
                        }
                    }

                    // Table Footer Summary Row (মোট পাল্লা | মোট পিস | মোট ওজন | গড় ওজন)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFFEF3C7))
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "মোট ${sale.pallaCount} পাল্লা",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF92400E),
                            modifier = Modifier.weight(0.75f)
                        )
                        Text(
                            text = "${sale.totalBirdsPieces} পিস",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF1E293B),
                            modifier = Modifier.weight(0.85f)
                        )
                        Text(
                            text = "${String.format(Locale.US, "%.2f", sale.totalWeightKg)} কেজি",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF15803D),
                            modifier = Modifier.weight(0.95f)
                        )
                        Text(
                            text = "${String.format(Locale.US, "%.2f", sale.avgWeightPerBirdKg)} কেজি",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFB45309),
                            modifier = Modifier.weight(0.95f)
                        )
                        Text(
                            text = "${(sale.avgWeightPerBirdKg * 1000).toInt()} গ্রাম/পিস",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF92400E),
                            modifier = Modifier.weight(1.0f)
                        )
                    }
                }
            }
        }
    }
}

/**
 * ৪টি ঘরের (১ম: পিস | ২য়: ওজন | ৩য়: গড় অটো | ৪র্থ: মন্তব্য ঐচ্ছিক) মুরগি বিক্রি ও পাল্লা হিসাব ডায়ালগ
 */
@Composable
fun PallaBroilerSaleDialog(
    flocks: List<FlockEntity>,
    initialSaleToEdit: BroilerSaleEntity? = null,
    onDismiss: () -> Unit,
    onConfirmSale: (
        buyerName: String,
        saleDateLabel: String,
        shedName: String,
        pallaCount: Int,
        totalBirdsPieces: Int,
        totalWeightKg: Double,
        avgWeightPerBirdKg: Double,
        avgWeightPerPallaKg: Double,
        pricePerKgBdt: Double,
        totalAmountBdt: Double,
        pallaBreakdownText: String,
        existingSaleId: Long
    ) -> Unit
) {
    val todayDefault = remember {
        SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
    }
    var buyerName by remember(initialSaleToEdit) {
        mutableStateOf(initialSaleToEdit?.buyerName ?: "সোনার বাংলা পোল্ট্রি আড়ত")
    }
    var saleDateLabel by remember(initialSaleToEdit) {
        mutableStateOf(initialSaleToEdit?.saleDateLabel ?: "২৭ সেপ্টেম্বর ২০২৬ ($todayDefault)")
    }
    var selectedShedName by remember(initialSaleToEdit) {
        mutableStateOf(
            initialSaleToEdit?.shedName
                ?: flocks.firstOrNull()?.let { "${it.shedNumber} (${it.name})" }
                ?: "শেড-০১ (কব-৫০০ ব্যাচ)"
        )
    }
    var pricePerKgInput by remember(initialSaleToEdit) {
        mutableStateOf(
            initialSaleToEdit?.let { String.format(Locale.US, "%.0f", it.pricePerKgBdt) } ?: "180"
        )
    }

    var nextUid by remember { mutableLongStateOf(200L) }

    // ৪টি ঘরের তালিকা: ১ম ঘর পিস | ২য় ঘর ওজন | ৩য় ঘর গড় (অটো) | ৪র্থ ঘর মন্তব্য (ঐচ্ছিক)
    val pallaList = remember(initialSaleToEdit) {
        val parsed = initialSaleToEdit?.let { parsePallaBreakdownToEditableList(it.pallaBreakdownText) }
        if (!parsed.isNullOrEmpty()) {
            mutableStateListOf(*parsed.toTypedArray())
        } else {
            mutableStateListOf(
                EditablePallaItem(uid = 1L, piecesText = "20", weightKgText = "35.60", remarkText = "১ নং খাঁচা"),
                EditablePallaItem(uid = 2L, piecesText = "18", weightKgText = "32.10", remarkText = ""),
                EditablePallaItem(uid = 3L, piecesText = "15", weightKgText = "26.80", remarkText = "")
            )
        }
    }

    val validPallas = pallaList.filter { it.pieces > 0 || it.weightKg > 0.0 }
    val totalPallaCount = validPallas.size
    val totalPieces = pallaList.sumOf { it.pieces }
    val totalWeightKg = pallaList.sumOf { it.weightKg }
    val avgWeightPerBirdKg = if (totalPieces > 0) totalWeightKg / totalPieces.toDouble() else 0.0
    val avgWeightPerPallaKg = if (totalPallaCount > 0) totalWeightKg / totalPallaCount.toDouble() else 0.0
    val pricePerKg = normalizeDigits(pricePerKgInput).toDoubleOrNull() ?: 0.0
    val totalAmountBdt = totalWeightKg * pricePerKg

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = "মুরগি বিক্রি (৪ ঘরের পাল্লা ছক)",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "১ম ঘরে পিস • ২য় ঘরে ওজন • ৩য় ঘরে গড় (অটোমেটিক) • ৪র্থ ঘরে মন্তব্য (ঐচ্ছিক)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // ক্রেতার নাম, তারিখ ও দর
                OutlinedTextField(
                    value = buyerName,
                    onValueChange = { buyerName = it },
                    label = { Text("ক্রেতার নাম / আড়তের নাম") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("palla_buyer_name_input")
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = saleDateLabel,
                        onValueChange = { saleDateLabel = it },
                        label = { Text("বিক্রির তারিখ") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("palla_sale_date_input")
                    )
                    OutlinedTextField(
                        value = pricePerKgInput,
                        onValueChange = { pricePerKgInput = it },
                        label = { Text("দর (৳/কেজি)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .weight(0.8f)
                            .testTag("palla_price_per_kg_input")
                    )
                }

                // শেড নির্বাচন
                if (flocks.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "শেড:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        flocks.forEach { flock ->
                            val label = "${flock.shedNumber} (${flock.name})"
                            FilterChip(
                                selected = selectedShedName == label,
                                onClick = { selectedShedName = label },
                                label = { Text(flock.shedNumber) }
                            )
                        }
                    }
                }

                HorizontalDivider()

                // ৪টি ঘরের টেবিল হেডার (প্রথম ঘরে পিস | দ্বিতীয় ঘরে ওজন | তৃতীয় ঘরে গড় অটো | চতুর্থ ঘরে মন্তব্য)
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF15803D),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "১ম: পিস",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(0.95f)
                        )
                        Text(
                            text = "২য়: ওজন(কেজি)",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1.1f)
                        )
                        Text(
                            text = "৩য়: গড় (অটো)",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFFDE047),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1.05f)
                        )
                        Text(
                            text = "৪র্থ: মন্তব্য (ঐচ্ছিক)",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1.25f)
                        )
                        Spacer(modifier = Modifier.width(24.dp))
                    }
                }

                // প্রতিটি পাল্লার ৪টি ঘরের লাইন (Rows)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    pallaList.forEachIndexed { index, item ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 6.dp, vertical = 6.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "পাল্লা নং #${index + 1}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF15803D)
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    // ১ম ঘর: পিস (ইচ্ছেমতো সংখ্যা)
                                    CompactTableCellInput(
                                        value = item.piecesText,
                                        onValueChange = { newPcs ->
                                            pallaList[index] = item.copy(piecesText = newPcs)
                                        },
                                        placeholder = "পিস",
                                        keyboardType = KeyboardType.Number,
                                        modifier = Modifier
                                            .weight(0.95f)
                                            .testTag("editable_palla_pieces_${index + 1}")
                                    )

                                    // ২য় ঘর: ওজন (কেজি)
                                    CompactTableCellInput(
                                        value = item.weightKgText,
                                        onValueChange = { newWt ->
                                            pallaList[index] = item.copy(weightKgText = newWt)
                                        },
                                        placeholder = "কেজি",
                                        keyboardType = KeyboardType.Decimal,
                                        modifier = Modifier
                                            .weight(1.1f)
                                            .testTag("editable_palla_weight_${index + 1}")
                                    )

                                    // ৩য় ঘর: গড় (অটোমেটিক ভাবে)
                                    Box(
                                        modifier = Modifier
                                            .weight(1.05f)
                                            .height(40.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFFFEF3C7))
                                            .border(1.dp, Color(0xFFF59E0B), RoundedCornerShape(8.dp))
                                            .padding(horizontal = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(
                                                text = "${String.format(Locale.US, "%.2f", item.avgPerBirdKg)} কেজি",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = Color(0xFF92400E),
                                                maxLines = 1
                                            )
                                            Text(
                                                text = "${(item.avgPerBirdKg * 1000).toInt()} গ্রাম",
                                                style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.SemiBold),
                                                color = Color(0xFFB45309),
                                                maxLines = 1
                                            )
                                        }
                                    }

                                    // ৪র্থ ঘর: মন্তব্য (ঐচ্ছিক)
                                    CompactTableCellInput(
                                        value = item.remarkText,
                                        onValueChange = { newRemark ->
                                            pallaList[index] = item.copy(remarkText = newRemark)
                                        },
                                        placeholder = "মন্তব্য",
                                        keyboardType = KeyboardType.Text,
                                        modifier = Modifier
                                            .weight(1.25f)
                                            .testTag("editable_palla_remark_${index + 1}")
                                    )

                                    // রো মুছুন বাটন
                                    IconButton(
                                        onClick = { pallaList.removeAt(index) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "পাল্লা বাদ দিন",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // নতুন পাল্লা যোগ করার বাটন
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            nextUid += 1L
                            pallaList.add(
                                EditablePallaItem(
                                    uid = nextUid,
                                    piecesText = "",
                                    weightKgText = "",
                                    remarkText = ""
                                )
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF15803D),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("add_single_palla_btn")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("নতুন পাল্লা (৪ ঘরের লাইন) যোগ করুন", fontWeight = FontWeight.Bold)
                    }

                    if (pallaList.isNotEmpty()) {
                        OutlinedButton(
                            onClick = { pallaList.clear() },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("সব মুছুন")
                        }
                    }
                }

                // সর্বমোট পাল্লা, পিস, ওজন ও অটোমেটিক গড় সামারি বক্স
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFFECFDF5),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "সর্বমোট চূড়ান্ত হিসাব (অটোমেটিক):",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF14532D)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("কত পাল্লা দিলাম:", style = MaterialTheme.typography.bodySmall, color = Color(0xFF166534))
                            Text("$totalPallaCount টি পাল্লা", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.ExtraBold, color = Color(0xFF14532D))
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("১ম ঘর মোট পিস:", style = MaterialTheme.typography.bodySmall, color = Color(0xFF166534))
                            Text("$totalPieces পিস", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.ExtraBold, color = Color(0xFF14532D))
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("২য় ঘর মোট ওজন (কেজি):", style = MaterialTheme.typography.bodySmall, color = Color(0xFF166534))
                            Text("${String.format(Locale.US, "%.2f", totalWeightKg)} কেজি", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.ExtraBold, color = Color(0xFF15803D))
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("৩য় ঘর গড় ওজন (অটোমেটিক):", style = MaterialTheme.typography.bodySmall, color = Color(0xFF166534))
                            Text(
                                text = "${String.format(Locale.US, "%.2f", avgWeightPerBirdKg)} কেজি/পিস (${(avgWeightPerBirdKg * 1000).toInt()} গ্রাম)",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFFD97706)
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("প্রতি পাল্লা গড় ওজন (অটো):", style = MaterialTheme.typography.bodySmall, color = Color(0xFF166534))
                            Text(
                                text = "${String.format(Locale.US, "%.2f", avgWeightPerPallaKg)} কেজি / পাল্লা",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0284C7)
                            )
                        }
                        HorizontalDivider(color = Color(0xFFBBF7D0))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "মোট বিক্রয় মূল্য (@ ৳${String.format(Locale.US, "%.0f", pricePerKg)}/কেজি):",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF14532D)
                            )
                            Text(
                                text = formatCurrencyBdt(totalAmountBdt),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF15803D)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (validPallas.isNotEmpty() && totalWeightKg > 0.0) {
                        val breakdown = validPallas.mapIndexed { idx, entry ->
                            val wStr = String.format(Locale.US, "%.2f", entry.weightKg)
                            val avgStr = String.format(Locale.US, "%.2f", entry.avgPerBirdKg)
                            val cleanRemark = entry.remarkText.replace("|", " ").replace("~", " ").trim()
                            "পাল্লা-${idx + 1}~${entry.pieces}~$wStr~$avgStr~$cleanRemark"
                        }.joinToString("|")

                        onConfirmSale(
                            buyerName,
                            saleDateLabel,
                            selectedShedName,
                            totalPallaCount,
                            totalPieces,
                            totalWeightKg,
                            avgWeightPerBirdKg,
                            avgWeightPerPallaKg,
                            pricePerKg,
                            totalAmountBdt,
                            breakdown,
                            initialSaleToEdit?.id ?: 0L
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF15803D),
                    contentColor = Color.White
                ),
                modifier = Modifier.testTag("confirm_palla_sale_btn")
            ) {
                Text(
                    text = if (initialSaleToEdit != null) "পরিবর্তন সংরক্ষণ করুন" else "চালান ও বিক্রি সংরক্ষণ করুন",
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}

@Composable
private fun CompactTableCellInput(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    keyboardType: KeyboardType,
    modifier: Modifier = Modifier
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        textStyle = TextStyle(
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        ),
        decorationBox = { innerTextField ->
            Box(
                modifier = Modifier
                    .height(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White)
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                if (value.isEmpty()) {
                    Text(
                        text = placeholder,
                        style = TextStyle(fontSize = 11.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        maxLines = 1
                    )
                }
                innerTextField()
            }
        },
        modifier = modifier
    )
}

/**
 * বাকি সব বিক্রি ও খরচের জন্য ৪ ঘরের স্মার্ট ছক ডায়ালগ:
 * - খুচরা মুরগি বিক্রি: ১ম ঘর পিস/কেজি | ২য় ঘর ওজন (কেজি) | ৩য় ঘর গড় (অটোমেটিক) | ৪র্থ ঘর মন্তব্য (ঐচ্ছিক)
 * - ফিড বিক্রি / ফিড ক্রয়: ১ম ঘর বস্তা | ২য় ঘর ওজন (কেজি) | ৩য় ঘর গড় কেজি/বস্তা (অটোমেটিক) | ৪র্থ ঘর মন্তব্য (ঐচ্ছিক)
 * - লিটার/ব্যবহৃত গুঁড়া বিক্রি / কাঠের গুঁড়া কেনা: ১ম ঘর বস্তা | ২য় ঘর ওজন (কেজি) বা মোট টাকা | ৩য় ঘর গড় (অটোমেটিক) | ৪র্থ ঘর মন্তব্য (ঐচ্ছিক)
 * - বাচ্চা ক্রয় / কর্মচারী বেতন / যাতায়াত ভাড়া: ১ম ঘর পিস/জন/ট্রিপ | ২য় ঘর মোট টাকা (৳) | ৩য় ঘর গড় (অটোমেটিক) | ৪র্থ ঘর মন্তব্য (ঐচ্ছিক)
 */
@Composable
fun SmartFourBoxTransactionDialog(
    initialIsIncome: Boolean,
    initialCategory: String,
    onDismiss: () -> Unit,
    onOpenMultiPallaSaleInstead: (() -> Unit)? = null,
    onConfirm: (
        title: String,
        category: String,
        isIncome: Boolean,
        amountBdt: Double,
        quantityNote: String,
        partyName: String
    ) -> Unit
) {
    val saleCategories = listOf(
        "মুরগি বিক্রি",
        "ফিড বিক্রি",
        "কাঠের গুঁড়া বা লিটার বিক্রি",
        "খুচরা মুরগি বিক্রি"
    )
    val expenseCategories = listOf(
        "বাচ্চা কেনা",
        "ফিড কেনা",
        "মেডিসিন কেনা",
        "কাঠের গুঁড়া কেনা",
        "পরিবহন ব্যয় বা ভাড়া",
        "কর্মচারী বেতন",
        "অন্যান্য খরচ"
    )

    var isIncome by remember { mutableStateOf(initialIsIncome) }
    var category by remember { mutableStateOf(initialCategory) }

    // Configure labels & units dynamically according to category
    val isWeightSecondBox = category in listOf(
        "খুচরা মুরগি বিক্রি",
        "মুরগি বিক্রি",
        "ফিড বিক্রি",
        "ফিড কেনা",
        "ফিড ক্রয়",
        "কাঠের গুঁড়া বা লিটার বিক্রি",
        "লিটার/ব্যবহৃত গুঁড়া বিক্রি",
        "কাঠের গুঁড়া কেনা"
    )

    val box1HeaderShort = when (category) {
        "খুচরা মুরগি বিক্রি", "মুরগি বিক্রি", "বাচ্চা কেনা", "বাচ্চা ক্রয়" -> "১ম: পিস"
        "ফিড বিক্রি", "ফিড কেনা", "ফিড ক্রয়", "কাঠের গুঁড়া কেনা", "কাঠের গুঁড়া বা লিটার বিক্রি", "লিটার/ব্যবহৃত গুঁড়া বিক্রি" -> "১ম: বস্তা"
        "কর্মচারী বেতন" -> "১ম: জন"
        "পরিবহন ব্যয় বা ভাড়া", "যাতায়াত ভাড়া" -> "১ম: ট্রিপ"
        else -> "১ম: সংখ্যা"
    }
    val box1UnitShort = when (category) {
        "খুচরা মুরগি বিক্রি", "মুরগি বিক্রি", "বাচ্চা কেনা", "বাচ্চা ক্রয়" -> "পিস"
        "ফিড বিক্রি", "ফিড কেনা", "ফিড ক্রয়", "কাঠের গুঁড়া কেনা", "কাঠের গুঁড়া বা লিটার বিক্রি", "লিটার/ব্যবহৃত গুঁড়া বিক্রি" -> "বস্তা"
        "কর্মচারী বেতন" -> "জন"
        "পরিবহন ব্যয় বা ভাড়া", "যাতায়াত ভাড়া" -> "ট্রিপ"
        else -> "ইউনিট"
    }
    val box2HeaderShort = if (isWeightSecondBox) "২য়: ওজন (কেজি)" else "২য়: মোট টাকা (৳)"
    val box2UnitShort = if (isWeightSecondBox) "কেজি" else "৳"
    val box3HeaderShort = "৩য়: গড় (অটো)"
    val box4HeaderShort = "৪র্থ: মন্তব্য (ঐচ্ছিক)"

    var box1CountInput by remember(category) {
        mutableStateOf(
            when (category) {
                "খুচরা মুরগি বিক্রি", "মুরগি বিক্রি" -> "10"
                "ফিড বিক্রি" -> "4"
                "কাঠের গুঁড়া বা লিটার বিক্রি", "লিটার/ব্যবহৃত গুঁড়া বিক্রি" -> "50"
                "ফিড কেনা", "ফিড ক্রয়" -> "20"
                "বাচ্চা কেনা", "বাচ্চা ক্রয়" -> "1000"
                "কাঠের গুঁড়া কেনা" -> "40"
                "কর্মচারী বেতন" -> "2"
                "পরিবহন ব্যয় বা ভাড়া", "যাতায়াত ভাড়া" -> "1"
                else -> "1"
            }
        )
    }

    var box2ValueInput by remember(category) {
        mutableStateOf(
            when (category) {
                "খুচরা মুরগি বিক্রি", "মুরগি বিক্রি" -> "18.50" // কেজি
                "ফিড বিক্রি" -> "200"           // কেজি (৪ বস্তা × ৫০ কেজি)
                "কাঠের গুঁড়া বা লিটার বিক্রি", "লিটার/ব্যবহৃত গুঁড়া বিক্রি" -> "1500" // কেজি
                "ফিড কেনা", "ফিড ক্রয়" -> "1000" // কেজি (২০ বস্তা × ৫০ কেজি)
                "কাঠের গুঁড়া কেনা" -> "1000"    // কেজি
                "বাচ্চা কেনা", "বাচ্চা ক্রয়" -> "48000" // মোট টাকা (৳)
                "কর্মচারী বেতন" -> "24000"      // মোট টাকা (৳)
                "পরিবহন ব্যয় বা ভাড়া", "যাতায়াত ভাড়া" -> "2500" // মোট টাকা (৳)
                "মেডিসিন কেনা", "ওষুধ ও টিকা" -> "3500"
                "অন্যান্য খরচ", "বিদ্যুৎ ও অন্যান্য" -> "2000"
                else -> "1500"
            }
        )
    }

    var box4RemarkInput by remember(category) {
        mutableStateOf("")
    }

    var rateInput by remember(category) {
        mutableStateOf(
            when (category) {
                "খুচরা মুরগি বিক্রি", "মুরগি বিক্রি" -> "190" // ৳/কেজি
                "ফিড বিক্রি" -> "3450"        // ৳/বস্তা
                "কাঠের গুঁড়া বা লিটার বিক্রি", "লিটার/ব্যবহৃত গুঁড়া বিক্রি" -> "80" // ৳/বস্তা
                "ফিড কেনা", "ফিড ক্রয়" -> "3350" // ৳/বস্তা
                "কাঠের গুঁড়া কেনা" -> "145"   // ৳/বস্তা
                else -> ""
            }
        )
    }

    val isPerKgPriced = category == "খুচরা মুরগি বিক্রি" || category == "মুরগি বিক্রি"
    val rateLabel = if (isPerKgPriced) "দর (৳/কেজি)" else "প্রতি $box1UnitShort দর (৳/$box1UnitShort)"

    val countVal = normalizeDigits(box1CountInput).toDoubleOrNull() ?: 0.0
    val box2Val = normalizeDigits(box2ValueInput).toDoubleOrNull() ?: 0.0
    val rateVal = normalizeDigits(rateInput).toDoubleOrNull() ?: 0.0

    // ৩য় ঘর: গড় (অটোমেটিক ভাবে)
    val autoAverageVal = if (countVal > 0.0) box2Val / countVal else 0.0
    val autoAverageDisplayText = if (isWeightSecondBox) {
        "${String.format(Locale.US, "%.2f", autoAverageVal)} কেজি/$box1UnitShort"
    } else {
        "৳${String.format(Locale.US, "%.0f", autoAverageVal)}/$box1UnitShort"
    }

    val autoTotalAmountBdt = when {
        isPerKgPriced -> box2Val * rateVal // কেজি × কেজি দর
        isWeightSecondBox -> countVal * rateVal // বস্তা × বস্তা দর
        else -> box2Val // ২য় ঘরে সরাসরি মোট টাকা
    }

    var manualAmountOverride by remember(category) { mutableStateOf("") }
    val finalAmountBdt = normalizeDigits(manualAmountOverride).toDoubleOrNull() ?: autoTotalAmountBdt
    var partyName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = "$category (৪ ঘরের হিসাব ছক)",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "১ম ঘরে $box1UnitShort • ২য় ঘরে ${if (isWeightSecondBox) "ওজন (কেজি)" else "মোট টাকা"} • ৩য় ঘরে গড় (অটোমেটিক) • ৪র্থ ঘরে মন্তব্য (ঐচ্ছিক)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // আয় বা ব্যয় এবং খাত বাছাই
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = isIncome,
                        onClick = {
                            isIncome = true
                            category = saleCategories.first()
                        },
                        label = { Text("বিক্রি (আয়)") }
                    )
                    FilterChip(
                        selected = !isIncome,
                        onClick = {
                            isIncome = false
                            category = expenseCategories.first()
                        },
                        label = { Text("খরচ (ব্যয়)") }
                    )
                }

                val activeList = if (isIncome) saleCategories else expenseCategories
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    activeList.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = {
                                if (cat == "মুরগি বিক্রি" && onOpenMultiPallaSaleInstead != null) {
                                    onOpenMultiPallaSaleInstead()
                                } else {
                                    category = cat
                                }
                            },
                            label = { Text(cat) }
                        )
                    }
                }

                HorizontalDivider()

                // ৪টি ঘরের এক লাইনের ছক হেডার (১ম ঘর | ২য় ঘর | ৩য় ঘর গড় অটো | ৪র্থ ঘর মন্তব্য ঐচ্ছিক)
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isIncome) Color(0xFF0F766E) else Color(0xFFB91C1C),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = box1HeaderShort,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(0.95f)
                        )
                        Text(
                            text = box2HeaderShort,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1.1f)
                        )
                        Text(
                            text = box3HeaderShort,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFFDE047),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1.1f)
                        )
                        Text(
                            text = box4HeaderShort,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1.25f)
                        )
                    }
                }

                // ৪টি ঘরের এক লাইনের ইনপুট রো (পাশাপাশি ৪টি ঘর)
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // ১ম ঘর: পিস / বস্তা / জন / ট্রিপ
                        CompactTableCellInput(
                            value = box1CountInput,
                            onValueChange = {
                                box1CountInput = it
                                if (category == "ফিড বিক্রি" || category == "ফিড কেনা" || category == "ফিড ক্রয়") {
                                    val bags = normalizeDigits(it).toDoubleOrNull() ?: 0.0
                                    if (bags > 0) {
                                        box2ValueInput = String.format(Locale.US, "%.0f", bags * 50.0)
                                    }
                                }
                            },
                            placeholder = box1UnitShort,
                            keyboardType = KeyboardType.Number,
                            modifier = Modifier
                                .weight(0.95f)
                                .testTag("four_box_col1_input")
                        )

                        // ২য় ঘর: ওজন (কেজি) অথবা মোট টাকা (৳)
                        CompactTableCellInput(
                            value = box2ValueInput,
                            onValueChange = { box2ValueInput = it },
                            placeholder = box2UnitShort,
                            keyboardType = KeyboardType.Decimal,
                            modifier = Modifier
                                .weight(1.1f)
                                .testTag("four_box_col2_input")
                        )

                        // ৩য় ঘর: গড় (অটোমেটিক ভাবে)
                        Box(
                            modifier = Modifier
                                .weight(1.1f)
                                .height(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFFEF3C7))
                                .border(1.dp, Color(0xFFF59E0B), RoundedCornerShape(8.dp))
                                .padding(horizontal = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = autoAverageDisplayText,
                                    style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.ExtraBold),
                                    color = Color(0xFF92400E),
                                    maxLines = 1
                                )
                                if (isPerKgPriced) {
                                    Text(
                                        text = "${(autoAverageVal * 1000).toInt()} গ্রাম/পিস",
                                        style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.SemiBold),
                                        color = Color(0xFFB45309),
                                        maxLines = 1
                                    )
                                }
                            }
                        }

                        // ৪র্থ ঘর: মন্তব্য (ঐচ্ছিক)
                        CompactTableCellInput(
                            value = box4RemarkInput,
                            onValueChange = { box4RemarkInput = it },
                            placeholder = "মন্তব্য",
                            keyboardType = KeyboardType.Text,
                            modifier = Modifier
                                .weight(1.25f)
                                .testTag("four_box_col4_remark_input")
                        )
                    }
                }

                // দর ও মোট টাকার অটো হিসাব
                if (isWeightSecondBox) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = rateInput,
                            onValueChange = { rateInput = it },
                            label = { Text(rateLabel) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = manualAmountOverride.ifBlank {
                                String.format(Locale.US, "%.0f", autoTotalAmountBdt)
                            },
                            onValueChange = { manualAmountOverride = it },
                            label = { Text("মোট টাকা (৳ অটো)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("tx_amount_input")
                        )
                    }
                }

                OutlinedTextField(
                    value = partyName,
                    onValueChange = { partyName = it },
                    label = { Text("ক্রেতা / ডিলার / কর্মচারীর নাম (ঐচ্ছিক)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // ৪ ঘরের লাইভ প্রিভিউ সামারি
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isIncome) Color(0xFFECFDF5) else Color(0xFFFEF2F2),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "৪ ঘরের চূড়ান্ত হিসাব সারাংশ:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isIncome) Color(0xFF14532D) else Color(0xFF991B1B)
                        )
                        Text(
                            text = "১ম ঘর: ${countVal.toInt()} $box1UnitShort • ২য় ঘর: ${
                                if (isWeightSecondBox) "${String.format(Locale.US, "%.2f", box2Val)} কেজি" else formatCurrencyBdt(box2Val)
                            } • ৩য় ঘর (গড় অটো): $autoAverageDisplayText • ৪র্থ ঘর (মন্তব্য): ${box4RemarkInput.ifBlank { "—" }}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "মোট টাকার পরিমাণ: ${formatCurrencyBdt(finalAmountBdt)}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isIncome) Color(0xFF15803D) else Color(0xFFDC2626)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (finalAmountBdt > 0.0) {
                        val countClean = countVal.toInt()
                        val col1Str = "$countClean $box1UnitShort"
                        val col2Str = if (isWeightSecondBox) {
                            "${String.format(Locale.US, "%.2f", box2Val)} কেজি"
                        } else {
                            formatCurrencyBdt(box2Val)
                        }
                        val col3Str = autoAverageDisplayText
                        val col4Str = box4RemarkInput.replace("~", " ").trim().ifBlank { "—" }

                        val structuredFourBoxNote = "$col1Str~$col2Str~$col3Str~$col4Str"
                        val autoTitle = "$category ($col1Str • $col2Str)"

                        onConfirm(
                            autoTitle,
                            category,
                            isIncome,
                            finalAmountBdt,
                            structuredFourBoxNote,
                            partyName.ifBlank { col4Str }
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isIncome) Color(0xFF15803D) else Color(0xFFDC2626),
                    contentColor = Color.White
                ),
                modifier = Modifier.testTag("confirm_add_tx_btn")
            ) {
                Text("৪ ঘরের হিসাব সংরক্ষণ করুন", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}
