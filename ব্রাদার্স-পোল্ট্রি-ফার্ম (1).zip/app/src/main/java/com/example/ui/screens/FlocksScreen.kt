package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.HomeWork
import androidx.compose.material.icons.filled.MonitorWeight
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.FlockEntity
import com.example.viewmodel.PoultryUiState
import java.util.Locale

@Composable
fun FlocksScreen(
    uiState: PoultryUiState,
    onBreedFilterChange: (String) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onAddFlock: (String, String, String, Int, Int, Int, Int, Double, String, String, String) -> Unit,
    onDeleteFlock: (FlockEntity) -> Unit,
    onAddDailyLog: (FlockEntity, String, Int, Double, Double, Int, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddFlockDialog by rememberSaveable { mutableStateOf(false) }
    var flockForLog by remember { mutableStateOf<FlockEntity?>(null) }

    val broilerBreeds = listOf("সব জাত", "কব-৫০০", "রস-৩০৮", "হাবার্ড", "আর্বার একরস")

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddFlockDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_flock_fab")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Add, contentDescription = "নতুন ব্রয়লার ব্যাচ যোগ করুন")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("নতুন ব্রয়লার ব্যাচ", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("flocks_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = { Text("শেড নম্বর, ব্যাচ বা বাচ্চা আসার তারিখ খুঁজুন...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("flock_search_input")
                )
            }

            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    broilerBreeds.forEach { breed ->
                        FilterChip(
                            selected = uiState.selectedBreedFilter == breed,
                            onClick = { onBreedFilterChange(breed) },
                            label = { Text(breed) },
                            modifier = Modifier.testTag("filter_chip_$breed")
                        )
                    }
                }
            }

            if (uiState.flocks.isEmpty()) {
                item {
                    ElevatedCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Pets,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "কোনো ব্রয়লার ব্যাচ পাওয়া যায়নি",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "নিচের '+ নতুন ব্রয়লার ব্যাচ' বাটনে ট্যাপ করে নতুন শেড যোগ করুন।",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(uiState.flocks, key = { it.id }) { flock ->
                    BroilerBatchDetailCard(
                        flock = flock,
                        onLogClick = { flockForLog = flock },
                        onDeleteClick = { onDeleteFlock(flock) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(76.dp))
            }
        }
    }

    if (showAddFlockDialog) {
        AddBroilerBatchDialog(
            onDismiss = { showAddFlockDialog = false },
            onConfirm = { name, shed, breed, count, age, targetSaleDays, weight, chickPrice, arrivalDate, hatchery, notes ->
                onAddFlock(name, shed, breed, count, age, targetSaleDays, weight, chickPrice, arrivalDate, hatchery, notes)
                showAddFlockDialog = false
            }
        )
    }

    flockForLog?.let { selectedFlock ->
        RecordBroilerLogDialog(
            flocks = listOf(selectedFlock),
            onDismiss = { flockForLog = null },
            onConfirm = { flock, feedPhase, mortality, feedKg, waterLiters, avgWeight, medicine, remarks ->
                onAddDailyLog(flock, feedPhase, mortality, feedKg, waterLiters, avgWeight, medicine, remarks)
                flockForLog = null
            }
        )
    }
}

@Composable
private fun BroilerBatchDetailCard(
    flock: FlockEntity,
    onLogClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val survivalRate = if (flock.initialCount > 0) {
        (flock.currentCount.toFloat() / flock.initialCount.toFloat()).coerceIn(0f, 1f)
    } else 1f

    val totalLiveWeightKg = (flock.currentCount * flock.avgWeightGrams) / 1000.0
    val batchFcr = if (totalLiveWeightKg > 0) flock.totalFeedConsumedKg / totalLiveWeightKg else 0.0
    val totalFeedBags = flock.totalFeedConsumedKg / 50.0

    val stageLabel = when {
        flock.ageInDays <= 10 -> "ব্রুডিং / প্রি-স্টার্টার পর্যায়"
        flock.ageInDays <= 20 -> "গ্রোয়ার পর্যায়"
        flock.ageInDays < flock.targetSaleDays -> "ফিনিশার পর্যায়"
        else -> "বিক্রির উপযোগী (Ready)"
    }

    val stageColor = when {
        flock.ageInDays <= 10 -> Color(0xFFD97706)
        flock.ageInDays <= 20 -> Color(0xFF0284C7)
        else -> Color(0xFF15803D)
    }

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("flock_card_${flock.id}"),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(stageColor.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.HomeWork,
                            contentDescription = flock.breed,
                            tint = stageColor
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = flock.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "${flock.shedNumber} • ${flock.breed} • ${flock.hatcheryName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    color = stageColor.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = "বয়স: ${flock.ageInDays}/${flock.targetSaleDays} দিন",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = stageColor,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Highlighted Chick Arrival Date & Stage Banner
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFEF3C7),
                    contentColor = Color(0xFF92400E)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "বাচ্চার আসার দিন: ${flock.startDateLabel}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = stageColor.copy(alpha = 0.1f)
                ) {
                    Text(
                        text = stageLabel,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = stageColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                FlockStatColumn(
                    label = "জীবিত ব্রয়লার",
                    value = "${flock.currentCount} / ${flock.initialCount} টি"
                )
                FlockStatColumn(
                    label = "গড় ও মোট ওজন",
                    value = "${flock.avgWeightGrams} গ্রা. (${totalLiveWeightKg.toInt()} কেজি)"
                )
                FlockStatColumn(
                    label = "খাবার ও FCR",
                    value = "${String.format(Locale.US, "%.1f", totalFeedBags)} বস্তা • FCR ${String.format(Locale.US, "%.2f", batchFcr)}"
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "জীবিত থাকার হার: ${String.format(Locale.US, "%.1f", survivalRate * 100)}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "বাচ্চার দর: ৳${flock.chickPricePerBird.toInt()}/পিস",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { survivalRate },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(7.dp)
                        .clip(RoundedCornerShape(50)),
                    color = stageColor,
                    trackColor = stageColor.copy(alpha = 0.16f)
                )
            }

            if (flock.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "নোট: ${flock.notes}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onLogClick,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("flock_log_btn_${flock.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.EditNote,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("আজকের খাবার ও ওজন লগ")
                }

                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier.testTag("delete_flock_btn_${flock.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "ব্যাচ মুছুন",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

@Composable
private fun FlockStatColumn(
    label: String,
    value: String
) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun AddBroilerBatchDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, Int, Int, Int, Int, Double, String, String, String) -> Unit
) {
    val breeds = listOf("কব-৫০০ (Cobb-500)", "রস-৩০৮ (Ross-308)", "হাবার্ড (Hubbard)", "আর্বার একরস (Arbor Acres)")
    var selectedBreed by remember { mutableStateOf(breeds.first()) }
    var name by remember { mutableStateOf("") }
    var shedNumber by remember { mutableStateOf("শেড-০৪") }
    var arrivalDate by remember { mutableStateOf("২৮ সেপ্টেম্বর ২০২৬") }
    var hatcheryName by remember { mutableStateOf("কাজী হ্যাচারি (A-Grade)") }
    var initialCount by remember { mutableStateOf("1500") }
    var ageInDays by remember { mutableStateOf("1") }
    var targetSaleDays by remember { mutableStateOf("32") }
    var avgWeightGrams by remember { mutableStateOf("44") }
    var chickPricePerBird by remember { mutableStateOf("48") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "নতুন ব্রয়লার ব্যাচ যোগ করুন",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "ব্রয়লারের জাত (Strain) নির্বাচন করুন:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    breeds.forEach { breed ->
                        FilterChip(
                            selected = selectedBreed == breed,
                            onClick = { selectedBreed = breed },
                            label = { Text(breed) }
                        )
                    }
                }

                OutlinedTextField(
                    value = arrivalDate,
                    onValueChange = { arrivalDate = it },
                    label = { Text("বাচ্চার আসার দিন (তারিখ)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("ব্যাচের নাম (যেমন: কব-৫০০ ব্যাচ #১৭)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_flock_name")
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = shedNumber,
                        onValueChange = { shedNumber = it },
                        label = { Text("শেড নম্বর") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = initialCount,
                        onValueChange = { initialCount = it },
                        label = { Text("বাচ্চা সংখ্যা (পিস)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_flock_count")
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = ageInDays,
                        onValueChange = { ageInDays = it },
                        label = { Text("বর্তমান বয়স (দিন)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = targetSaleDays,
                        onValueChange = { targetSaleDays = it },
                        label = { Text("বিক্রির বয়স (দিন)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = avgWeightGrams,
                        onValueChange = { avgWeightGrams = it },
                        label = { Text("গড় ওজন (গ্রাম)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = chickPricePerBird,
                        onValueChange = { chickPricePerBird = it },
                        label = { Text("বাচ্চার দর (৳/পিস)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = hatcheryName,
                    onValueChange = { hatcheryName = it },
                    label = { Text("হ্যাচারির নাম") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ব্রুডিং নোট") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val count = initialCount.toIntOrNull() ?: 500
                    val age = ageInDays.toIntOrNull() ?: 1
                    val saleDays = targetSaleDays.toIntOrNull() ?: 32
                    val weight = avgWeightGrams.toIntOrNull() ?: 44
                    val chickPrice = chickPricePerBird.toDoubleOrNull() ?: 48.0
                    val finalName = name.ifBlank { "$selectedBreed ব্যাচ" }
                    onConfirm(
                        finalName,
                        shedNumber,
                        selectedBreed,
                        count,
                        age,
                        saleDays,
                        weight,
                        chickPrice,
                        arrivalDate,
                        hatcheryName,
                        notes
                    )
                },
                modifier = Modifier.testTag("confirm_add_flock_btn")
            ) {
                Text("যোগ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}
