package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Forest Emerald & Warm Harvest Gold Palette for Brothers Poultry Farm
val FarmGreenPrimary = Color(0xFF1B4332)
val FarmGreenSecondary = Color(0xFF2D6A4F)
val FarmGreenLight = Color(0xFFD8F3DC)
val FarmMintContainer = Color(0xFFE9F5EC)

val HarvestGold = Color(0xFFD97706)
val HarvestGoldLight = Color(0xFFFEF3C7)
val TerracottaAccent = Color(0xFFC2410C)
val TerracottaLight = Color(0xFFFFEDD5)

val CreamBackground = Color(0xFFFAF8F3)
val WarmSurface = Color(0xFFFFFFFF)
val WarmSurfaceVariant = Color(0xFFF2EFE9)
val TextDarkForest = Color(0xFF132A1E)
val TextMutedOlive = Color(0xFF4A5D52)

// Dark Theme Colors
val DarkGreenPrimary = Color(0xFF74C69D)
val DarkGreenSecondary = Color(0xFF52B788)
val DarkGreenContainer = Color(0xFF1B4332)
val DarkGoldTertiary = Color(0xFFFBBF24)
val DarkBackground = Color(0xFF0F1C15)
val DarkSurface = Color(0xFF16271E)
val DarkSurfaceVariant = Color(0xFF21382C)

// Semantic Status Colors
val ProfitGreen = Color(0xFF15803D)
val ExpenseRed = Color(0xFFB91C1C)
val WarningAmber = Color(0xFFB45309)
