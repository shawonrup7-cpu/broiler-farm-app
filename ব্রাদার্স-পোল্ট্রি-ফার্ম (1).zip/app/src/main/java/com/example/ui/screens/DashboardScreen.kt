package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Grass
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.MonitorWeight
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.BroilerSaleEntity
import com.example.data.DailyLogEntity
import com.example.data.DailyMedicineEntity
import com.example.data.FlockEntity
import com.example.viewmodel.PoultryUiState
import java.text.NumberFormat
import java.util.Locale

@Composable
fun DashboardScreen(
    uiState: PoultryUiState,
    onAddDailyLog: (FlockEntity, String, Int, Double, Double, Int, String, String) -> Unit,
    onDeleteDailyLog: (DailyLogEntity) -> Unit,
    onQuickAddTransaction: (String, String, Boolean, Double, String, String) -> Unit,
    onAddBroilerPallaSale: (String, String, String, Int, Int, Double, Double, Double, Double, Double, String, Long) -> Unit,
    onDeleteBroilerSale: (BroilerSaleEntity) -> Unit,
    onAddDailyMedicine: (String, String, String, String, String, String) -> Unit,
    onToggleDailyMedicine: (DailyMedicineEntity) -> Unit,
    onDeleteDailyMedicine: (DailyMedicineEntity) -> Unit,
    onAddFlockClick: (String, String, String, Int, Int, Int, Int, Double, String, String, String) -> Unit,
    onOpenEditAppName: () -> Unit = {},
    onNavigateToFlocks: () -> Unit,
    onNavigateToFinance: () -> Unit,
    onNavigateToHealth: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showDailyLogDialog by rememberSaveable { mutableStateOf(false) }
    var showPallaSaleDialog by rememberSaveable { mutableStateOf(false) }
    var editingPallaSale by remember { mutableStateOf<BroilerSaleEntity?>(null) }
    var showQuickTxDialog by rememberSaveable { mutableStateOf(false) }
    var quickTxDefaultIncome by rememberSaveable { mutableStateOf(true) }
    var quickTxDefaultCategory by rememberSaveable { mutableStateOf("খুচরা মুরগি বিক্রি") }
    var showAddMedicineDialog by rememberSaveable { mutableStateOf(false) }
    var showAddChickArrivalDialog by rememberSaveable { mutableStateOf(false) }
    var selectedMedicineTimeFilter by rememberSaveable { mutableStateOf("সব সময়") }

    val openOtherSaleDialog: (String) -> Unit = { category ->
        if (category == "মুরগি বিক্রি") {
            editingPallaSale = null
            showPallaSaleDialog = true
        } else {
            quickTxDefaultIncome = true
            quickTxDefaultCategory = category
            showQuickTxDialog = true
        }
    }

    val openExpenseDialog: (String) -> Unit = { category ->
        quickTxDefaultIncome = false
        quickTxDefaultCategory = category
        showQuickTxDialog = true
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Hero Banner with Quick Action Buttons
        item {
            BroilerHeroBannerCard(
                appName = uiState.customAppName,
                activeFlockCount = uiState.flocks.size,
                totalBirds = uiState.totalActiveBirds,
                mortalityRatePercent = uiState.overallMortalityRatePercent,
                onEditAppNameClick = onOpenEditAppName,
                onLogTodayClick = { showDailyLogDialog = true },
                onQuickPallaSaleClick = { showPallaSaleDialog = true },
                onQuickExpenseClick = { openExpenseDialog("ফিড কেনা") },
                onAddMedicineClick = { showAddMedicineDialog = true }
            )
        }

        // 2. Top Broiler KPI Grid (জীবিত মুরগি, মৃত্যু হার %, মোট জীবন্ত ওজন, FCR)
        item {
            BroilerKpiGridSection(uiState = uiState)
        }

        // 3. ড্যাশবোর্ডে মৃত্যু হার (Mortality Rate & Per-Shed Dead Bird Breakdown)
        item {
            DashboardMortalitySummaryCard(
                uiState = uiState,
                onRecordMortalityClick = { showDailyLogDialog = true }
            )
        }

        // 4. মুরগি বিক্রি (ইচ্ছেমতো পিস ও পাল্লা ওজন, ক্রেতার নাম, তারিখ, ওজন, পিস, কত পাল্লা, মোট কেজি, গড়) ও অন্যান্য বিক্রি ঘর
        item {
            BroilerSalesAndOtherSalesCard(
                uiState = uiState,
                onOpenPallaSaleDialog = {
                    editingPallaSale = null
                    showPallaSaleDialog = true
                },
                onEditBroilerSale = { saleToEdit ->
                    editingPallaSale = saleToEdit
                    showPallaSaleDialog = true
                },
                onDeleteBroilerSale = onDeleteBroilerSale,
                onAddOtherSaleCategory = openOtherSaleDialog,
                onViewAllFinance = onNavigateToFinance
            )
        }

        // 5. জীবিত মুরগির এখন পর্যন্ত কত খরচ (Total Cost of Live Chickens So Far + কর্মচারী বেতন, কাঠের গুঁড়া কেনা, যাতায়াত ভাড়া)
        item {
            LiveBroilerExpenseBreakdownCard(
                uiState = uiState,
                onAddExpenseCategory = openExpenseDialog,
                onViewAllFinance = onNavigateToFinance
            )
        }

        // 6. বাচ্চার আসার দিন ও সচল ব্রয়লার ব্যাচ (Chick Arrival Date & Active Batches)
        item {
            ChickArrivalAndBatchesCard(
                flocks = uiState.flocks,
                totalActiveBirds = uiState.totalActiveBirds,
                totalExpenseBdt = uiState.totalExpenseBdt,
                onAddNewBatchClick = { showAddChickArrivalDialog = true },
                onViewAllBatchesClick = onNavigateToFlocks
            )
        }

        // 7. প্রতিদিনের ঔষধ শিডিউল (Daily Medicine Schedule - সকাল, দুপুর, রাত)
        item {
            DailyMedicineScheduleDashboardCard(
                medicines = uiState.dailyMedicines,
                selectedTimeFilter = selectedMedicineTimeFilter,
                onSelectTimeFilter = { selectedMedicineTimeFilter = it },
                onAddMedicineClick = { showAddMedicineDialog = true },
                onToggleMedicine = onToggleDailyMedicine,
                onDeleteMedicine = onDeleteDailyMedicine,
                onViewVaccinesClick = onNavigateToHealth
            )
        }

        // 8. প্রতিদিনের শেড লগ (Recent Daily Logs)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "প্রতিদিনের ব্রয়লার শেড লগ",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "খাবার (কেজি), গড় ওজন (গ্রাম), পানি ও মর্টালিটি রেকর্ড",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TextButton(
                    onClick = { showDailyLogDialog = true },
                    modifier = Modifier.testTag("add_daily_log_text_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("নতুন লগ")
                }
            }
        }

        items(uiState.dailyLogs.take(5), key = { it.id }) { log ->
            DailyLogItemCard(
                log = log,
                onDelete = { onDeleteDailyLog(log) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }

    // Dialog 1: Daily Shed Log (including Mortality entry)
    if (showDailyLogDialog && uiState.flocks.isNotEmpty()) {
        RecordBroilerLogDialog(
            flocks = uiState.flocks,
            onDismiss = { showDailyLogDialog = false },
            onConfirm = { flock, feedPhase, mortality, feedKg, waterLiters, avgWeight, medicine, remarks ->
                onAddDailyLog(flock, feedPhase, mortality, feedKg, waterLiters, avgWeight, medicine, remarks)
                showDailyLogDialog = false
            }
        )
    }

    // Dialog 2: Palla-based Broiler Sale Dialog (ইচ্ছেমতো পিস ও পাল্লা ওজন, ক্রেতার নাম, তারিখ, ওজন, পিস, কত পাল্লা, মোট কেজি, গড়)
    if (showPallaSaleDialog) {
        PallaBroilerSaleDialog(
            flocks = uiState.flocks,
            initialSaleToEdit = editingPallaSale,
            onDismiss = {
                showPallaSaleDialog = false
                editingPallaSale = null
            },
            onConfirmSale = { buyer, date, shed, pallaCount, totalPcs, totalKg, avgBirdKg, avgPallaKg, rate, totalBdt, breakdown, existingId ->
                onAddBroilerPallaSale(
                    buyer,
                    date,
                    shed,
                    pallaCount,
                    totalPcs,
                    totalKg,
                    avgBirdKg,
                    avgPallaKg,
                    rate,
                    totalBdt,
                    breakdown,
                    existingId
                )
                showPallaSaleDialog = false
                editingPallaSale = null
            }
        )
    }

    // Dialog 3: Smart 4-Box Other Sale / Expense Transaction Dialog
    if (showQuickTxDialog) {
        SmartFourBoxTransactionDialog(
            initialIsIncome = quickTxDefaultIncome,
            initialCategory = quickTxDefaultCategory,
            onDismiss = { showQuickTxDialog = false },
            onOpenMultiPallaSaleInstead = {
                showQuickTxDialog = false
                editingPallaSale = null
                showPallaSaleDialog = true
            },
            onConfirm = { title, category, isIncome, amount, qty, party ->
                onQuickAddTransaction(title, category, isIncome, amount, qty, party)
                showQuickTxDialog = false
            }
        )
    }

    // Dialog 4: Add Daily Medicine Schedule
    if (showAddMedicineDialog) {
        AddDailyMedicineDialog(
            flocks = uiState.flocks,
            onDismiss = { showAddMedicineDialog = false },
            onConfirm = { flockName, ageDayLabel, medicineName, timeOfDay, dosage, purpose ->
                onAddDailyMedicine(flockName, ageDayLabel, medicineName, timeOfDay, dosage, purpose)
                showAddMedicineDialog = false
            }
        )
    }

    // Dialog 5: Add Chick Arrival Batch
    if (showAddChickArrivalDialog) {
        AddChickArrivalDashboardDialog(
            onDismiss = { showAddChickArrivalDialog = false },
            onConfirm = { name, shed, breed, count, age, targetSaleDays, weight, chickPrice, arrivalDate, hatchery, notes ->
                onAddFlockClick(name, shed, breed, count, age, targetSaleDays, weight, chickPrice, arrivalDate, hatchery, notes)
                showAddChickArrivalDialog = false
            }
        )
    }
}

@Composable
private fun BroilerHeroBannerCard(
    appName: String,
    activeFlockCount: Int,
    totalBirds: Int,
    mortalityRatePercent: Double,
    onEditAppNameClick: () -> Unit,
    onLogTodayClick: () -> Unit,
    onQuickPallaSaleClick: () -> Unit,
    onQuickExpenseClick: () -> Unit,
    onAddMedicineClick: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hero_banner_card"),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(228.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_broiler_hero),
                contentDescription = "$appName ব্যানার",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0x66071D12),
                                Color(0xE60B2B1C),
                                Color(0xF50E3522)
                            )
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = Color(0xFFFFB703),
                        shape = RoundedCornerShape(50),
                        contentColor = Color(0xFF1E1600),
                        modifier = Modifier.clickable { onEditAppNameClick() }
                    ) {
                        Text(
                            text = "$appName • $activeFlockCount টি শেড সচল ✎",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                        )
                    }
                    Surface(
                        color = Color.White.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(50),
                        contentColor = Color.White
                    ) {
                        Text(
                            text = "মৃত্যু হার: ${String.format(Locale.US, "%.2f", mortalityRatePercent)}%",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                Column {
                    Text(
                        text = "ব্রয়লার উৎপাদন, মৃত্যু হার ও পাল্লা বিক্রি",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "জীবিত: ${formatBanglaInt(totalBirds)} টি • ১৫/২০ টি করে পাল্লায় মুরগি ওজন, ওষুধ শিডিউল ও খরচের হিসাব",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onQuickPallaSaleClick,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF2DC653),
                                contentColor = Color(0xFF04230C)
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("hero_quick_sale_btn")
                        ) {
                            Icon(Icons.Default.Scale, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("পাল্লা ধরে মুরগি বিক্রি", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                        }
                        Button(
                            onClick = onLogTodayClick,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFFFB703),
                                contentColor = Color(0xFF1F1700)
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("hero_log_today_btn")
                        ) {
                            Icon(Icons.Default.EditNote, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("দৈনিক লগ ও মৃত্যু", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                        }
                        OutlinedButton(
                            onClick = onQuickExpenseClick,
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color.White
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("hero_quick_expense_btn")
                        ) {
                            Icon(Icons.Default.Paid, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("খরচ যোগ", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelMedium)
                        }
                        OutlinedButton(
                            onClick = onAddMedicineClick,
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color.White
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.MedicalServices, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ওষুধ যোগ", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BroilerKpiGridSection(uiState: PoultryUiState) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            KpiStatCard(
                title = "জীবিত ব্রয়লার মুরগি",
                value = "${formatBanglaInt(uiState.totalActiveBirds)} টি",
                subtitle = "মোট বাচ্চা: ${formatBanglaInt(uiState.totalInitialBirds)} টি",
                icon = Icons.Default.Pets,
                accentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
            KpiStatCard(
                title = "মৃত্যু হার (Mortality)",
                value = "${String.format(Locale.US, "%.2f", uiState.overallMortalityRatePercent)}%",
                subtitle = "মোট মৃত: ${formatBanglaInt(uiState.totalDeadBirds)} টি (আজ: ${uiState.todayDeadBirds} টি)",
                icon = Icons.Default.HealthAndSafety,
                accentColor = Color(0xFFDC2626),
                modifier = Modifier
                    .weight(1f)
                    .testTag("kpi_mortality_rate_card")
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            KpiStatCard(
                title = "মোট জীবন্ত ওজন",
                value = "${String.format(Locale.US, "%.0f", uiState.totalEstimatedLiveWeightKg)} কেজি",
                subtitle = "গড় ওজন: ${uiState.averageWeightGrams} গ্রাম/পিস",
                icon = Icons.Default.MonitorWeight,
                accentColor = Color(0xFFD97706),
                modifier = Modifier.weight(1f)
            )
            KpiStatCard(
                title = "মোট খাবার ও FCR",
                value = "FCR ${String.format(Locale.US, "%.2f", uiState.overallFcr)}",
                subtitle = "খাবার: ${String.format(Locale.US, "%.1f", uiState.totalFeedBagsConsumed)} বস্তা",
                icon = Icons.Default.Scale,
                accentColor = Color(0xFF0284C7),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun KpiStatCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = accentColor,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun BroilerSalesAndOtherSalesCard(
    uiState: PoultryUiState,
    onOpenPallaSaleDialog: () -> Unit,
    onEditBroilerSale: (BroilerSaleEntity) -> Unit,
    onDeleteBroilerSale: (BroilerSaleEntity) -> Unit,
    onAddOtherSaleCategory: (String) -> Unit,
    onViewAllFinance: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("sales_and_other_sales_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Section Title: সকল আয় আলাদা ভাবে
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "সকল আয় (বিক্রি হিসাব) — আলাদা খাতসমূহ",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF14532D)
                    )
                    Text(
                        text = "মুরগি বিক্রি, ফিড বিক্রি এবং কাঠের গুঁড়া বা লিটার বিক্রি আলাদা হিসাব",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color(0xFFDCFCE7)
                ) {
                    Text(
                        text = "সর্বমোট আয়: ${formatCurrencyBdt(uiState.totalIncomeBdt)}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF15803D),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            // ৩টি আলাদা আয়ের বাটন ও কার্ড: ১. মুরগি বিক্রি | ২. ফিড বিক্রি | ৩. কাঠের গুঁড়া বা লিটার বিক্রি
            Text(
                text = "আয়ের খাত অনুযায়ী আলাদা বাটন (ট্যাপ করে নতুন বিক্রি যোগ করুন):",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF15803D)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OtherSaleItemCard(
                    title = "মুরগি বিক্রি",
                    amountBdt = uiState.chickenSalesTotalBdt,
                    actionLabel = "+ মুরগি বিক্রি",
                    accentColor = Color(0xFF15803D),
                    onClick = onOpenPallaSaleDialog,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("income_chicken_sale_btn")
                )
                OtherSaleItemCard(
                    title = "ফিড বিক্রি",
                    amountBdt = uiState.feedSalesBdt,
                    actionLabel = "+ ফিড বিক্রি",
                    accentColor = Color(0xFFD97706),
                    onClick = { onAddOtherSaleCategory("ফিড বিক্রি") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("other_sale_feed_card")
                )
                OtherSaleItemCard(
                    title = "কাঠের গুঁড়া বা লিটার বিক্রি",
                    amountBdt = uiState.litterSawdustSalesBdt,
                    actionLabel = "+ গুঁড়া/লিটার বিক্রি",
                    accentColor = Color(0xFF4F46E5),
                    onClick = { onAddOtherSaleCategory("কাঠের গুঁড়া বা লিটার বিক্রি") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("other_sale_litter_card")
                )
            }

            // খুচরা মুরগি ও পাল্লা মুরগি আলাদা কুইক বাটন রো
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onOpenPallaSaleDialog,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF15803D),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("add_main_broiler_sale_btn")
                ) {
                    Icon(Icons.Default.Scale, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("মুরগি বিক্রি (পাল্লা ওজন)", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = { onAddOtherSaleCategory("খুচরা মুরগি বিক্রি") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("other_sale_retail_chicken_card")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("খুচরা মুরগি (${formatCurrencyBdt(uiState.retailChickenSalesBdt)})", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }

            // 1. Main Wholesale Broiler Palla Sales Header Card
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFFECFDF5),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenPallaSaleDialog() }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "মুরগি বিক্রি (পাল্লা: ${formatCurrencyBdt(uiState.mainBroilerSalesBdt)} + খুচরা: ${formatCurrencyBdt(uiState.retailChickenSalesBdt)})",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF166534)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = formatCurrencyBdt(uiState.chickenSalesTotalBdt),
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF15803D)
                            )
                        }
                        TextButton(onClick = onViewAllFinance) {
                            Text("সব আয় দেখুন")
                        }
                    }

                    HorizontalDivider(color = Color(0xFFBBF7D0))

                    // Overall Palla Summary Row (কত পাল্লা দিলাম, মোট কত পিস, মোট কত কেজি হলো, গড় কত হলো)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "মোট পাল্লা দিলাম",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF166534)
                            )
                            Text(
                                text = "${uiState.totalSalePallaCount} পাল্লা",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF14532D)
                            )
                        }
                        Column {
                            Text(
                                text = "মোট মুরগি (পিস)",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF166534)
                            )
                            Text(
                                text = "${uiState.totalSoldBirdsPieces} পিস",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF14532D)
                            )
                        }
                        Column {
                            Text(
                                text = "মোট কত কেজি হলো",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF166534)
                            )
                            Text(
                                text = "${String.format(Locale.US, "%.2f", uiState.totalSoldWeightKg)} কেজি",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF15803D)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "গড় ওজন কত হলো",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF166534)
                            )
                            Text(
                                text = "${String.format(Locale.US, "%.2f", uiState.overallSoldAvgWeightPerBirdKg)} কেজি/পিস",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFFD97706)
                            )
                        }
                    }
                }
            }

            // 1B. Individual Palla Sale Invoices (ক্রেতার নাম, তারিখ, ওজন, পিস ও পাল্লার আলাদা হিসাব)
            if (uiState.broilerSales.isNotEmpty()) {
                Text(
                    text = "মুরগি বিক্রির পাল্লা চালানসমূহ (ট্যাপ করে পিস ও ওজন এডিট করুন):",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    uiState.broilerSales.forEach { sale ->
                        BroilerPallaSaleInvoiceCard(
                            sale = sale,
                            onEditSale = onEditBroilerSale,
                            onDelete = { onDeleteBroilerSale(sale) }
                        )
                    }
                }
            }

            // 2. ফিড বিক্রি, কাঠের গুঁড়া বা লিটার বিক্রি ও খুচরা মুরগি বিক্রির ৪ ঘরের ছক
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Storefront,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ফিড বিক্রি, কাঠের গুঁড়া বা লিটার বিক্রি ও খুচরা মুরগি (৪ ঘরের ছক)",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    OtherSalesFourBoxDashboardTable(
                        transactions = uiState.allTransactionsUnfiltered
                    )
                }
            }
        }
    }
}

@Composable
private fun OtherSaleItemCard(
    title: String,
    amountBdt: Double,
    actionLabel: String,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = formatCurrencyBdt(amountBdt),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.ExtraBold,
                color = accentColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(6.dp))
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = accentColor.copy(alpha = 0.12f)
            ) {
                Text(
                    text = actionLabel,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = accentColor,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun LiveBroilerExpenseBreakdownCard(
    uiState: PoultryUiState,
    onAddExpenseCategory: (String) -> Unit,
    onViewAllFinance: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("live_broiler_expense_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "সকল ব্যয় (খরচ হিসাব) — ৭টি আলাদা খাত",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF991B1B)
                    )
                    Text(
                        text = "বাচ্চা কেনা, ফিড কেনা, মেডিসিন কেনা, কাঠের গুঁড়া কেনা, পরিবহন ব্যয় বা ভাড়া, কর্মচারী বেতন ও অন্যান্য খরচ",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TextButton(onClick = onViewAllFinance) {
                    Text("সব ব্যয়")
                }
            }

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFFFEF2F2),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "এখন পর্যন্ত সর্বমোট ব্যয়",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color(0xFF991B1B)
                            )
                            Text(
                                text = formatCurrencyBdt(uiState.totalExpenseBdt),
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFFB91C1C)
                            )
                        }
                        Button(
                            onClick = { onAddExpenseCategory("ফিড কেনা") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFDC2626),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("add_expense_dashboard_btn")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("নতুন ব্যয় যোগ", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = Color(0xFFFECACA))
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "প্রতি পিস জীবিত মুরগির খরচ",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF7F1D1D)
                            )
                            Text(
                                text = "৳${String.format(Locale.US, "%.1f", uiState.costPerLiveBirdBdt)} / পিস",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF991B1B)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "প্রতি কেজি জীবন্ত ওজনের খরচ",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF7F1D1D)
                            )
                            Text(
                                text = "৳${String.format(Locale.US, "%.1f", uiState.costPerLiveKgBdt)} / কেজি",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF991B1B)
                            )
                        }
                    }
                }
            }

            Text(
                text = "ব্যয়ের ৭টি আলাদা বাটন ও খাতওয়ারী হিসাব (ট্যাপ করে যোগ করুন):",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFB91C1C)
            )

            // সারি ১: বাচ্চা কেনা | ফিড কেনা | মেডিসিন কেনা
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExpenseCategoryMiniCard(
                    title = "বাচ্চা কেনা",
                    amountBdt = uiState.chickPurchaseExpenseBdt,
                    subtitle = "+ বাচ্চা কেনা",
                    icon = Icons.Default.Pets,
                    accentColor = Color(0xFF0F766E),
                    onClick = { onAddExpenseCategory("বাচ্চা কেনা") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("expense_chick_card")
                )
                ExpenseCategoryMiniCard(
                    title = "ফিড কেনা",
                    amountBdt = uiState.feedPurchaseExpenseBdt,
                    subtitle = "+ ফিড কেনা",
                    icon = Icons.Default.ShoppingBag,
                    accentColor = Color(0xFFC2410C),
                    onClick = { onAddExpenseCategory("ফিড কেনা") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("expense_feed_card")
                )
                ExpenseCategoryMiniCard(
                    title = "মেডিসিন কেনা",
                    amountBdt = uiState.medicineVaccineExpenseBdt,
                    subtitle = "+ মেডিসিন কেনা",
                    icon = Icons.Default.Vaccines,
                    accentColor = Color(0xFFBE123C),
                    onClick = { onAddExpenseCategory("মেডিসিন কেনা") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("expense_medicine_card")
                )
            }

            // সারি ২: কাঠের গুঁড়া কেনা | পরিবহন ব্যয় বা ভাড়া | কর্মচারী বেতন
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExpenseCategoryMiniCard(
                    title = "কাঠের গুঁড়া কেনা",
                    amountBdt = uiState.sawdustPurchaseExpenseBdt,
                    subtitle = "+ কাঠের গুঁড়া কেনা",
                    icon = Icons.Default.Grass,
                    accentColor = Color(0xFFB45309),
                    onClick = { onAddExpenseCategory("কাঠের গুঁড়া কেনা") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("expense_sawdust_card")
                )
                ExpenseCategoryMiniCard(
                    title = "পরিবহন ব্যয় বা ভাড়া",
                    amountBdt = uiState.transportFareExpenseBdt,
                    subtitle = "+ পরিবহন/ভাড়া",
                    icon = Icons.Default.LocalShipping,
                    accentColor = Color(0xFF0369A1),
                    onClick = { onAddExpenseCategory("পরিবহন ব্যয় বা ভাড়া") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("expense_transport_card")
                )
                ExpenseCategoryMiniCard(
                    title = "কর্মচারী বেতন",
                    amountBdt = uiState.employeeSalaryExpenseBdt,
                    subtitle = "+ কর্মচারী বেতন",
                    icon = Icons.Default.Groups,
                    accentColor = Color(0xFF7C3AED),
                    onClick = { onAddExpenseCategory("কর্মচারী বেতন") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("expense_salary_card")
                )
            }

            // সারি ৩: অন্যান্য খরচ (আলাদা বাটন ও কার্ড)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExpenseCategoryMiniCard(
                    title = "অন্যান্য খরচ",
                    amountBdt = uiState.utilityOtherExpenseBdt,
                    subtitle = "+ অন্যান্য খরচ যোগ করুন (বিদ্যুৎ, গ্যাস, মেরামত ইত্যাদি)",
                    icon = Icons.Default.Paid,
                    accentColor = Color(0xFF475569),
                    onClick = { onAddExpenseCategory("অন্যান্য খরচ") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("expense_other_card")
                )
            }

            // ৪ ঘরের ছকে খরচের বিস্তারিত হিসাব (১ম ঘর: বস্তা/পিস/জন/ট্রিপ | ২য় ঘর: ওজন/টাকা | ৩য় ঘর: গড় অটো | ৪র্থ ঘর: মন্তব্য)
            ExpensesFourBoxDashboardTable(
                transactions = uiState.allTransactionsUnfiltered
            )
        }
    }
}

@Composable
private fun ExpenseCategoryMiniCard(
    title: String,
    amountBdt: Double,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        color = accentColor.copy(alpha = 0.08f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = formatCurrencyBdt(amountBdt),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.ExtraBold,
                color = accentColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ChickArrivalAndBatchesCard(
    flocks: List<FlockEntity>,
    totalActiveBirds: Int,
    totalExpenseBdt: Double,
    onAddNewBatchClick: () -> Unit,
    onViewAllBatchesClick: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("chick_arrival_batches_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "বাচ্চার আসার দিন ও সচল শেড ব্যাচ",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "শেড অনুযায়ী বাচ্চা আসার তারিখ, হ্যাচারি, মৃত্যু হার ও বর্তমান খরচ",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                OutlinedButton(
                    onClick = onAddNewBatchClick,
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("add_chick_arrival_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("নতুন বাচ্চা", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
            }

            flocks.forEach { flock ->
                val flockShareCost = if (totalActiveBirds > 0) {
                    totalExpenseBdt * (flock.currentCount.toDouble() / totalActiveBirds.toDouble())
                } else {
                    flock.initialCount * flock.chickPricePerBird
                }
                val liveWeightKg = (flock.currentCount * flock.avgWeightGrams) / 1000.0

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onViewAllBatchesClick() }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${flock.name} • ${flock.shedNumber}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${flock.breed} • ${flock.hatcheryName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = Color(0xFFFEF3C7),
                                contentColor = Color(0xFF92400E)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CalendarMonth,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "বাচ্চা আসার দিন: ${flock.startDateLabel}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "বয়স ও মৃত্যু হার",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "${flock.ageInDays} দিন • মৃত্যু ${String.format(Locale.US, "%.2f", flock.mortalityRatePercent)}% (${flock.deadBirdCount} টি)",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFDC2626)
                                )
                            }
                            Column {
                                Text(
                                    text = "জীবিত মুরগি ও ওজন",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "${flock.currentCount}/${flock.initialCount} টি • ${liveWeightKg.toInt()} কেজি",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "আনুমানিক খরচ",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = formatCurrencyBdt(flockShareCost),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DailyMedicineScheduleDashboardCard(
    medicines: List<DailyMedicineEntity>,
    selectedTimeFilter: String,
    onSelectTimeFilter: (String) -> Unit,
    onAddMedicineClick: () -> Unit,
    onToggleMedicine: (DailyMedicineEntity) -> Unit,
    onDeleteMedicine: (DailyMedicineEntity) -> Unit,
    onViewVaccinesClick: () -> Unit
) {
    val timeFilters = listOf("সব সময়", "সকাল", "দুপুর", "রাত", "বাকি আছে")
    val filteredMedicines = medicines.filter { med ->
        when (selectedTimeFilter) {
            "সকাল" -> med.timeOfDay.contains("সকাল")
            "দুপুর" -> med.timeOfDay.contains("দুপুর")
            "রাত" -> med.timeOfDay.contains("রাত")
            "বাকি আছে" -> !med.isGivenToday
            else -> true
        }
    }

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("daily_medicine_schedule_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.MedicalServices,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "প্রতিদিনের ঔষধ শিডিউল",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "সকাল, দুপুর ও রাতের পানিতে ব্রয়লারের প্রতিদিনের ওষুধ ও ভিটামিন",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Button(
                    onClick = onAddMedicineClick,
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("add_daily_medicine_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ওষুধ যোগ", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                timeFilters.forEach { filter ->
                    FilterChip(
                        selected = selectedTimeFilter == filter,
                        onClick = { onSelectTimeFilter(filter) },
                        label = { Text(filter) }
                    )
                }
                AssistChip(
                    onClick = onViewVaccinesClick,
                    label = { Text("টিকা চার্ট দেখুন") },
                    leadingIcon = {
                        Icon(
                            Icons.Default.Vaccines,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                )
            }

            if (filteredMedicines.isEmpty()) {
                Text(
                    text = "এই সময়ে কোনো ওষুধ শিডিউল নেই। '+ ওষুধ যোগ' বাটনে ট্যাপ করে নতুন ওষুধ যোগ করুন।",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                filteredMedicines.forEach { med ->
                    val badgeColor = when {
                        med.timeOfDay.contains("সকাল") -> Color(0xFF0284C7)
                        med.timeOfDay.contains("দুপুর") -> Color(0xFFD97706)
                        else -> Color(0xFF7C3AED)
                    }

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (med.isGivenToday) {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                        } else {
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onToggleMedicine(med) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { onToggleMedicine(med) },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = if (med.isGivenToday) {
                                        Icons.Default.CheckCircle
                                    } else {
                                        Icons.Default.RadioButtonUnchecked
                                    },
                                    contentDescription = "ওষুধ স্ট্যাটাস পরিবর্তন",
                                    tint = if (med.isGivenToday) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Surface(
                                        color = badgeColor.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "${med.timeOfDay}ের পানি",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = badgeColor,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Text(
                                        text = med.ageDayLabel,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = med.medicineName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    textDecoration = if (med.isGivenToday) TextDecoration.LineThrough else TextDecoration.None
                                )
                                Text(
                                    text = "${med.flockName} • মাত্রা: ${med.dosagePerLiter}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "কাজ: ${med.purpose}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                            IconButton(onClick = { onDeleteMedicine(med) }) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "ওষুধ মুছুন",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DailyLogItemCard(
    log: DailyLogEntity,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = log.flockName,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = log.feedPhase,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = log.dateLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "লগ মুছুন",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AssistChip(
                    onClick = {},
                    label = { Text("গড় ওজন: ${log.avgWeightGrams} গ্রাম") },
                    leadingIcon = {
                        Icon(
                            Icons.Default.MonitorWeight,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = Color(0xFFD97706)
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                    )
                )
                AssistChip(
                    onClick = {},
                    label = { Text("খাবার: ${log.feedKg.toInt()} কেজি") },
                    leadingIcon = {
                        Icon(
                            Icons.Default.Scale,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                )
                AssistChip(
                    onClick = {},
                    label = { Text("মৃত: ${log.mortalityCount}") },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = if (log.mortalityCount > 0) {
                            MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant
                        }
                    )
                )
            }

            if (log.medicineGiven.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.WaterDrop,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "ওষুধ/ভিটামিন: ${log.medicineGiven} • পানি: ${log.waterLiters.toInt()} লিটার",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun RecordBroilerLogDialog(
    flocks: List<FlockEntity>,
    onDismiss: () -> Unit,
    onConfirm: (FlockEntity, String, Int, Double, Double, Int, String, String) -> Unit
) {
    var selectedFlock by remember { mutableStateOf(flocks.first()) }
    val feedPhases = listOf("প্রি-স্টার্টার", "স্টার্টার ক্রাম্বল", "গ্রোয়ার ক্রাম্বল", "ফিনিশার পেলেট")
    var selectedPhase by remember {
        mutableStateOf(
            when {
                selectedFlock.ageInDays <= 10 -> "প্রি-স্টার্টার"
                selectedFlock.ageInDays <= 20 -> "গ্রোয়ার ক্রাম্বল"
                else -> "ফিনিশার পেলেট"
            }
        )
    }
    var avgWeightInput by remember { mutableStateOf((selectedFlock.avgWeightGrams + 65).toString()) }
    var feedKgInput by remember { mutableStateOf("150") }
    var waterLitersInput by remember { mutableStateOf("300") }
    var mortalityInput by remember { mutableStateOf("0") }
    var medicineInput by remember { mutableStateOf("লিভার টনিক ও ইলেকট্রোলাইট") }
    var remarksInput by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "আজকের ব্রয়লার শেড লগ ও মৃত্যু এন্ট্রি",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "ব্রয়লার শেড নির্বাচন করুন:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    flocks.forEach { flock ->
                        FilterChip(
                            selected = selectedFlock.id == flock.id,
                            onClick = {
                                selectedFlock = flock
                                avgWeightInput = (flock.avgWeightGrams + 65).toString()
                            },
                            label = { Text(flock.shedNumber) }
                        )
                    }
                }

                Text(
                    text = "খাবারের ধরন (Feed Phase):",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    feedPhases.forEach { phase ->
                        FilterChip(
                            selected = selectedPhase == phase,
                            onClick = { selectedPhase = phase },
                            label = { Text(phase) }
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = avgWeightInput,
                        onValueChange = { avgWeightInput = it },
                        label = { Text("গড় ওজন (গ্রাম)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("log_weight_input")
                    )
                    OutlinedTextField(
                        value = mortalityInput,
                        onValueChange = { mortalityInput = it },
                        label = { Text("মৃত মুরগি (পিস)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("log_mortality_input")
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = feedKgInput,
                        onValueChange = { feedKgInput = it },
                        label = { Text("খাবার (কেজি)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("log_feed_input")
                    )
                    OutlinedTextField(
                        value = waterLitersInput,
                        onValueChange = { waterLitersInput = it },
                        label = { Text("পানি (লিটার)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = medicineInput,
                    onValueChange = { medicineInput = it },
                    label = { Text("প্রদত্ত ওষুধ / ভিটামিন") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = remarksInput,
                    onValueChange = { remarksInput = it },
                    label = { Text("মন্তব্য (লিটার/তাপমাত্রা)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(
                        selectedFlock,
                        selectedPhase,
                        mortalityInput.toIntOrNull() ?: 0,
                        feedKgInput.toDoubleOrNull() ?: 0.0,
                        waterLitersInput.toDoubleOrNull() ?: 0.0,
                        avgWeightInput.toIntOrNull() ?: selectedFlock.avgWeightGrams,
                        medicineInput,
                        remarksInput
                    )
                },
                modifier = Modifier.testTag("confirm_daily_log_btn")
            ) {
                Text("সংরক্ষণ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}

@Composable
private fun QuickDashboardTransactionDialog(
    initialIsIncome: Boolean,
    initialCategory: String,
    onDismiss: () -> Unit,
    onConfirm: (String, String, Boolean, Double, String, String) -> Unit
) {
    val saleCategories = listOf(
        "খুচরা মুরগি বিক্রি",
        "ফিড বিক্রি",
        "লিটার/ব্যবহৃত গুঁড়া বিক্রি",
        "মুরগি বিক্রি"
    )
    val expenseCategories = listOf(
        "কর্মচারী বেতন",
        "কাঠের গুঁড়া কেনা",
        "যাতায়াত ভাড়া",
        "ফিড ক্রয়",
        "বাচ্চা ক্রয়",
        "ওষুধ ও টিকা",
        "বিদ্যুৎ ও অন্যান্য"
    )

    var isIncome by remember { mutableStateOf(initialIsIncome) }
    var category by remember { mutableStateOf(initialCategory) }
    var title by remember {
        mutableStateOf(
            when (initialCategory) {
                "খুচরা মুরগি বিক্রি" -> "খামার থেকে খুচরা ব্রয়লার বিক্রি"
                "ফিড বিক্রি" -> "অতিরিক্ত ব্রয়লার ফিড বিক্রি"
                "লিটার/ব্যবহৃত গুঁড়া বিক্রি" -> "শেডের ব্যবহৃত কাঠের গুঁড়া / লিটার বিক্রি"
                "কর্মচারী বেতন" -> "খামার কর্মচারী মাসিক বেতন"
                "কাঠের গুঁড়া কেনা" -> "শেডের জন্য শুকনো কাঠের গুঁড়া কেনা"
                "যাতায়াত ভাড়া" -> "ফিড/বাচ্চা পরিবহন গাড়ি ভাড়া"
                "বাচ্চা ক্রয়" -> "একদিনের ব্রয়লার বাচ্চা (DOC) ক্রয়"
                "ওষুধ ও টিকা" -> "ব্রয়লারের ওষুধ ও ভিটামিন ক্রয়"
                else -> "ব্রয়লার ফিড বস্তা ক্রয়"
            }
        )
    }
    var amountInput by remember {
        mutableStateOf(
            when (initialCategory) {
                "খুচরা মুরগি বিক্রি" -> "3800"
                "ফিড বিক্রি" -> "6900"
                "লিটার/ব্যবহৃত গুঁড়া বিক্রি" -> "4500"
                "কর্মচারী বেতন" -> "12000"
                "কাঠের গুঁড়া কেনা" -> "6500"
                "যাতায়াত ভাড়া" -> "2500"
                else -> "16750"
            }
        )
    }
    var quantityNote by remember {
        mutableStateOf(
            when (initialCategory) {
                "খুচরা মুরগি বিক্রি" -> "১২ পিস • ২০ কেজি @ ৳১৯০/কেজি"
                "ফিড বিক্রি" -> "২ বস্তা (১০০ কেজি) @ ৳৩,৪৫০/বস্তা"
                "লিটার/ব্যবহৃত গুঁড়া বিক্রি" -> "৫০ বস্তা ব্যবহৃত গুঁড়া @ ৳৯০/বস্তা"
                "কর্মচারী বেতন" -> "১ জন স্টাফ • মাসিক বেতন"
                "কাঠের গুঁড়া কেনা" -> "৪৫ বস্তা শুকনো গুঁড়া @ ৳১৪৫/বস্তা"
                "যাতায়াত ভাড়া" -> "১ ট্রিপ পিকআপ/ভ্যান ভাড়া"
                else -> "৫ বস্তা ফিড @ ৳৩,৩৫০/বস্তা"
            }
        )
    }
    var partyName by remember { mutableStateOf("") }
    var customPiecesInput by remember { mutableStateOf("5") }
    var customWeightKgInput by remember { mutableStateOf("9.0") }
    var customRatePerKgInput by remember { mutableStateOf("190") }

    val isChickenSaleCategory = isIncome && (category == "খুচরা মুরগি বিক্রি" || category == "মুরগি বিক্রি")

    val recalculateChickenSale = { pcsStr: String, wtStr: String, rateStr: String ->
        val pcs = pcsStr.toIntOrNull() ?: 0
        val wt = wtStr.toDoubleOrNull() ?: 0.0
        val rate = rateStr.toDoubleOrNull() ?: 0.0
        val avg = if (pcs > 0) wt / pcs.toDouble() else 0.0
        if (wt > 0.0 && rate > 0.0) {
            amountInput = String.format(Locale.US, "%.0f", wt * rate)
        }
        quantityNote = "$pcs পিস • ${String.format(Locale.US, "%.2f", wt)} কেজি (গড় ${String.format(Locale.US, "%.2f", avg)} কেজি) @ ৳${String.format(Locale.US, "%.0f", rate)}/কেজি"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isIncome) "বিক্রি ও আয় এন্ট্রি (ইচ্ছেমতো পিস ও পরিমাণ)" else "খরচ ও ব্যয় এন্ট্রি",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = isIncome,
                        onClick = {
                            isIncome = true
                            category = saleCategories.first()
                        },
                        label = { Text("বিক্রি (আয়)") }
                    )
                    FilterChip(
                        selected = !isIncome,
                        onClick = {
                            isIncome = false
                            category = expenseCategories.first()
                        },
                        label = { Text("খরচ (ব্যয়)") }
                    )
                }

                Text(
                    text = if (isIncome) "বিক্রির খাত নির্বাচন করুন:" else "খরচের খাত নির্বাচন করুন:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                val activeList = if (isIncome) saleCategories else expenseCategories
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    activeList.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = {
                                category = cat
                                title = cat
                            },
                            label = { Text(cat) }
                        )
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("বিবরণ") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (isChickenSaleCategory) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = customPiecesInput,
                            onValueChange = {
                                customPiecesInput = it
                                recalculateChickenSale(it, customWeightKgInput, customRatePerKgInput)
                            },
                            label = { Text("মুরগি (ইচ্ছেমতো পিস)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("custom_retail_pieces_input")
                        )
                        OutlinedTextField(
                            value = customWeightKgInput,
                            onValueChange = {
                                customWeightKgInput = it
                                recalculateChickenSale(customPiecesInput, it, customRatePerKgInput)
                            },
                            label = { Text("মোট ওজন (কেজি)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = customRatePerKgInput,
                            onValueChange = {
                                customRatePerKgInput = it
                                recalculateChickenSale(customPiecesInput, customWeightKgInput, it)
                            },
                            label = { Text("দর (৳/কেজি)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(0.9f)
                        )
                    }
                }

                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("টাকার পরিমাণ (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = quantityNote,
                    onValueChange = { quantityNote = it },
                    label = { Text("পরিমাণ (ইচ্ছেমতো পিস / কেজি / বস্তা / ট্রিপ)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = partyName,
                    onValueChange = { partyName = it },
                    label = { Text("ক্রেতা / কর্মচারী / ডিলারের নাম") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountInput.toDoubleOrNull() ?: 0.0
                    if (title.isNotBlank() && amount > 0.0) {
                        onConfirm(title, category, isIncome, amount, quantityNote, partyName)
                    }
                }
            ) {
                Text("সংরক্ষণ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}

@Composable
private fun AddDailyMedicineDialog(
    flocks: List<FlockEntity>,
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String, String, String) -> Unit
) {
    val timeOptions = listOf("সকাল", "দুপুর", "রাত")
    var selectedTime by remember { mutableStateOf("সকাল") }
    var flockName by remember {
        mutableStateOf(flocks.firstOrNull()?.let { "${it.shedNumber} (${it.name})" } ?: "সকল ব্রয়লার শেড")
    }
    var ageDayLabel by remember { mutableStateOf("৮ম – ১২তম দিন") }
    var medicineName by remember { mutableStateOf("রেনামাইসিন / ডক্সিভেট + ভিটামিন বি-কমপ্লেক্স") }
    var dosagePerLiter by remember { mutableStateOf("১ গ্রাম / ১ লিটার পানিতে") }
    var purpose by remember { mutableStateOf("ঠান্ডা প্রতিরোধ ও দৈহিক বৃদ্ধি") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "প্রতিদিনের ঔষধ শিডিউল যোগ করুন",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "ওষুধ দেওয়ার সময়:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    timeOptions.forEach { t ->
                        FilterChip(
                            selected = selectedTime == t,
                            onClick = { selectedTime = t },
                            label = { Text("${t}ের পানি") }
                        )
                    }
                }

                OutlinedTextField(
                    value = medicineName,
                    onValueChange = { medicineName = it },
                    label = { Text("ওষুধ / ভিটামিনের নাম") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = ageDayLabel,
                        onValueChange = { ageDayLabel = it },
                        label = { Text("মুরগির বয়স/দিন") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = dosagePerLiter,
                        onValueChange = { dosagePerLiter = it },
                        label = { Text("পানির মাত্রা") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = flockName,
                    onValueChange = { flockName = it },
                    label = { Text("নির্ধারিত শেড / ব্যাচ") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = purpose,
                    onValueChange = { purpose = it },
                    label = { Text("ওষুধের কাজ / উদ্দেশ্য") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (medicineName.isNotBlank()) {
                        onConfirm(flockName, ageDayLabel, medicineName, selectedTime, dosagePerLiter, purpose)
                    }
                }
            ) {
                Text("শিডিউলে যোগ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}

@Composable
private fun AddChickArrivalDashboardDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, Int, Int, Int, Int, Double, String, String, String) -> Unit
) {
    val breeds = listOf("কব-৫০০ (Cobb-500)", "রস-৩০৮ (Ross-308)", "হাবার্ড (Hubbard)", "আর্বার একরস (Arbor Acres)")
    var selectedBreed by remember { mutableStateOf(breeds.first()) }
    var name by remember { mutableStateOf("নতুন ব্রয়লার ব্যাচ #১৭") }
    var shedNumber by remember { mutableStateOf("শেড-০৪") }
    var arrivalDate by remember { mutableStateOf("২৮ সেপ্টেম্বর ২০২৬") }
    var hatcheryName by remember { mutableStateOf("কাজী হ্যাচারি (A-Grade)") }
    var initialCount by remember { mutableStateOf("1500") }
    var chickPrice by remember { mutableStateOf("48") }
    var notes by remember { mutableStateOf("একদিনের সুস্থ ব্রয়লার বাচ্চা (DOC)") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "নতুন বাচ্চার আসার দিন ও ব্যাচ এন্ট্রি",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = arrivalDate,
                    onValueChange = { arrivalDate = it },
                    label = { Text("বাচ্চার আসার দিন (তারিখ)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    breeds.forEach { breed ->
                        FilterChip(
                            selected = selectedBreed == breed,
                            onClick = { selectedBreed = breed },
                            label = { Text(breed) }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("ব্যাচের নাম") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = shedNumber,
                        onValueChange = { shedNumber = it },
                        label = { Text("শেড নম্বর") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = initialCount,
                        onValueChange = { initialCount = it },
                        label = { Text("বাচ্চার সংখ্যা (পিস)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = chickPrice,
                        onValueChange = { chickPrice = it },
                        label = { Text("দর (৳/বাচ্চা)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = hatcheryName,
                    onValueChange = { hatcheryName = it },
                    label = { Text("হ্যাচারি / কোম্পানির নাম") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val count = initialCount.toIntOrNull() ?: 1000
                    val price = chickPrice.toDoubleOrNull() ?: 48.0
                    onConfirm(
                        name,
                        shedNumber,
                        selectedBreed,
                        count,
                        1,
                        32,
                        44,
                        price,
                        arrivalDate,
                        hatcheryName,
                        notes
                    )
                }
            ) {
                Text("সংরক্ষণ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}

fun formatCurrencyBdt(amount: Double): String {
    val formatter = NumberFormat.getNumberInstance(Locale.US)
    formatter.maximumFractionDigits = 0
    val sign = if (amount < 0) "-" else ""
    return "${sign}৳${formatter.format(kotlin.math.abs(amount))}"
}

fun formatBanglaInt(number: Int): String {
    return NumberFormat.getNumberInstance(Locale.US).format(number)
}
