package com.example.ui.screens

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.FlockEntity
import com.example.data.VaccinationEntity

private const val ASSET_LINKS_JSON = """[{
  "relation": ["delegate_permission/common.handle_all_urls"],
  "target": {
    "namespace": "android_app",
    "package_name": "io.github.shawonrup7_cpu.twa",
    "sha256_cert_fingerprints": [
      "79:0B:B0:6E:C7:48:92:3A:B9:03:B1:19:1E:2D:7F:D3:2A:E2:80:F2:AB:4D:6F:5F:41:12:D8:AD:1C:A9:1A:4D"
    ]
  }
}]"""

@Composable
fun HealthAndPortalScreen(
    vaccinations: List<VaccinationEntity>,
    flocks: List<FlockEntity>,
    onAddVaccination: (String, String, Int, String, String, String) -> Unit,
    onToggleVaccination: (VaccinationEntity) -> Unit,
    onDeleteVaccination: (VaccinationEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var showWebPortalFullScreen by rememberSaveable { mutableStateOf(false) }
    var portalUrl by rememberSaveable { mutableStateOf("https://docs.pwabuilder.com/#/builder/android?id=publish") }
    var urlInput by rememberSaveable { mutableStateOf(portalUrl) }
    var showAddVaccineDialog by rememberSaveable { mutableStateOf(false) }
    var showAssetLinksDialog by rememberSaveable { mutableStateOf(false) }
    var copiedBannerText by remember { mutableStateOf<String?>(null) }

    val context = LocalContext.current

    if (showWebPortalFullScreen) {
        EmbeddedWebPortalView(
            url = portalUrl,
            onBack = { showWebPortalFullScreen = false }
        )
        return
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("health_portal_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Broiler Vaccination Schedule Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MedicalServices,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "ব্রয়লার টিকা ও ভ্যাকসিন সূচি",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "৫ম দিন BCRDV, ১০ম দিন গামবোরো ও ১৭তম দিন বুস্টার ডোজ",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Button(
                    onClick = { showAddVaccineDialog = true },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("add_vaccine_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("নতুন টিকা")
                }
            }
        }

        items(vaccinations, key = { it.id }) { vaccine ->
            VaccinationRowCard(
                vaccine = vaccine,
                onToggle = { onToggleVaccination(vaccine) },
                onDelete = { onDeleteVaccination(vaccine) }
            )
        }

        // 2. Brothers Poultry Web Portal & Play Store TWA Configuration
        item {
            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("twa_config_card"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "ব্রয়লার খামার হিসাব • TWA ও পোর্টাল কনফিগ",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "Package: io.github.shawonrup7_cpu.twa • খামার ম্যানেজার",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        label = { Text("ওয়েব পোর্টাল / PWA লিংক") },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Language, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                portalUrl = urlInput.ifBlank { "https://docs.pwabuilder.com/#/builder/android?id=publish" }
                                showWebPortalFullScreen = true
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("open_web_portal_btn")
                        ) {
                            Icon(Icons.Default.OpenInBrowser, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ওয়েব পোর্টাল খুলুন")
                        }
                        FilledTonalButton(
                            onClick = { showAssetLinksDialog = true },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Digital Asset Links")
                        }
                    }

                    HorizontalDivider()

                    Text(
                        text = "Play Store Signing & Keystore তথ্য:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("• Signer: ব্রাদার্স পোল্ট্রি Admin (ব্রাদার্স পোল্ট্রি ফার্ম)", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            Text("• Keystore File: signing.keystore | Alias: my-key-alias", style = MaterialTheme.typography.bodySmall)
                            Text("• SHA-256: 79:0B:B0:6E:C7:48:92:3A:B9:03:B1:19:1E:2D:7F:D3:2A:E2:80:F2:AB:4D:6F:5F:41:12:D8:AD:1C:A9:1A:4D", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(
                            onClick = {
                                copyToClipboard(context, "assetlinks.json", ASSET_LINKS_JSON)
                                copiedBannerText = "assetlinks.json ক্লিপবোর্ডে কপি হয়েছে!"
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("assetlinks কপি")
                        }
                        FilledTonalButton(
                            onClick = {
                                copyToClipboard(
                                    context,
                                    "SHA-256",
                                    "79:0B:B0:6E:C7:48:92:3A:B9:03:B1:19:1E:2D:7F:D3:2A:E2:80:F2:AB:4D:6F:5F:41:12:D8:AD:1C:A9:1A:4D"
                                )
                                copiedBannerText = "SHA-256 ফিঙ্গারপ্রিন্ট কপি হয়েছে!"
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("SHA-256 কপি")
                        }
                    }

                    copiedBannerText?.let { msg ->
                        Text(
                            text = msg,
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFF15803D),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }

    if (showAddVaccineDialog) {
        AddVaccinationDialog(
            flocks = flocks,
            onDismiss = { showAddVaccineDialog = false },
            onConfirm = { flockName, vaccineName, ageDays, dateLabel, route, doseInfo ->
                onAddVaccination(flockName, vaccineName, ageDays, dateLabel, route, doseInfo)
                showAddVaccineDialog = false
            }
        )
    }

    if (showAssetLinksDialog) {
        AlertDialog(
            onDismissRequest = { showAssetLinksDialog = false },
            title = { Text("Digital Asset Links (.well-known/assetlinks.json)") },
            text = {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = ASSET_LINKS_JSON,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        copyToClipboard(context, "assetlinks.json", ASSET_LINKS_JSON)
                        copiedBannerText = "assetlinks.json কপি সম্পন্ন!"
                        showAssetLinksDialog = false
                    }
                ) {
                    Text("কপি করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAssetLinksDialog = false }) {
                    Text("বন্ধ করুন")
                }
            }
        )
    }
}

@Composable
private fun VaccinationRowCard(
    vaccine: VaccinationEntity,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (vaccine.isCompleted) {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onToggle) {
                Icon(
                    imageVector = if (vaccine.isCompleted) {
                        Icons.Default.CheckCircle
                    } else {
                        Icons.Default.RadioButtonUnchecked
                    },
                    contentDescription = "টিকা সম্পন্ন পরিবর্তন",
                    tint = if (vaccine.isCompleted) {
                        Color(0xFF15803D)
                    } else {
                        MaterialTheme.colorScheme.primary
                    }
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = vaccine.vaccineName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    textDecoration = if (vaccine.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                )
                Text(
                    text = "${vaccine.flockName} • বয়স: ${vaccine.targetAgeDays} দিন",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "তারিখ: ${vaccine.scheduledDateLabel} • প্রয়োগ: ${vaccine.route} (${vaccine.doseInfo})",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "টিকা মুছুন",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun AddVaccinationDialog(
    flocks: List<FlockEntity>,
    onDismiss: () -> Unit,
    onConfirm: (String, String, Int, String, String, String) -> Unit
) {
    var flockName by remember {
        mutableStateOf(flocks.firstOrNull()?.let { "${it.name} (${it.shedNumber})" } ?: "ব্রয়লার শেড-০১")
    }
    var vaccineName by remember { mutableStateOf("গামবোরো বুস্টার ডোজ (IBD Plus)") }
    var targetAgeDays by remember { mutableStateOf("17") }
    var scheduledDateLabel by remember { mutableStateOf("৩০ সেপ্টেম্বর ২০২৬") }
    val routes = listOf("চোখে ১ ফোঁটা", "ঠান্ডা খাবার পানিতে", "ইনজেকশন")
    var selectedRoute by remember { mutableStateOf(routes.first()) }
    var doseInfo by remember { mutableStateOf("১,৫০০ ডোজ ভায়াল") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন ব্রয়লার টিকা যুক্ত করুন", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = vaccineName,
                    onValueChange = { vaccineName = it },
                    label = { Text("টিকার নাম") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = flockName,
                    onValueChange = { flockName = it },
                    label = { Text("শেড / ব্যাচের নাম") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = targetAgeDays,
                        onValueChange = { targetAgeDays = it },
                        label = { Text("বয়স (দিন)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = scheduledDateLabel,
                        onValueChange = { scheduledDateLabel = it },
                        label = { Text("তারিখ") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    routes.forEach { r ->
                        FilterChip(
                            selected = selectedRoute == r,
                            onClick = { selectedRoute = r },
                            label = { Text(r) }
                        )
                    }
                }
                OutlinedTextField(
                    value = doseInfo,
                    onValueChange = { doseInfo = it },
                    label = { Text("ডোজ নোট") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (vaccineName.isNotBlank()) {
                        onConfirm(
                            flockName,
                            vaccineName,
                            targetAgeDays.toIntOrNull() ?: 10,
                            scheduledDateLabel,
                            selectedRoute,
                            doseInfo
                        )
                    }
                }
            ) {
                Text("সংরক্ষণ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun EmbeddedWebPortalView(
    url: String,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Column {
                    Text("ব্রাদার্স পোল্ট্রি ওয়েব পোর্টাল", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(url, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                }
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "ফিরে যান")
                }
            },
            actions = {
                IconButton(onClick = { webViewRef?.reload() }) {
                    Icon(Icons.Default.Refresh, contentDescription = "রিলোড")
                }
            }
        )
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    webViewClient = WebViewClient()
                    webChromeClient = WebChromeClient()
                    loadUrl(url)
                    webViewRef = this
                }
            },
            modifier = Modifier.fillMaxSize()
        )
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
}
