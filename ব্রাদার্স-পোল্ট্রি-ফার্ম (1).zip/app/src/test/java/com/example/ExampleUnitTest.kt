package com.example

import com.example.data.FlockEntity
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun flockFcrCalculation_isCorrect() {
        val flock = FlockEntity(
            name = "কব-৫০০ ব্রয়লার",
            shedNumber = "শেড-১",
            birdType = "কব-৫০০",
            initialCount = 1000,
            currentCount = 1000,
            mortalityCount = 0,
            ageInDays = 28,
            avgWeightGrams = 1500, // 1500 kg total biomass
            totalFeedKg = 2250.0   // FCR = 2250 / 1500 = 1.50
        )
        assertEquals("1.50", flock.fcrFormatted)
        assertEquals(1500.0, flock.totalLiveWeightKg, 0.01)
        assertEquals(45.0, flock.totalFeedBags, 0.01)
    }
}
